export type FacilityType = 'government' | 'commercial' | 'residential';

export type CommercialSubtypeCode = 'industrial' | 'educational' | 'warehouse' | 'workshop' | 'farm' | 'other' | string;

export interface FacilitySubtype {
  id: string;
  code: string;
  name_ar: string;
  name_en: string;
  is_system: boolean;
  is_active: boolean;
}

export type DepartmentId = 
  | 'elevators' 
  | 'fire_safety' 
  | 'cctv' 
  | 'environmental' 
  | 'security' 
  | 'extinguishers' 
  | 'contracting';

export interface Department {
  id: DepartmentId;
  name_ar: string;
  name_en: string;
  icon: string;
  managerName: string;
}

export type ServiceCategory = 
  | 'maintenance' 
  | 'installation' 
  | 'contract' 
  | 'certificate' 
  | 'permit' 
  | 'study' 
  | 'test' 
  | 'refill' 
  | 'renewal' 
  | 'guards'
  | 'custom_review';

export type RequestStatus = 
  | 'draft' 
  | 'submitted' 
  | 'under_review' 
  | 'quoted' 
  | 'approved' 
  | 'rejected' 
  | 'activated';

export interface ClientFacility {
  id: string;
  client_id: string;
  facility_name: string;
  facility_type: FacilityType;
  commercial_subtype?: string;
  commercial_subtype_other?: string;
  owner_name: string;
  owner_phone: string;
  delegate_name?: string;
  delegate_phone?: string;
  location_lat: number;
  location_lng: number;
  map_url: string;
  address_text: string;
  notes?: string;
  site_photo_url: string;
  created_at: string;
  is_draft?: boolean;
  lead_status?: string;
  marketer_estimated_value?: number;
  marketer_pricing_notes?: string;
  created_by?: string;
}

export interface ClientServiceRequest {
  id: string;
  request_number: string; // e.g. REQ-2026-0001
  client_id: string;
  client_name: string;
  facility_id: string;
  department_id: DepartmentId;
  service_category: ServiceCategory;
  service_title_ar: string;
  service_details: Record<string, any>;
  status: RequestStatus;
  marketer_id: string;
  marketer_name: string;
  marketer_estimated_value?: number; // Point 6: Marketer puts initial estimated value
  marketer_pricing_notes?: string;
  domain_approved_value?: number;    // Department manager approved value
  finance_approved_value?: number;   // Finance manager final value
  submitted_at: string;
  reviewed_by?: string;
  reviewed_at?: string;
  rejection_reason?: string;
  quote_id?: string;
  subscription_id?: string;
  created_at: string;
}

export interface MarketingVisitAppointment {
  id: string;
  appointment_number: string;
  client_id: string;
  client_name: string;
  facility_id: string;
  facility_name: string;
  service_request_id?: string;
  requested_date: string;
  requested_time: string;
  status: 'requested' | 'confirmed' | 'rescheduled' | 'completed' | 'cancelled';
  confirmed_by?: string;
  confirmed_at?: string;
  rescheduled_reason?: string;
  converted_visit_id?: string;
  marketer_id: string;
  marketer_name: string;
  created_at: string;
}

export type VisitSourceType = 'maintenance_plan' | 'service_request' | 'marketing' | 'manual' | 'emergency';
export type VisitType = 'inspection' | 'preventive_maintenance' | 'corrective_repair' | 'installation' | 'emergency';
export type VisitStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
export type VisitSessionStatus = 'not_started' | 'active' | 'ended' | 'aborted';

export interface VisitCostItem {
  id: string;
  visit_id: string;
  cost_type: 'labor' | 'overtime' | 'vehicle_operating' | 'fuel' | 'parts';
  technician_name?: string;
  quantity: number;
  unit_rate: number;
  duration_seconds?: number;
  amount: number;
  notes?: string;
}

export interface Visit {
  id: string;
  visit_number: string;
  client_id: string;
  client_name: string;
  facility_id: string;
  facility_name: string;
  site_address: string;
  location_lat: number;
  location_lng: number;
  visit_type: VisitType;
  source_type: VisitSourceType;
  marketing_appointment_id?: string;
  source_service_request_id?: string;
  scheduled_date: string;
  scheduled_time: string;
  status: VisitStatus;
  
  // Point 14: Dual QR scan session
  session_status: VisitSessionStatus;
  start_scan_at?: string;
  end_scan_at?: string;
  duration_seconds: number; // Point 15: Precise seconds calculation

  // Point 3 & 4: Distinct supervisor & team leader & technician
  assigned_team_id?: string;
  assigned_team_name?: string;
  assigned_supervisor_name?: string;
  assigned_team_leader_name?: string;
  assigned_technician_id?: string;
  assigned_technician_name?: string;
  
  // Point 15: Precise cost calculation
  labor_cost: number;
  vehicle_cost: number;
  parts_cost: number;
  total_cost: number;
  cost_breakdown?: VisitCostItem[];
  site_qr_code?: string;
  emergency_token_deducted?: boolean;
  cost_calculation?: {
    duration_seconds: number;
    labor_cost_sar: number;
    vehicle_operating_cost_sar: number;
    parts_cost_sar: number;
    total_cost_sar: number;
  };

  actual_start_at?: string;
  actual_end_at?: string;
  completion_percentage: number;
  qr_verified: boolean;
  inspection_notes?: string;
  findings?: string[];
  photos?: string[];
  parts_consumed?: { part_id: string; part_name: string; quantity: number; unit_cost: number }[];
  report_approved_by?: string;
  created_by: string;
  created_at: string;
}

export interface QuoteItem {
  id: string;
  quote_id: string;
  department_id: DepartmentId;
  service_id?: string;
  description: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  notes?: string;
}

export interface Quote {
  id: string;
  quote_number: string;
  client_id: string;
  client_name: string;
  client_service_request_id?: string;
  facility_id: string;
  facility_name: string;
  quote_type: string;
  contract_type: 'standard' | 'premium_plus' | 'consultation' | 'permit_only';
  items: QuoteItem[];
  subtotal: number;
  vat_rate: number;
  vat_amount: number;
  total_price: number;
  status: 'draft' | 'sent' | 'under_review' | 'accepted' | 'rejected' | 'expired';
  valid_until: string;
  created_by: string;
  created_at: string;
  accepted_at?: string;
  generated_subscription_id?: string;
}

export interface SubscriptionItem {
  id: string;
  subscription_id: string;
  department_id: DepartmentId;
  service_name: string;
  quantity: number;
  unit_value: number;
  total_value: number;
  visit_frequency: 'weekly' | 'monthly' | 'quarterly' | 'semi_annual' | 'annual';
  visits_per_year: number;
}

export interface Subscription {
  id: string;
  subscription_number: string;
  client_id: string;
  client_name: string;
  facility_id: string;
  facility_name: string;
  client_service_request_id?: string;
  
  // Point 2: Premium+ contract type
  contract_type: 'standard' | 'premium_plus' | 'consultation' | 'permit_only';
  emergency_tokens_total?: number;
  emergency_tokens_remaining?: number;
  free_parts_allowance_annual?: number;
  free_parts_consumed?: number;
  sla_response_hours?: number;

  items: SubscriptionItem[];
  total_annual_value: number;
  start_date: string;
  end_date: string;
  status: 'active' | 'pending_finance' | 'suspended' | 'expired' | 'renewed';
  finance_approved_by?: string;
  finance_approved_at?: string;
  created_at: string;
}

export interface Part {
  id: string;
  part_number: string;
  name_ar: string;
  name_en: string;
  department_ids: DepartmentId[];
  facility_types: FacilityType[];
  commercial_subtypes?: string[];
  unit: string;
  unit_cost: number;
  is_active: boolean;
}

export interface WarehouseStock {
  id: string;
  part_id: string;
  part_name: string;
  part_number: string;
  warehouse_id: string;
  warehouse_name: string;
  quantity: number;
  reserved_quantity: number;
  available_quantity: number; // quantity - reserved_quantity
}

export interface QRCodeRecord {
  id: string;
  qr_code: string;
  client_id: string;
  facility_id?: string;
  service_request_id?: string;
  purpose: 'site_access' | 'asset_identification' | 'service_specific' | 'contract_activation';
  assigned_label: string;
  location_name: string;
  scans_count: number;
  last_scanned_at?: string;
  created_at: string;
}

export interface NotificationRecord {
  id: string;
  recipient_type: 'user' | 'client';
  recipient_id: string;
  recipient_name: string;
  channel: 'in_app' | 'sms' | 'whatsapp' | 'email';
  subject: string;
  message: string;
  status: 'queued' | 'sent' | 'delivered' | 'read';
  event_type: string;
  created_at: string;
}

// Point 18: Full 19 roles (including FINANCE_MGR and HR_MGR)
export type RoleCode = 
  | 'SYS_ADMIN' 
  | 'GM' 
  | 'ADMIN_MGR' 
  | 'FINANCE_MGR'       // Role #4
  | 'HR_MGR'            // Role #5
  | 'MARKETING_MGR' 
  | 'MARKETER' 
  | 'REPRESENTATIVE' 
  | 'DOMAIN_MGR' 
  | 'TEAM_SUPERVISOR' 
  | 'MAINT_TEAM_LEADER' 
  | 'MAINT_TECHNICIAN' 
  | 'FAULT_TEAM_LEADER' 
  | 'FAULT_TECHNICIAN' 
  | 'SECURITY_MGR' 
  | 'GUARD' 
  | 'ENV_PERMITS_MGR' 
  | 'ENV_INSPECTOR' 
  | 'CLIENT' 
  | 'REFERRED_CLIENT';

export interface UserRoleDefinition {
  code: RoleCode;
  title_ar: string;
  level: number;
  parent_role?: RoleCode;
  domain?: DepartmentId | 'all' | 'client' | 'security' | 'environmental' | 'own';
  description_ar: string;
  landing_route: string;
  default_view: 'list' | 'map' | 'calendar' | 'kanban' | 'chart';
  widgets: string[];
  landing_page?: {
    title_ar: string;
    description_ar: string;
    primary_kpis: { title_ar: string; value: string | number; change?: string }[];
    recommended_actions: { label_ar: string; action: string }[];
  };
}

// Point 8: Employee Marketing Mode (Side-Hustle)
export interface EmployeeMarketingActivation {
  id: string;
  user_id: string;
  user_name: string;
  user_department: string;
  is_active: boolean;
  commission_rate: number;
  total_leads_submitted: number;
  total_commissions_earned: number;
  activated_at: string;
}

// Point 10: Loyalty Wallet & Redemptions
export interface LoyaltyTransaction {
  id: string;
  wallet_id: string;
  transaction_type: 'earn' | 'redeem_cash' | 'redeem_discount' | 'expire' | 'adjustment';
  points: number;
  monetary_value: number; // e.g. 100 points = 10 SAR
  reference_desc: string;
  created_at: string;
}

export interface LoyaltyWallet {
  id: string;
  client_id: string;
  client_name: string;
  balance_points: number;
  monetary_value_sar: number;
  total_earned_points: number;
  total_redeemed_sar: number;
  transactions: LoyaltyTransaction[];
}

// Point 9: HR Performance Reviews & Employee Dues
export interface PerformanceReview {
  id: string;
  user_id: string;
  user_name: string;
  role: RoleCode;
  period: string;
  visits_completed: number;
  visits_on_time_pct: number;
  avg_customer_rating: number;
  overall_score: number; // 0 - 5.0
  hr_comments: string;
  status: 'draft' | 'finalized';
  reviewed_by?: string;
  created_at: string;
}

export interface EmployeeDue {
  id: string;
  user_id: string;
  user_name: string;
  due_type: 'commission' | 'bonus' | 'side_hustle' | 'overtime';
  source_subscription_id?: string;
  amount: number;
  status: 'pending' | 'approved' | 'paid';
  approved_by?: string;
  paid_at?: string;
  created_at: string;
}

// Point 16: Assets & Custody
export interface AssetRecord {
  id: string;
  asset_code: string;
  name_ar: string;
  category: 'vehicle' | 'specialized_tool' | 'testing_device' | 'safety_gear';
  custody_type: 'warehouse' | 'team' | 'technician' | 'retired';
  custody_team_name?: string;
  custody_leader_name?: string;
  custody_technician_name?: string;
  custody_since?: string;
  condition: 'excellent' | 'good' | 'fair' | 'needs_repair';
  value_sar: number;
}

// Point 13: Live Technician GPS Location & Dispatch Suggestions
export interface TechnicianLiveLocation {
  technician_id: string;
  name: string;
  team_name: string;
  department_id: DepartmentId;
  latitude: number;
  longitude: number;
  active_tasks_count: number;
  rating: number;
  vehicle_plate?: string;
  last_updated: string;
}

export interface DispatchSuggestion {
  technician_id: string;
  technician_name: string;
  team_name: string;
  distance_km: number;
  estimated_arrival_minutes: number;
  current_workload: number;
  score: number; // 0 - 100
  rating: number;
}

// Point 17: Subscriber Density Cluster
export interface SubscriberDensityPoint {
  client_id: string;
  client_name: string;
  facility_type: FacilityType;
  commercial_subtype_name: string;
  latitude: number;
  longitude: number;
  distance_km: number;
  is_active_subscriber: boolean;
  annual_contract_value: number;
  services_count: number;
}

export interface SequenceRecord {
  scope: string;
  year: number;
  current_value: number;
  updated_at: string;
}

export interface JobLockRecord {
  job_name: string;
  locked_by: string;
  locked_at: string;
  locked_until: string;
  heartbeat_at: string;
  is_active: boolean;
}

export interface RefreshTokenRecord {
  id: string;
  jti: string;
  user_id: string;
  token_hash: string; // SHA-256
  device_fingerprint: string;
  ip_address: string;
  expires_at: string;
  created_at: string;
}
