import React, { useState } from 'react';
import { 
  Building2, 
  UserCircle2, 
  Bell, 
  PlusCircle, 
  Layers, 
  CheckCircle2, 
  Database, 
  Users,
  Sparkles
} from 'lucide-react';
import { RoleCode } from '../types';
import { ROLES_CATALOG } from '../data/initialData';
import { storageService } from '../services/storageService';

interface NavbarProps {
  currentRole: RoleCode;
  onRoleChange: (role: RoleCode) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenNewLeadModal: () => void;
  onOpenSimulator: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onRoleChange,
  activeTab,
  onTabChange,
  onOpenNewLeadModal,
  onOpenSimulator,
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const notifications = storageService.getNotifications();
  const unreadNotifs = notifications.filter((n) => n.status !== 'read');
  const activeRoleDef = ROLES_CATALOG.find((r) => r.code === currentRole);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Strictly compliant Top Bar Contract: 3 zones separated by gap-8 */}
        <div className="flex items-center justify-between gap-8 h-16">
          
          {/* Zone 1: Brand title, one line wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-900 via-amber-900 to-amber-600 flex items-center justify-center text-white shadow-sm">
              <Building2 className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap">
                منصة هامة
              </span>
              <span className="text-xs text-slate-500 block leading-none font-medium">
                نظام التشغيل والتسويق التجاري
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-5 text-xs lg:text-sm font-medium text-slate-600">
            <button
              onClick={() => onTabChange('role_landing')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 flex items-center gap-1 ${
                activeTab === 'role_landing' ? 'border-amber-600 text-slate-900 font-bold' : 'border-transparent text-amber-900 bg-amber-50/70 px-2 rounded-md'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>لوحتي الخاصة</span>
            </button>
            <button
              onClick={() => onTabChange('marketing')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                activeTab === 'marketing' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              التسويق والعملاء
            </button>
            <button
              onClick={() => onTabChange('visits')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                activeTab === 'visits' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              الزيارات والمعاينة
            </button>
            <button
              onClick={() => onTabChange('quotes_subs')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                activeTab === 'quotes_subs' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              العروض والاشتراكات
            </button>
            <button
              onClick={() => onTabChange('hr_finance')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                activeTab === 'hr_finance' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              الموارد والمالية
            </button>
            <button
              onClick={() => onTabChange('inventory')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                activeTab === 'inventory' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              المخزون وQR
            </button>
            <button
              onClick={() => onTabChange('reports')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 ${
                activeTab === 'reports' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent'
              }`}
            >
              مؤشرات الأداء
            </button>
            <button
              onClick={() => onTabChange('database_fixes')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 flex items-center gap-1 ${
                activeTab === 'database_fixes' ? 'border-amber-600 text-slate-900 font-semibold' : 'border-transparent text-slate-500'
              }`}
            >
              <Database className="w-3.5 h-3.5 text-amber-600" />
              <span>الإصلاحات</span>
            </button>
          </nav>

          {/* Zone 3: Actions & Role switcher */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Interactive 6-Stage Simulator button */}
            <button
              onClick={onOpenSimulator}
              className="hidden lg:flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-xs"
              title="تجربة دورة العميل المتكاملة (6 مراحل من التسويق إلى التفعيل)"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>محاكي دورة العميل</span>
            </button>

            {/* Notification bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotifMenu(!showNotifMenu)}
                className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                aria-label="الإشعارات"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifs.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-600 rounded-full ring-2 ring-white"></span>
                )}
              </button>

              {showNotifMenu && (
                <div className="absolute left-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">سجل إشعارات النظام</span>
                    <span className="text-[11px] text-slate-500">{notifications.length} إشعار</span>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-xs text-center text-slate-400">لا توجد إشعارات جديدة</div>
                    ) : (
                      notifications.slice(0, 5).map((n) => (
                        <div key={n.id} className="p-3 text-right hover:bg-slate-50">
                          <p className="text-xs font-semibold text-slate-800">{n.subject}</p>
                          <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">{n.message}</p>
                          <span className="text-[10px] text-slate-400 mt-1 block tabular-nums">{n.created_at}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Role switcher dropdown (17 roles) */}
            <div className="relative">
              <button
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors whitespace-nowrap"
              >
                <UserCircle2 className="w-4 h-4 text-slate-500" />
                <span className="max-w-[130px] truncate">{activeRoleDef?.title_ar || currentRole}</span>
              </button>

              {showRoleMenu && (
                <div className="absolute left-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 max-h-96 overflow-y-auto">
                  <div className="px-4 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    تبديل الدور (الهيكل التنظيمي 19 دوراً)
                  </div>
                  {ROLES_CATALOG.map((role) => (
                    <button
                      key={role.code}
                      onClick={() => {
                        onRoleChange(role.code);
                        setShowRoleMenu(false);
                      }}
                      className={`w-full text-right px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${
                        currentRole === role.code ? 'bg-amber-50/70 text-amber-900 font-semibold' : 'text-slate-700'
                      }`}
                    >
                      <div>
                        <div className="font-medium">{role.title_ar}</div>
                        <div className="text-[10px] text-slate-400 font-mono">Level {role.level} · {role.code}</div>
                      </div>
                      {currentRole === role.code && (
                        <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Primary Action Button: New Lead */}
            <button
              onClick={onOpenNewLeadModal}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-sm whitespace-nowrap shrink-0 active:scale-98"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <span>عميل جديد (المسوق)</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
