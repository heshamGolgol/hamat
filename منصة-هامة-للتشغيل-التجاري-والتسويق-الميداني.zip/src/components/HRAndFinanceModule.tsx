import React, { useState } from 'react';
import { 
  Users, 
  DollarSign, 
  Award, 
  Briefcase, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  AlertCircle, 
  Layers, 
  Wrench, 
  Plus, 
  FileText,
  TrendingUp,
  Percent,
  Cpu,
  PackageCheck,
  Check
} from 'lucide-react';
import { storageService } from '../services/storageService';

export const HRAndFinanceModule: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'reviews' | 'dues' | 'custody' | 'activations'>('reviews');
  const [successMsg, setSuccessMsg] = useState<string>('');

  const reviews = storageService.getPerformanceReviews();
  const dues = storageService.getEmployeeDues();
  const assets = storageService.getAssets();
  const activations = storageService.getMarketingActivations();

  const handlePayDue = (dueId: string) => {
    // In our storageService, update the due status
    const allDues = storageService.getEmployeeDues();
    const d = allDues.find((x) => x.id === dueId);
    if (d) {
      d.status = 'paid';
      d.paid_at = new Date().toISOString().replace('T', ' ').substring(0, 19);
      setSuccessMsg(`تم صرف مستحق ${d.user_name} بقيمة ${d.amount.toLocaleString()} ريال بنجاح!`);
      setTimeout(() => setSuccessMsg(''), 4000);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-900">
              الموارد البشرية، المالية، وعُهد الفرق (HR & Finance Governance)
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-900 border border-purple-200">
              تقييم الأداء + العُهد + العمولات
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            إدارة تقييمات الموظفين وتعليقات الموارد البشرية، مستحقات العمولات، وعُهد المعدات مع قادة الفرق
          </p>
        </div>

        {/* Sub-tabs */}
        <div className="flex p-1 bg-slate-100 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveSubTab('reviews')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeSubTab === 'reviews' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تقييمات الأداء ({reviews.length})
          </button>
          <button
            onClick={() => setActiveSubTab('dues')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeSubTab === 'dues' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            مستحقات الموظفين والعمولات ({dues.length})
          </button>
          <button
            onClick={() => setActiveSubTab('custody')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeSubTab === 'custody' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            عُهد المعدات والأصول ({assets.length})
          </button>
          <button
            onClick={() => setActiveSubTab('activations')}
            className={`px-3.5 py-1.5 rounded-lg transition-all ${
              activeSubTab === 'activations' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تسويق الموظفين ({activations.length})
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl flex items-center justify-between text-xs font-bold animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg('')} className="text-emerald-700">✕</button>
        </div>
      )}

      {/* Sub-Tab 1: Performance Reviews (Point 9) */}
      {activeSubTab === 'reviews' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reviews.map((rev) => (
              <div key={rev.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
                <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{rev.user_name}</h3>
                    <span className="text-slate-400 text-[11px] font-mono">{rev.role} · {rev.period}</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-purple-50 px-3 py-1 rounded-lg border border-purple-200">
                    <Award className="w-4 h-4 text-purple-700" />
                    <span className="font-mono font-bold text-purple-900 text-sm">{rev.overall_score} / 5.0</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-lg text-center">
                  <div>
                    <span className="text-slate-400 text-[10px] block">المهام المنجزة</span>
                    <span className="font-bold font-mono text-slate-800">{rev.visits_completed}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">دقة المواعيد</span>
                    <span className="font-bold font-mono text-emerald-700">{rev.visits_on_time_pct}%</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">رضا العملاء</span>
                    <span className="font-bold font-mono text-amber-900">{rev.avg_customer_rating} / 5.0</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="font-semibold text-slate-700 text-[11px]">ملاحظات مدير الموارد البشرية (HR_MGR):</span>
                  <p className="text-[11px] text-slate-600 bg-purple-50/40 p-2.5 rounded-lg border border-purple-100 leading-relaxed">
                    "{rev.hr_comments}"
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[10px] text-slate-400">
                  <span>تم التقييم بواسطة: {rev.reviewed_by}</span>
                  <span className="font-mono">{rev.created_at.substring(0, 10)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Employee Dues & Commissions (Point 9 & Point 8) */}
      {activeSubTab === 'dues' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">
              سجل مستحقات الموظفين والعمولات التسويقية (employee_dues)
            </h3>
            <span className="text-xs text-slate-500">{dues.length} مستحق مالي</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-3 px-4">رقم السجل</th>
                  <th className="py-3 px-4">اسم الموظف</th>
                  <th className="py-3 px-4">نوع المستحق</th>
                  <th className="py-3 px-4">المبلغ المستحق</th>
                  <th className="py-3 px-4">حالة الصرف</th>
                  <th className="py-3 px-4">المعتمد</th>
                  <th className="py-3 px-4 text-center">إجراء الصرف</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dues.map((due) => (
                  <tr key={due.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">{due.id}</td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900">{due.user_name}</td>
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                        due.due_type === 'commission' ? 'bg-emerald-100 text-emerald-800' :
                        due.due_type === 'overtime' ? 'bg-sky-100 text-sky-800' : 'bg-slate-100 text-slate-800'
                      }`}>
                        {due.due_type === 'commission' ? 'عمولة تسويقية 5%' :
                         due.due_type === 'overtime' ? 'عمل إضافي' : 'راتب أساسي'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 tabular-nums">
                      {due.amount.toLocaleString()} ريال
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        due.status === 'paid' ? 'bg-emerald-100 text-emerald-800' :
                        due.status === 'approved' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {due.status === 'paid' ? 'تم التحويل والصرف' :
                         due.status === 'approved' ? 'معتمد للصرف' : 'معلق'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 text-[11px]">{due.approved_by || '—'}</td>
                    <td className="py-3.5 px-4 text-center">
                      {due.status !== 'paid' ? (
                        <button
                          onClick={() => handlePayDue(due.id)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] shadow-2xs transition-colors"
                        >
                          تحويل الحساب
                        </button>
                      ) : (
                        <span className="text-[11px] text-emerald-700 font-bold">مصروف</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Assets Custody (Point 16) */}
      {activeSubTab === 'custody' && (
        <div className="space-y-4">
          <div className="bg-slate-900 text-white p-4 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <PackageCheck className="w-4 h-4 text-amber-400" />
              <span>
                <strong>سجل عُهد المعدات والأجهزة (Asset Custody Register):</strong> توثيق دقيق لما إذا كانت العهدة بالمستودع المركزي أو بعهدة فريق ميداني مع قائد الفريق (Team Leader).
              </span>
            </div>
            <span className="font-mono font-bold text-amber-400">{assets.length} عُهد مسجلة</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assets.map((asset) => (
              <div key={asset.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
                <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{asset.name_ar}</h3>
                    <span className="font-mono text-slate-400 text-[10px]">كود الأصل: {asset.asset_code}</span>
                  </div>
                  <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold ${
                    asset.custody_type === 'team'
                      ? 'bg-sky-100 text-sky-800 border border-sky-200'
                      : 'bg-slate-100 text-slate-800 border border-slate-200'
                  }`}>
                    {asset.custody_type === 'team' ? 'عهدة فريق ميداني' : 'بالمستودع المركزي'}
                  </span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2">
                  {asset.custody_type === 'team' ? (
                    <>
                      <div className="flex justify-between">
                        <span className="text-slate-500">الفريق الحائز للعهدة:</span>
                        <span className="font-bold text-slate-900">{asset.custody_team_name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">قائد الفريق المسؤول (Team Leader):</span>
                        <span className="font-semibold text-slate-800">{asset.custody_leader_name}</span>
                      </div>
                    </>
                  ) : (
                    <div className="flex justify-between">
                      <span className="text-slate-500">الموقع المخزني:</span>
                      <span className="font-bold text-slate-900">المستودع الرئيسي - الرياض</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-1 border-t border-slate-200/60">
                    <span className="text-slate-500">الحالة الفنية:</span>
                    <span className="text-emerald-700 font-bold">{asset.condition === 'excellent' ? 'ممتازة ومعايرة' : 'جيدة'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                  <span>تاريخ الفحص والعهدة: {asset.custody_since || '2026-01-15'}</span>
                  <span>القيمة التقديرية: {asset.value_sar.toLocaleString()} ريال</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub-Tab 4: Employee Marketing Activations (Point 8) */}
      {activeSubTab === 'activations' && (
        <div className="space-y-4">
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-emerald-950 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-700" />
              <span>
                <strong>برنامج المسوق الإضافي لجميع موظفي هامة (Employee Side-Hustle):</strong> تمكين الفنيين والإداريين من إحالة عملاء جدد وكسب عمولة 5% على قيمة العقد السنوي.
              </span>
            </div>
            <span className="font-mono font-bold text-emerald-900">{activations.length} موظف مشترك</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activations.map((act) => (
              <div key={act.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
                <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{act.user_name}</h3>
                    <span className="text-slate-400 text-[11px]">القسم: {act.user_department}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    act.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {act.is_active ? 'وضع التسويق نشط' : 'غير مفعل'}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                  <div>
                    <span className="text-slate-400 text-[10px] block">إجمالي الإحالات</span>
                    <span className="font-bold font-mono text-slate-800 text-sm">{act.total_leads_submitted}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">نسبة العمولة</span>
                    <span className="font-bold font-mono text-indigo-700 text-sm">{act.commission_rate}%</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">العمولة المكتسبة</span>
                    <span className="font-bold font-mono text-emerald-700 text-sm">{act.total_commissions_earned.toLocaleString()} ريال</span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100">
                  تاريخ الاشتراك بالبرنامج: {act.activated_at}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
