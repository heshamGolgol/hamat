import React from 'react';
import { 
  TrendingUp, 
  Users, 
  Building2, 
  DollarSign, 
  Percent, 
  BarChart3, 
  PieChart, 
  CheckCircle2, 
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { storageService } from '../services/storageService';

export const ReportsModule: React.FC = () => {
  const marketerStats = storageService.getMarketerPerformanceView();
  const facilityStats = storageService.getClientsByFacilityTypeView();
  const funnelStats = storageService.getLeadFunnelView();
  const subscriptions = storageService.getSubscriptions();

  const totalContractRevenue = subscriptions.reduce((sum, s) => sum + s.total_annual_value, 0);
  const totalServiceRequests = storageService.getServiceRequests().length;
  const activatedRequests = storageService.getServiceRequests().filter((r) => r.status === 'activated').length;
  const overallConversionRate = totalServiceRequests > 0 
    ? Math.round((activatedRequests / totalServiceRequests) * 100) 
    : 0;

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900">
            لوحة مؤشرات الأداء والتقارير التنفيذية (SQL Views Analytics)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            مؤشرات مستخرجة مباشرة من استعلامات وقواعد البيانات (v_marketer_performance · v_clients_by_facility_type · v_lead_funnel)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-slate-400">تحديث لحظي تلقائي</span>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 text-right space-y-1">
          <span className="text-slate-500 text-[11px] font-medium">إجمالي عوائد العقود السنوية</span>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {totalContractRevenue.toLocaleString()} <span className="text-xs font-sans text-slate-500">ريال</span>
          </div>
          <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3" />
            <span>عقود معتمدة نشطة</span>
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 text-right space-y-1">
          <span className="text-slate-500 text-[11px] font-medium">إجمالي طلبات الخدمات المسجلة</span>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {totalServiceRequests} <span className="text-xs font-sans text-slate-500">طلب</span>
          </div>
          <span className="text-[10px] text-slate-400">مرفوعة عبر المسوقين المعتمدين</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 text-right space-y-1">
          <span className="text-slate-500 text-[11px] font-medium">نسبة التحويل الإجمالية (Conversion)</span>
          <div className="text-xl font-bold text-amber-900 font-mono tabular-nums">
            {overallConversionRate}%
          </div>
          <span className="text-[10px] text-amber-700 font-semibold">تحول الطلبات لعقود مفعلة</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 text-right space-y-1">
          <span className="text-slate-500 text-[11px] font-medium">المنشآت المسجلة بالنظام</span>
          <div className="text-xl font-bold text-slate-900 font-mono tabular-nums">
            {storageService.getFacilities().length} <span className="text-xs font-sans text-slate-500">منشأة</span>
          </div>
          <span className="text-[10px] text-slate-400">حكومية وتجارية وسكنية</span>
        </div>
      </div>

      {/* View 1: Marketer Performance View */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">
              تقرير أداء المسوقين الميدانيين (v_marketer_performance)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              احتساب العملاء المسجلين، عدد الخدمات، وقيمة الإيرادات المحققة ونسبة النجاح لكل مسوق
            </p>
          </div>
          <span className="font-mono text-xs text-slate-400 font-semibold">GROUP BY marketer_id</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200 font-semibold">
              <tr>
                <th className="py-3 px-4">اسم المسوق</th>
                <th className="py-3 px-4 text-center">العملاء المسجلين</th>
                <th className="py-3 px-4 text-center">طلبات الخدمات</th>
                <th className="py-3 px-4 text-center">الخدمات المفعلة</th>
                <th className="py-3 px-4">إجمالي العوائد المحققة</th>
                <th className="py-3 px-4">معدل التحويل (Conversion Rate)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {marketerStats.map((stat) => (
                <tr key={stat.marketer_id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900">{stat.marketer_name}</td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-slate-800 tabular-nums">
                    {stat.clients_count}
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-slate-700 tabular-nums">
                    {stat.service_requests}
                  </td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-emerald-700 tabular-nums">
                    {stat.activated_services}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                    {stat.total_revenue.toLocaleString()} ريال
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-600 h-full rounded-full"
                          style={{ width: `${stat.conversion_rate_pct}%` }}
                        ></div>
                      </div>
                      <span className="font-mono font-bold text-slate-800 tabular-nums text-[11px] w-9">
                        {stat.conversion_rate_pct}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grid: Lead Funnel & Facility Type Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* View 2: Lead Funnel (v_lead_funnel) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                مسار تحويل الطلبات (v_lead_funnel)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">توزيع مراحل الطلبات عبر مسار البيع</p>
            </div>
            <span className="font-mono text-[11px] text-slate-400">Pipeline</span>
          </div>

          <div className="space-y-3">
            {funnelStats.map((item) => {
              const labelAr = 
                item.status === 'submitted' ? 'مقدم جديد (Submitted)' :
                item.status === 'under_review' ? 'قيد المعاينة (Under Review)' :
                item.status === 'quoted' ? 'تم تقديم العرض (Quoted)' :
                item.status === 'activated' ? 'عقد مفعل (Activated)' :
                item.status === 'approved' ? 'معتمد (Approved)' : 'مرفوض (Rejected)';

              return (
                <div key={item.status} className="space-y-1">
                  <div className="flex justify-between font-medium text-slate-700">
                    <span>{labelAr}</span>
                    <span className="font-mono font-bold tabular-nums text-slate-900">
                      {item.count} طلب ({item.pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        item.status === 'activated' ? 'bg-emerald-600' :
                        item.status === 'quoted' ? 'bg-purple-600' :
                        item.status === 'under_review' ? 'bg-sky-600' : 'bg-amber-600'
                      }`}
                      style={{ width: `${item.pct}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* View 3: Clients by Facility Type (v_clients_by_facility_type) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                توزيع العملاء حسب نوع المنشأة (v_clients_by_facility_type)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">تصنيف المنشآت والأنشطة والخدمات المرتبطة</p>
            </div>
            <span className="font-mono text-[11px] text-slate-400">Facilities</span>
          </div>

          <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden bg-slate-50/40">
            {facilityStats.map((fac, idx) => (
              <div key={idx} className="p-3 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900">{fac.subtype_name}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    القطاع: {fac.facility_type === 'commercial' ? 'تجاري' : fac.facility_type === 'government' ? 'حكومي' : 'سكني'}
                  </div>
                </div>
                <div className="text-left font-mono">
                  <span className="font-bold text-slate-900 tabular-nums">{fac.count} منشأة</span>
                  <span className="text-[10px] text-slate-400 block tabular-nums">{fac.requests_count} طلب خدمة</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
