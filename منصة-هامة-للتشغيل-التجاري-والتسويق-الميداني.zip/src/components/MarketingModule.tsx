import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  Calendar, 
  Clock, 
  Phone, 
  User, 
  FileText, 
  ExternalLink, 
  CheckCircle2, 
  Plus, 
  Search, 
  Filter,
  Check,
  ChevronDown,
  Sparkles,
  Zap,
  TrendingUp,
  Radar,
  ArrowRight,
  ShieldCheck,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { ClientFacility, ClientServiceRequest, MarketingVisitAppointment } from '../types';
import { storageService } from '../services/storageService';
import { DEPARTMENTS } from '../data/initialData';

interface MarketingModuleProps {
  onOpenNewLeadModal: () => void;
}

export const MarketingModule: React.FC<MarketingModuleProps> = ({ onOpenNewLeadModal }) => {
  const [activeSubTab, setActiveSubTab] = useState<'facilities' | 'drafts' | 'requests' | 'appointments' | 'referrals' | 'density'>('facilities');
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [densityRadius, setDensityRadius] = useState<number>(5);
  const [toastMsg, setToastMsg] = useState<string>('');

  const facilities = storageService.getFacilities();
  const serviceRequests = storageService.getServiceRequests();
  const appointments = storageService.getAppointments();
  const subtypes = storageService.getFacilitySubtypes();
  const referralTracking = storageService.getMarketerLeadTrackingView();
  const densityClusters = storageService.getSubscriberDensity(densityRadius);
  const activations = storageService.getMarketingActivations();

  // Find or default current logged user activation for side-hustle
  const currentActivation = activations[0] || {
    id: 'act_usr_mkt_1',
    user_id: 'usr_mkt_1',
    user_name: 'سلطان بن فهد',
    user_department: 'التسويق الميداني',
    is_active: true,
    commission_rate: 5.0,
    total_leads_submitted: 14,
    total_commissions_earned: 14200,
    activated_at: '2026-01-10 09:00:00'
  };

  // Draft facilities (Point 7)
  const draftFacilities = facilities.filter((f) => f.is_draft || f.lead_status === 'draft');
  const activeFacilities = facilities.filter((f) => !f.is_draft && f.lead_status !== 'draft');

  // Filter active facilities
  const filteredFacilities = activeFacilities.filter((fac) => {
    const matchesType = filterType === 'all' || fac.facility_type === filterType;
    const matchesSearch = fac.facility_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          fac.owner_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          fac.address_text.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const handleConfirmAppointment = (appId: string) => {
    storageService.confirmAppointment(appId, 'مدير التسويق (MARKETING_MGR)');
    setToastMsg('تم تأكيد الموعد وإسناد الزيارة التشغيلية للفريق بنجاح!');
    setTimeout(() => setToastMsg(''), 4000);
  };

  const handleSubmitDraft = (facilityId: string) => {
    const fac = facilities.find((f) => f.id === facilityId);
    if (!fac) return;
    storageService.submitDraftLead(facilityId, {
      owner_name: fac.owner_name.includes('مسودة') ? 'محمد العبدالله' : fac.owner_name,
      owner_phone: fac.owner_phone === '0500000000' ? '0505123987' : fac.owner_phone,
      marketer_estimated_value: fac.marketer_estimated_value || 28000,
      marketer_pricing_notes: 'تمت المراجعة والاعتماد بواسطة مدير التسويق والمبيعات'
    });
    setToastMsg(`تم استكمال المسودة (${fac.facility_name}) وتحويلها لعميل معتمد وجدولة المعاينة!`);
    setTimeout(() => setToastMsg(''), 4000);
  };

  const handleToggleSideHustle = () => {
    storageService.toggleMarketingMode(currentActivation.user_id, currentActivation.user_name, currentActivation.user_department);
    setToastMsg('تم تحديث حالة وضع التسويق الإضافي بنجاح!');
    setTimeout(() => setToastMsg(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Actions with Side-Hustle Widget (Point 8) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-slate-900">
                منظومة التسويق الميداني والعملاء (Marketing Ecosystem)
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                تحديث شامل 2026
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              إدارة المنشآت، المسودات، استكمال العقود، تتبع خط الإحالات، وخريطة الكثافة الجغرافية
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Side-Hustle Mode Toggle Button (Point 8) */}
            <button
              onClick={handleToggleSideHustle}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                currentActivation.is_active
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
              }`}
              title="تفعيل وضع التسويق الإضافي لجميع موظفي الشركة بعمولة 5% على الصفقات المغلقة"
            >
              <Zap className={`w-3.5 h-3.5 ${currentActivation.is_active ? 'text-emerald-600 fill-emerald-600' : 'text-slate-400'}`} />
              <span>وضع التسويق الإضافي: {currentActivation.is_active ? 'نشط (عمولة 5%)' : 'معطل'}</span>
            </button>

            <button
              onClick={onOpenNewLeadModal}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs active:scale-98"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>تسجيل عميل جديد</span>
            </button>
          </div>
        </div>

        {/* Sub Tabs Bar */}
        <div className="flex overflow-x-auto pb-1 gap-1 border-t border-slate-100 pt-3 text-xs font-medium">
          <button
            onClick={() => setActiveSubTab('facilities')}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeSubTab === 'facilities' ? 'bg-slate-900 text-white font-bold shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            المنشآت المعتمدة ({activeFacilities.length})
          </button>
          
          {/* Point 7: Drafts Tab */}
          <button
            onClick={() => setActiveSubTab('drafts')}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeSubTab === 'drafts' ? 'bg-amber-600 text-white font-bold shadow-xs' : 'text-amber-800 bg-amber-50 hover:bg-amber-100'
            }`}
          >
            <span>مسودات بانتظار الإكمال ({draftFacilities.length})</span>
            {draftFacilities.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('requests')}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeSubTab === 'requests' ? 'bg-slate-900 text-white font-bold shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            طلبات الخدمات ({serviceRequests.length})
          </button>

          <button
            onClick={() => setActiveSubTab('appointments')}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all ${
              activeSubTab === 'appointments' ? 'bg-slate-900 text-white font-bold shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            مواعيد المعاينة ({appointments.length})
          </button>

          {/* Point 12: Referrals Pipeline View */}
          <button
            onClick={() => setActiveSubTab('referrals')}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeSubTab === 'referrals' ? 'bg-sky-700 text-white font-bold shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-sky-500" />
            <span>تتبع صفقات المسوق ({referralTracking.length})</span>
          </button>

          {/* Point 17: Subscriber Density Radar */}
          <button
            onClick={() => setActiveSubTab('density')}
            className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeSubTab === 'density' ? 'bg-indigo-700 text-white font-bold shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Radar className="w-3.5 h-3.5 text-indigo-500" />
            <span>رادار كثافة المشتركين</span>
          </button>
        </div>
      </div>

      {/* Toast Alert */}
      {toastMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{toastMsg}</span>
          </div>
          <button onClick={() => setToastMsg('')} className="text-xs text-emerald-700">✕</button>
        </div>
      )}

      {/* Sub-Tab 1: Facilities */}
      {activeSubTab === 'facilities' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                placeholder="بحث باسم المنشأة، المالك، العنوان..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-9 pl-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              />
            </div>

            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-slate-500 text-[11px]">النوع:</span>
              {[
                { id: 'all', label: 'الكل' },
                { id: 'commercial', label: 'تجاري' },
                { id: 'government', label: 'حكومي' },
                { id: 'residential', label: 'سكني' },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setFilterType(t.id)}
                  className={`px-3 py-1 rounded-lg border transition-colors ${
                    filterType === t.id
                      ? 'bg-slate-900 text-white border-slate-900 font-medium'
                      : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFacilities.map((facility) => {
              const subtypeObj = subtypes.find((st) => st.id === facility.commercial_subtype);
              const subtypeLabel = facility.facility_type === 'commercial' 
                ? (subtypeObj?.name_ar || facility.commercial_subtype_other || 'تجاري عام')
                : facility.facility_type === 'government' ? 'منشأة حكومية' : 'مجمع سكني';

              const facRequests = serviceRequests.filter((r) => r.facility_id === facility.id);
              const facAppointments = appointments.filter((a) => a.facility_id === facility.id);

              return (
                <div
                  key={facility.id}
                  className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:border-slate-300 transition-all flex flex-col justify-between shadow-2xs"
                >
                  <div className="relative h-44 bg-slate-100 overflow-hidden">
                    <img
                      src={facility.site_photo_url}
                      alt={facility.facility_name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                    />
                    <div className="absolute top-2.5 right-2.5 px-2.5 py-1 rounded-md bg-slate-900/80 backdrop-blur-xs text-white text-[11px] font-medium">
                      {subtypeLabel}
                    </div>
                    {facility.marketer_estimated_value && (
                      <div className="absolute bottom-2.5 left-2.5 px-2.5 py-1 rounded-md bg-amber-500/90 backdrop-blur-xs text-white text-[10px] font-bold">
                        تقدير: {facility.marketer_estimated_value.toLocaleString()} ريال
                      </div>
                    )}
                  </div>

                  <div className="p-4 space-y-3 flex-1 text-right text-xs">
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm line-clamp-1">
                        {facility.facility_name}
                      </h3>
                      <p className="text-slate-500 text-[11px] mt-1 flex items-start gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{facility.address_text}</span>
                      </p>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-lg space-y-1.5 text-[11px] border border-slate-100">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">المالك:</span>
                        <span className="font-medium text-slate-800">{facility.owner_name}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">هاتف التواصل:</span>
                        <span className="font-mono text-slate-700 dir-ltr">{facility.owner_phone}</span>
                      </div>
                      {facility.delegate_name && (
                        <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                          <span className="text-slate-500">المندوب:</span>
                          <span className="text-slate-700">{facility.delegate_name}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-2 text-[11px] text-slate-500 border-t border-slate-100">
                      <span>الخدمات المطلوبة: <strong className="text-slate-900">{facRequests.length}</strong></span>
                      <span>المواعيد: <strong className="text-slate-900">{facAppointments.length}</strong></span>
                    </div>
                  </div>

                  <div className="px-4 py-2.5 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between text-[11px]">
                    <a
                      href={facility.map_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-amber-700 hover:text-amber-800 font-medium flex items-center gap-1"
                    >
                      <span>عرض الخريطة</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <span className="text-slate-400 tabular-nums">{facility.created_at.substring(0, 10)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Drafts Pending Review & Completion (Point 7) */}
      {activeSubTab === 'drafts' && (
        <div className="space-y-4">
          <div className="bg-amber-50/80 border border-amber-200 p-4 rounded-xl text-amber-900 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>مسودات المسوقين:</strong> يتيح هذا القسم لمدير التسويق مراجعة بيانات المسودات غير المكتملة وتعديل القيمة التقديرية واعتمادها لإطلاق موعد المعاينة.
              </span>
            </div>
            <span className="font-bold text-amber-900 font-mono text-sm">{draftFacilities.length} مسودة</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {draftFacilities.map((draft) => (
              <div key={draft.id} className="bg-white border-2 border-dashed border-amber-300 rounded-xl p-5 space-y-4 text-right text-xs">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-mono text-[10px] font-bold">
                      مسودة (Draft) #{draft.id}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm mt-1">{draft.facility_name}</h3>
                    <p className="text-slate-500 text-[11px] mt-0.5">{draft.address_text}</p>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">{draft.created_at.substring(0, 10)}</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg space-y-2 border border-slate-200">
                  <div className="flex justify-between">
                    <span className="text-slate-500">القيمة التقديرية للعقد:</span>
                    <span className="font-mono font-bold text-amber-900">
                      {draft.marketer_estimated_value?.toLocaleString() || 24000} ريال
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">ملاحظات التسعير:</span>
                    <span className="text-slate-700">{draft.marketer_pricing_notes || 'بانتظار دراسة مدير التسويق'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">هاتف المالك المسجل:</span>
                    <span className="font-mono text-slate-700">{draft.owner_phone}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <span className="text-slate-500 text-[11px]">المنشأة: {draft.facility_name}</span>
                  <button
                    onClick={() => handleSubmitDraft(draft.id)}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>استكمال واعتماد الطلب</span>
                  </button>
                </div>
              </div>
            ))}

            {draftFacilities.length === 0 && (
              <div className="col-span-2 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-400 text-xs">
                لا توجد مسودات معلقة حالياً. جميع إحالات المسوقين مكتملة ومعتمدة!
              </div>
            )}
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Service Requests */}
      {activeSubTab === 'requests' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">
              سجل طلبات الخدمات متعددة الأقسام (client_service_requests)
            </h3>
            <span className="text-xs text-slate-500">إجمالي {serviceRequests.length} طلب خدمة</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-3 px-4">رقم الطلب</th>
                  <th className="py-3 px-4">المنشأة</th>
                  <th className="py-3 px-4">القسم المختص</th>
                  <th className="py-3 px-4">الخدمة والتفاصيل</th>
                  <th className="py-3 px-4">المسوق</th>
                  <th className="py-3 px-4">الحالة</th>
                  <th className="py-3 px-4">تاريخ الرفع</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {serviceRequests.map((req) => {
                  const dept = DEPARTMENTS.find((d) => d.id === req.department_id);
                  return (
                    <tr key={req.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{req.request_number}</td>
                      <td className="py-3 px-4 font-medium text-slate-800">{req.client_name}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-800 border border-slate-200">
                          {dept?.name_ar || req.department_id}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{req.service_title_ar}</div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {JSON.stringify(req.service_details)}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-700">{req.marketer_name}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          req.status === 'activated'
                            ? 'bg-emerald-100 text-emerald-800'
                            : req.status === 'quoted'
                            ? 'bg-purple-100 text-purple-800'
                            : req.status === 'under_review'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {req.status === 'activated' ? 'مفعل بعقد' :
                           req.status === 'quoted' ? 'تم التسعير' :
                           req.status === 'under_review' ? 'قيد المعاينة' : 'مقدم جديد'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-500 tabular-nums">{req.created_at.substring(0, 16)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 4: Appointments */}
      {activeSubTab === 'appointments' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                مواعيد الزيارات والمعاينة الميدانية (marketing_visit_appointments)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                تأكيد الموعد يطلق Trigger أوتوماتيكي لتوليد زيارة تشغيلية بجدول `visits` بنوع `inspection`
              </p>
            </div>
            <span className="text-xs text-slate-500">{appointments.length} موعد</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-3 px-4">رقم الموعد</th>
                  <th className="py-3 px-4">المنشأة</th>
                  <th className="py-3 px-4">التاريخ والوقت</th>
                  <th className="py-3 px-4">المسوق</th>
                  <th className="py-3 px-4">الحالة</th>
                  <th className="py-3 px-4">زيارة التشغيل الناتجة</th>
                  <th className="py-3 px-4 text-center">إجراء المدير</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointments.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{app.appointment_number}</td>
                    <td className="py-3 px-4 font-medium text-slate-800">{app.facility_name}</td>
                    <td className="py-3 px-4 tabular-nums">
                      <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{app.requested_date}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{app.requested_time}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700">{app.marketer_name}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        app.status === 'confirmed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : app.status === 'completed'
                          ? 'bg-slate-100 text-slate-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {app.status === 'confirmed' ? 'معتمد ومجدول' :
                         app.status === 'completed' ? 'تمت الزيارة' : 'طلب جديد'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono">
                      {app.converted_visit_id ? (
                        <span className="text-emerald-700 font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>زيارة معاينة منشأة</span>
                        </span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {app.status === 'requested' ? (
                        <button
                          onClick={() => handleConfirmAppointment(app.id)}
                          className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold text-[11px] shadow-2xs transition-colors"
                        >
                          تأكيد الموعد وتوليد الزيارة
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">تم الاعتماد</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 5: Referrals Pipeline & Tracking (Point 12: v_marketer_lead_tracking) */}
      {activeSubTab === 'referrals' && (
        <div className="space-y-4">
          <div className="bg-sky-50 border border-sky-200 p-4 rounded-xl text-sky-950 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-sky-700 shrink-0" />
              <span>
                <strong>سجل تتبع صفقات وإحالات المسوق المباشر (v_marketer_lead_tracking):</strong> تتبع لحظي لمراحل الصفقات من المعاينة الفنية إلى إغلاق العقد واحتساب العمولة.
              </span>
            </div>
            <span className="font-bold text-sky-900">{referralTracking.length} صفقة قيد التتبع</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {referralTracking.map((lead) => (
              <div key={lead.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{lead.facility_name}</h3>
                    <p className="text-slate-500 text-[11px] mt-0.5">{lead.facility_address}</p>
                  </div>
                  <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                    العمولة: {lead.expected_commission.toLocaleString()} ريال (5%)
                  </span>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-slate-700">{lead.stage_label}</span>
                    <span className="font-mono text-slate-500 tabular-nums">{lead.progress_pct}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        lead.progress_pct === 100 ? 'bg-emerald-500' :
                        lead.progress_pct >= 75 ? 'bg-sky-500' :
                        lead.progress_pct >= 50 ? 'bg-amber-500' : 'bg-slate-400'
                      }`}
                      style={{ width: `${lead.progress_pct}%` }}
                    ></div>
                  </div>
                </div>

                {/* Details grid */}
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg text-[11px] border border-slate-100">
                  <div>
                    <span className="text-slate-400 block">القيمة المقدرة:</span>
                    <span className="font-mono font-semibold text-slate-800">{lead.estimated_value.toLocaleString()} ريال</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">حالة الطلب:</span>
                    <span className="font-semibold text-slate-800">
                      {lead.status === 'activated' ? 'مفعل ونشط' :
                       lead.status === 'quoted' ? 'تم التسعير' :
                       lead.status === 'under_review' ? 'قيد المعاينة' : 'مقدم جديد'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[10px] text-slate-400">
                  <span>المسوق: {lead.marketer_name}</span>
                  <span className="tabular-nums">{lead.submitted_at.substring(0, 10)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub-Tab 6: Subscriber Density Radar & Map (Point 17) */}
      {activeSubTab === 'density' && (
        <div className="space-y-4">
          <div className="bg-indigo-50 border border-indigo-200 p-4 rounded-xl text-indigo-950 text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Radar className="w-5 h-5 text-indigo-600 shrink-0" />
              <div>
                <strong className="block text-sm">رادار وخريطة كثافة المشتركين (Subscriber Density Radar)</strong>
                <span className="text-indigo-800 text-[11px]">
                  تحليل التوزيع الجغرافي للمشتركين والعقود النشطة لتوجيه المسوقين وفرق الصيانة السريعة
                </span>
              </div>
            </div>

            {/* Radius Selector: 1, 3, 5, 10 km */}
            <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-indigo-200 text-xs font-semibold">
              <span className="text-slate-500 px-2 text-[11px]">نطاق الرادار:</span>
              {[1, 3, 5, 10].map((r) => (
                <button
                  key={r}
                  onClick={() => setDensityRadius(r)}
                  className={`px-3 py-1 rounded transition-colors ${
                    densityRadius === r ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {r} كم
                </button>
              ))}
            </div>
          </div>

          {/* Density Summary Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 text-right">
              <span className="text-slate-500 text-[11px] block">المشتركون النشطون بالنطاق</span>
              <span className="font-mono font-bold text-lg text-emerald-700">{densityClusters.totalSubscribers} مشترك</span>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 text-right">
              <span className="text-slate-500 text-[11px] block">الفرص التسويقية المحتملة</span>
              <span className="font-mono font-bold text-lg text-amber-800">{densityClusters.totalProspects} منشأة</span>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 text-right">
              <span className="text-slate-500 text-[11px] block">إجمالي القيمة التعاقدية في {densityRadius} كم</span>
              <span className="font-mono font-bold text-lg text-indigo-900">{densityClusters.totalRevenueInRadius.toLocaleString()} ريال</span>
            </div>
          </div>

          {/* Density Points Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {densityClusters.points.map((point) => (
              <div
                key={point.client_id}
                className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs hover:border-indigo-300 transition-all text-right text-xs"
              >
                <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{point.client_name}</h3>
                    <span className="text-slate-400 font-mono text-[10px]">
                      {point.latitude.toFixed(4)}, {point.longitude.toFixed(4)}
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    point.is_active_subscriber
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-amber-100 text-amber-800 border border-amber-200'
                  }`}>
                    {point.is_active_subscriber ? 'مشترك نشط' : 'فرصة تسويقية'}
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">نوع النشاط:</span>
                    <span className="font-bold text-slate-900">{point.commercial_subtype_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">المسافة عن المركز:</span>
                    <span className="font-mono font-bold text-indigo-700">{point.distance_km} كم</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">القيمة السنوية:</span>
                    <span className="font-mono font-bold text-slate-900">
                      {point.annual_contract_value > 0 ? `${point.annual_contract_value.toLocaleString()} ريال` : 'قيد التسعير'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex justify-between">
                  <span>عدد الخدمات المطلوبة:</span>
                  <span className="font-mono font-bold text-slate-800">{point.services_count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
