import React from 'react';
import { 
  Building2, 
  MapPin, 
  Calendar, 
  Clock, 
  DollarSign, 
  CheckCircle2, 
  Users, 
  Award, 
  ShieldCheck, 
  TrendingUp, 
  Gift, 
  AlertTriangle, 
  Navigation, 
  Timer, 
  QrCode, 
  Briefcase, 
  Sparkles, 
  ChevronRight,
  Plus,
  Play,
  Square,
  PackageCheck,
  FileText
} from 'lucide-react';
import { RoleCode } from '../types';
import { ROLES_CATALOG } from '../data/initialData';
import { storageService } from '../services/storageService';

interface RoleLandingViewProps {
  currentRole: RoleCode;
  onNavigateTab: (tab: string) => void;
  onOpenNewLeadModal: () => void;
  onOpenSimulator: () => void;
}

export const RoleLandingView: React.FC<RoleLandingViewProps> = ({
  currentRole,
  onNavigateTab,
  onOpenNewLeadModal,
  onOpenSimulator,
}) => {
  const roleDef = ROLES_CATALOG.find((r) => r.code === currentRole);
  const landingConfig = roleDef?.landing_page || {
    title_ar: roleDef?.title_ar || 'لوحة التحكم',
    description_ar: 'الواجهة المخصصة لإنجاز المهام ومتابعة المؤشرات الحيوية للدور',
    primary_kpis: [],
    recommended_actions: [],
  };

  const facilities = storageService.getFacilities();
  const serviceRequests = storageService.getServiceRequests();
  const visits = storageService.getVisits();
  const subscriptions = storageService.getSubscriptions();
  const quotes = storageService.getQuotes();
  const referrals = storageService.getMarketerLeadTrackingView();
  const loyaltyWallets = storageService.getLoyaltyWallets();
  const assets = storageService.getAssets();
  const dues = storageService.getEmployeeDues();
  const reviews = storageService.getPerformanceReviews();

  // Dynamic role stats calculations
  const pendingFinanceSubs = subscriptions.filter((s) => s.status === 'pending_finance');
  const activeSubs = subscriptions.filter((s) => s.status === 'active');
  const draftFacilities = facilities.filter((f) => f.is_draft || f.lead_status === 'draft');
  const activeVisits = visits.filter((v) => v.session_status === 'active' || v.status === 'in_progress');
  const scheduledVisits = visits.filter((v) => v.status === 'scheduled');

  return (
    <div className="space-y-6 text-right">
      
      {/* Role Personalized Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950 text-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-800 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 font-bold text-[10px] uppercase tracking-wider font-mono">
              Level {roleDef?.level} · {currentRole}
            </span>
            <span className="text-slate-400 text-xs">
              النطاق التشغيلي: {roleDef?.domain === 'all' ? 'كافة القطاعات' : roleDef?.domain}
            </span>
          </div>

          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            مرحباً بك في {landingConfig.title_ar}
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {landingConfig.description_ar}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            {landingConfig.recommended_actions.map((act, idx) => (
              <button
                key={idx}
                onClick={() => {
                  if (act.action === 'new_lead') onOpenNewLeadModal();
                  else if (act.action === 'simulator') onOpenSimulator();
                  else onNavigateTab(act.action);
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 shadow-xs active:scale-98 ${
                  idx === 0 
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold'
                    : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
                }`}
              >
                <span>{act.label_ar}</span>
                <ChevronRight className="w-3.5 h-3.5 rotate-180" />
              </button>
            ))}
          </div>
        </div>

        {/* Ambient watermark icon */}
        <div className="absolute left-6 -bottom-6 opacity-10 pointer-events-none">
          <Building2 className="w-48 h-48 text-white" />
        </div>
      </div>

      {/* KPI Cards Grid (Tailored per Role) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {landingConfig.primary_kpis.map((kpi, idx) => (
          <div
            key={idx}
            className="bg-white rounded-xl border border-slate-200 p-4 space-y-1 shadow-2xs hover:border-slate-300 transition-all text-right"
          >
            <span className="text-slate-500 text-[11px] block">{kpi.title_ar}</span>
            <div className="font-mono font-bold text-slate-900 text-xl tabular-nums">
              {kpi.value}
            </div>
            {kpi.change && (
              <span className="text-[10px] text-emerald-700 font-medium block">
                {kpi.change}
              </span>
            )}
          </div>
        ))}
      </div>

      {/* Dynamic Role-Specific Focus Sections */}
      {/* 1. If MARKETER or MARKETING_MGR */}
      {(currentRole === 'MARKETER' || currentRole === 'MARKETING_MGR') && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-sky-600" />
                <span>أحدث صفقات خط الإحالات (Referral Pipeline)</span>
              </h3>
              <button onClick={() => onNavigateTab('marketing')} className="text-sky-700 text-xs font-semibold">عرض الكل</button>
            </div>
            <div className="space-y-2">
              {referrals.slice(0, 3).map((ref) => (
                <div key={ref.id} className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{ref.facility_name}</span>
                    <span className="text-slate-500 text-[11px]">{ref.stage_label} ({ref.progress_pct}%)</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-700">+{ref.expected_commission.toLocaleString()} ريال</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <span>المسودات بانتظار الاعتماد المكتمل ({draftFacilities.length})</span>
              </h3>
              <button onClick={() => onNavigateTab('marketing')} className="text-amber-700 text-xs font-semibold">استعراض المسودات</button>
            </div>
            <div className="space-y-2">
              {draftFacilities.slice(0, 3).map((df) => (
                <div key={df.id} className="p-2.5 bg-amber-50/60 rounded-lg flex items-center justify-between text-xs border border-amber-200/60">
                  <div>
                    <span className="font-bold text-slate-900 block">{df.facility_name}</span>
                    <span className="text-slate-500 text-[11px]">{df.address_text}</span>
                  </div>
                  <span className="font-mono font-bold text-amber-900">{df.marketer_estimated_value?.toLocaleString() || 24000} ريال</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. If TEAM_SUPERVISOR or Team Leaders or Technicians */}
      {(currentRole === 'TEAM_SUPERVISOR' || currentRole === 'MAINT_TEAM_LEADER' || currentRole === 'FAULT_TEAM_LEADER' || currentRole === 'MAINT_TECHNICIAN' || currentRole === 'FAULT_TECHNICIAN') && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Timer className="w-4 h-4 text-emerald-600" />
                <span>الزيارات الميدانية النشطة والجارية ({activeVisits.length})</span>
              </h3>
              <button onClick={() => onNavigateTab('visits')} className="text-emerald-700 text-xs font-semibold">جدول الزيارات</button>
            </div>
            <div className="space-y-2">
              {activeVisits.length === 0 ? (
                <div className="p-4 text-center text-slate-400 text-xs">لا توجد زيارات نشطة بالعداد الآن.</div>
              ) : (
                activeVisits.map((v) => (
                  <div key={v.id} className="p-2.5 bg-emerald-50 rounded-lg flex items-center justify-between text-xs border border-emerald-200">
                    <div>
                      <span className="font-bold text-slate-900 block">{v.facility_name}</span>
                      <span className="text-slate-500 text-[11px]">{v.assigned_technician_name}</span>
                    </div>
                    <span className="px-2 py-1 bg-emerald-600 text-white font-mono font-bold rounded text-[10px] animate-pulse">
                      العداد يعمل
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <PackageCheck className="w-4 h-4 text-sky-600" />
                <span>عُهد المعدات المسندة للفرق (Team Custody)</span>
              </h3>
              <button onClick={() => onNavigateTab('hr_finance')} className="text-sky-700 text-xs font-semibold">سجل العُهد</button>
            </div>
            <div className="space-y-2">
              {assets.filter((a) => a.custody_type === 'team').map((a) => (
                <div key={a.id} className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{a.name_ar}</span>
                    <span className="text-slate-500 text-[11px]">القائد المسؤول: {a.custody_leader_name}</span>
                  </div>
                  <span className="font-mono text-slate-600 text-[10px]">{a.custody_team_name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. If FINANCE_MGR or HR_MGR */}
      {(currentRole === 'FINANCE_MGR' || currentRole === 'HR_MGR') && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-amber-600" />
                <span>عقود بانتظار الاعتماد المالي ({pendingFinanceSubs.length})</span>
              </h3>
              <button onClick={() => onNavigateTab('quotes_subs')} className="text-amber-700 text-xs font-semibold">اعتماد العقود</button>
            </div>
            <div className="space-y-2">
              {pendingFinanceSubs.map((sub) => (
                <div key={sub.id} className="p-3 bg-amber-50 rounded-xl flex items-center justify-between text-xs border border-amber-200">
                  <div>
                    <span className="font-bold text-slate-900 block">{sub.facility_name}</span>
                    <span className="text-slate-500 text-[11px] font-mono">{sub.subscription_number}</span>
                  </div>
                  <span className="font-mono font-bold text-amber-900">{sub.total_annual_value.toLocaleString()} ريال</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-600" />
                <span>مستحقات العمولات والأجور المعلقة ({dues.filter((d) => d.status !== 'paid').length})</span>
              </h3>
              <button onClick={() => onNavigateTab('hr_finance')} className="text-purple-700 text-xs font-semibold">سجل المستحقات</button>
            </div>
            <div className="space-y-2">
              {dues.slice(0, 3).map((d) => (
                <div key={d.id} className="p-2.5 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-900 block">{d.user_name}</span>
                    <span className="text-slate-500 text-[11px]">{d.due_type === 'commission' ? 'عمولة تسويقية 5%' : 'راتب/بدل'}</span>
                  </div>
                  <span className="font-mono font-bold text-slate-800">{d.amount.toLocaleString()} ريال</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. If CLIENT */}
      {currentRole === 'CLIENT' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Gift className="w-4 h-4 text-amber-600" />
                <span>محفظة نقاط الولاء الخاصة بي</span>
              </h3>
              <button onClick={() => onNavigateTab('quotes_subs')} className="text-amber-700 text-xs font-semibold">استبدال النقاط</button>
            </div>
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-600 text-xs">رصيد النقاط الحالي:</span>
                <span className="font-mono font-bold text-amber-900 text-lg">
                  {loyaltyWallets[0]?.balance_points.toLocaleString() || 1850} نقطة
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-600">القيمة المتاحة للاسترداد:</span>
                <span className="font-mono font-bold text-emerald-700">
                  {loyaltyWallets[0]?.monetary_value_sar.toLocaleString() || 185} ريال
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>اشتراكي السنوي ومزايا Premium+</span>
              </h3>
              <button onClick={() => onNavigateTab('quotes_subs')} className="text-emerald-700 text-xs font-semibold">تفاصيل العقد</button>
            </div>
            <div className="space-y-2">
              {activeSubs.slice(0, 1).map((s) => (
                <div key={s.id} className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>{s.facility_name}</span>
                    <span className="text-emerald-700">ساري ونشط</span>
                  </div>
                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>تاريخ الانتهاء:</span>
                    <span className="font-mono">{s.end_date}</span>
                  </div>
                  {s.emergency_tokens_remaining !== undefined && (
                    <div className="flex justify-between text-amber-900 text-[11px] font-bold pt-1 border-t border-slate-200">
                      <span>رموز الطوارئ المتبقية:</span>
                      <span className="font-mono">{s.emergency_tokens_remaining} من {s.emergency_tokens_total}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
