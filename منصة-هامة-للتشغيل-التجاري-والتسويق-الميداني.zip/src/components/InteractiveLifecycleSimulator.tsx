import React, { useState } from 'react';
import { 
  CheckCircle2, 
  ArrowLeft, 
  Play, 
  RefreshCw, 
  Building, 
  FileCheck, 
  QrCode, 
  DollarSign, 
  CheckCheck, 
  TrendingUp, 
  Sparkles,
  ChevronRight,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { storageService } from '../services/storageService';

interface InteractiveLifecycleSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenNewLead: () => void;
}

export const InteractiveLifecycleSimulator: React.FC<InteractiveLifecycleSimulatorProps> = ({
  isOpen,
  onClose,
  onOpenNewLead
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isExecuting, setIsExecuting] = useState(false);
  const [simulationLog, setSimulationLog] = useState<string[]>([
    'جاهز لبدء المحاكاة التفاعلية لدورة العميل الكاملة (End-to-End)...'
  ]);

  if (!isOpen) return null;

  const facilities = storageService.getFacilities();
  const appointments = storageService.getAppointments();
  const visits = storageService.getVisits();
  const quotes = storageService.getQuotes();
  const subscriptions = storageService.getSubscriptions();

  // Pick target facility for the simulation walkthrough
  const targetFacility = facilities[0];
  const targetApp = appointments.find((a) => a.facility_id === targetFacility?.id) || appointments[0];
  const targetVisit = visits.find((v) => v.facility_id === targetFacility?.id) || visits[0];
  const targetQuote = quotes.find((q) => q.facility_id === targetFacility?.id) || quotes[0];
  const targetSub = subscriptions.find((s) => s.facility_id === targetFacility?.id) || subscriptions[0];

  const logMessage = (msg: string) => {
    setSimulationLog((prev) => [
      `[${new Date().toLocaleTimeString('ar-SA')}] ${msg}`,
      ...prev,
    ]);
  };

  // Step 2 Action: Confirm Appointment
  const handleConfirmAppointmentAction = () => {
    if (!targetApp) return;
    setIsExecuting(true);
    setTimeout(() => {
      const newVisit = storageService.confirmAppointment(targetApp.id, 'مدير التسويق (MARKETING_MGR)');
      logMessage(`تم إطلاق Trigger: trg_appointment_confirmed_to_visit بنجاح! تم إنشاء زيارة معاينة تشغيلية (${newVisit?.visit_number})`);
      setIsExecuting(false);
      setCurrentStep(3);
    }, 600);
  };

  // Step 3 Action: Complete Inspection with QR scan
  const handleCompleteInspectionAction = () => {
    if (!targetVisit) return;
    setIsExecuting(true);
    setTimeout(() => {
      // 1. Scan QR
      const scanRes = storageService.scanQRCode('HAMA-FAC-1001-SITE', 'فني المعاينة: عبد الله المالكي');
      logMessage(`تم مسح QR الموقع والتحقق من التواجد الجغرافي: ${scanRes.message}`);

      // 2. Complete visit
      storageService.completeVisitInspection(targetVisit.id, {
        findings: [
          'فحص عدد 4 مصاعد Otis: تحتاج تزييت أحبال الجر واستبدال حساسات الباب',
          'فحص 30 طفاية حريق: ضغط منخفض في 12 طفاية بودرة تتطلب إعادة تعبئة',
          'غرفة التحكم: ملائمة لتركيب NVR و12 كاميرا مراقبة IP'
        ],
        inspection_notes: 'تمت المعاينة بحضور مندوب المنشأة م. فيصل العمري واعتمد التقرير الميداني.',
        parts_consumed: [
          { part_id: 'prt_2', part_name: 'حبال جر فولاذية 10mm', quantity: 20 }
        ]
      });

      logMessage(`تم إنهاء زيارة المعاينة بنجاح ورفع التقرير الميداني وتحديث المخزون.`);
      setIsExecuting(false);
      setCurrentStep(4);
    }, 700);
  };

  // Step 4 Action: Create Quote
  const handleCreateQuoteAction = () => {
    if (!targetFacility) return;
    setIsExecuting(true);
    setTimeout(() => {
      const newQuote = storageService.createQuoteForFacility(targetFacility.id, [
        {
          department_id: 'elevators',
          description: 'عقد صيانة وقائية سنوي شامل لـ 4 مصاعد Otis (12 زيارة)',
          quantity: 4,
          unit_price: 6000,
        },
        {
          department_id: 'cctv',
          description: 'توريد وتركيب 12 كاميرا مراقبة بدقة 4K مع شبكة NVR',
          quantity: 12,
          unit_price: 850,
        },
        {
          department_id: 'extinguishers',
          description: 'فحص واختبار ضغط وتعبئة 30 طفاية حريق بودرة وCO2',
          quantity: 30,
          unit_price: 120,
        }
      ]);
      logMessage(`تم توليد عرض سعر مجمع #${newQuote?.quote_number} بقيمة إجمالية ${newQuote?.total_price.toLocaleString()} ريال.`);
      setIsExecuting(false);
      setCurrentStep(5);
    }, 600);
  };

  // Step 5 Action: Client Accepts Quote
  const handleAcceptQuoteAction = () => {
    const quoteToAccept = targetQuote || quotes[0];
    if (!quoteToAccept) return;
    setIsExecuting(true);
    setTimeout(() => {
      const newSub = storageService.acceptQuote(quoteToAccept.id);
      logMessage(`🎉 أطلق العميل موافقته! Trigger: trg_quote_accepted_to_subscription حوّل العرض تلقائياً لاشتراك سنوي برقم #${newSub?.subscription_number}`);
      logMessage(`تم احتساب عمولة المسوق الميداني وتحديث مؤشرات الأداء اللحظية.`);
      setIsExecuting(false);
      setCurrentStep(6);
    }, 800);
  };

  const steps = [
    { num: 1, title: 'التسويق (Lead Submission)', icon: Building, role: 'المسوق الميداني (MARKETER)' },
    { num: 2, title: 'المراجعة واعتماد الموعد', icon: FileCheck, role: 'مدير التسويق (MARKETING_MGR)' },
    { num: 3, title: 'المعاينة الميدانية وQR', icon: QrCode, role: 'المشرف والفني (TECHNICIAN)' },
    { num: 4, title: 'إعداد العرض المجمع', icon: DollarSign, role: 'مدراء الأقسام (DOMAIN_MGR)' },
    { num: 5, title: 'قبول العميل وتفعيل العقد', icon: CheckCheck, role: 'العميل (CLIENT) والنظام' },
    { num: 6, title: 'التشغيل ومؤشرات الأداء', icon: TrendingUp, role: 'المدير العام والتقارير (GM)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between shrink-0 bg-slate-900 text-white rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">محاكي دورة العميل المتكاملة (End-to-End)</h2>
              <p className="text-xs text-slate-300">
                اختبار تدفق البيانات الحقيقي عبر المراحل الست وقواعد البيانات وفق النظام المُصلَح
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Stepper progress */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3">
          <div className="grid grid-cols-6 gap-2">
            {steps.map((s) => {
              const Icon = s.icon;
              const isPast = currentStep > s.num;
              const isCurrent = currentStep === s.num;
              return (
                <button
                  key={s.num}
                  onClick={() => setCurrentStep(s.num)}
                  className={`p-2 rounded-xl text-right transition-all border flex flex-col justify-between ${
                    isCurrent
                      ? 'bg-white border-amber-600 shadow-xs'
                      : isPast
                      ? 'bg-emerald-50/60 border-emerald-300 text-emerald-900'
                      : 'bg-transparent border-slate-200 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono font-bold">0{s.num}</span>
                    <Icon className={`w-3.5 h-3.5 ${isCurrent ? 'text-amber-600' : isPast ? 'text-emerald-600' : 'text-slate-400'}`} />
                  </div>
                  <div className="mt-1">
                    <div className="text-[11px] font-semibold truncate text-slate-800">{s.title}</div>
                    <div className="text-[9px] text-slate-500 truncate">{s.role}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 text-right text-xs">
          
          {/* Main Stage Interactive View */}
          <div className="lg:col-span-2 space-y-4">
            
            {/* Step 1: Marketer Lead Submission */}
            {currentStep === 1 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">المرحلة 1: التسويق الميداني ورفع بيانات العميل</h3>
                    <p className="text-slate-500 text-xs mt-0.5">الدور المسؤول: المسوق الميداني (MARKETER)</p>
                  </div>
                  <span className="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-md font-medium text-[11px]">
                    البيانات جاهزة
                  </span>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl space-y-2 border border-slate-200">
                  <div className="flex justify-between">
                    <span className="text-slate-500">اسم المنشأة الحالية:</span>
                    <span className="font-bold text-slate-900">{targetFacility?.facility_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">نوع المنشأة:</span>
                    <span className="font-medium text-slate-800">
                      {targetFacility?.facility_type === 'commercial' ? 'تجاري' : 'حكومي'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">المالك والمندوب:</span>
                    <span className="text-slate-700">{targetFacility?.owner_name} ({targetFacility?.owner_phone})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">الموقع الجغرافي:</span>
                    <span className="font-mono text-slate-600">{targetFacility?.location_lat}, {targetFacility?.location_lng}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenNewLead();
                    }}
                    className="px-4 py-2 border border-amber-300 bg-amber-50 text-amber-900 rounded-lg font-medium hover:bg-amber-100 transition-colors"
                  >
                    فتح نموذج المسوق وتسجيل منشأة جديدة
                  </button>
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="px-5 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 flex items-center gap-1.5"
                  >
                    <span>الانتقال للمرحلة 2 (مراجعة الطلب)</span>
                    <ArrowLeft className="w-4 h-4 text-amber-400" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Marketing Manager Review */}
            {currentStep === 2 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">المرحلة 2: مراجعة مدير التسويق وتأكيد الموعد</h3>
                    <p className="text-slate-500 text-xs mt-0.5">الدور المسؤول: مدير التسويق (MARKETING_MGR)</p>
                  </div>
                  <span className="px-2.5 py-1 bg-sky-50 text-sky-800 border border-sky-200 rounded-md font-medium text-[11px]">
                    موعد بانتظار التأكيد
                  </span>
                </div>

                <div className="p-4 bg-sky-50/50 rounded-xl border border-sky-200 space-y-3">
                  <p className="text-slate-700">
                    استلم مدير التسويق موعد المعاينة رقم <strong>{targetApp?.appointment_number}</strong> لمنشأة{' '}
                    <strong>{targetApp?.facility_name}</strong> بتاريخ{' '}
                    <span className="font-mono">{targetApp?.requested_date}</span> الساعة{' '}
                    <span className="font-mono">{targetApp?.requested_time}</span>.
                  </p>
                  <div className="text-[11px] text-slate-600 bg-white p-3 rounded-lg border border-sky-100">
                    ⚡ <strong>آلية الـ Trigger في قاعدة البيانات:</strong> عند تحويل حالة الموعد إلى `confirmed`،
                    يقوم `trg_appointment_confirmed_to_visit` بإنشاء صف تلقائي في جدول `visits` بنوع `inspection` ومصدر `marketing`.
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100"
                  >
                    السابق
                  </button>
                  <button
                    onClick={handleConfirmAppointmentAction}
                    disabled={isExecuting}
                    className="px-6 py-2.5 bg-sky-700 text-white rounded-lg font-semibold hover:bg-sky-800 flex items-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>تأكيد الموعد وإطلاق Trigger زيارة المعاينة</span>
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Field Inspection & QR Scan */}
            {currentStep === 3 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">المرحلة 3: المعاينة الميدانية ومسح QR الموقع</h3>
                    <p className="text-slate-500 text-xs mt-0.5">الدور المسؤول: مشرف الفرق والفني الميداني (TECHNICIAN)</p>
                  </div>
                  <span className="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-md font-medium text-[11px]">
                    الزيارة مجدولة
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-800">زيارة المعاينة #{targetVisit?.visit_number}</div>
                      <div className="text-[11px] text-slate-500">{targetVisit?.facility_name} · الفني: {targetVisit?.assigned_technician_name}</div>
                    </div>
                    <span className="px-2 py-0.5 bg-sky-100 text-sky-800 rounded font-mono text-[10px]">
                      {targetVisit?.status}
                    </span>
                  </div>

                  <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-white">
                    <div className="font-bold text-slate-800 flex items-center gap-1.5">
                      <QrCode className="w-4 h-4 text-emerald-600" />
                      <span>التحقق من رمز QR الموقع عند وصول الفريق:</span>
                    </div>
                    <p className="text-slate-600 text-[11px]">
                      يقوم الفني بمسح كود `HAMA-FAC-1001-SITE` لإثبات التواجد الفعلي في موقع المنشأة وفق نظام التتبع الجغرافي.
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setCurrentStep(2)}
                    className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100"
                  >
                    السابق
                  </button>
                  <button
                    onClick={handleCompleteInspectionAction}
                    disabled={isExecuting}
                    className="px-6 py-2.5 bg-emerald-700 text-white rounded-lg font-semibold hover:bg-emerald-800 flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>محاكاة مسح الـ QR وإتمام تقرير المعاينة</span>
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Multi-Department Quotes Preparation */}
            {currentStep === 4 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">المرحلة 4: إعداد العروض وتجميع البنود</h3>
                    <p className="text-slate-500 text-xs mt-0.5">الدور المسؤول: مدراء الأقسام (DOMAIN_MGR × 3) ومدير التسويق</p>
                  </div>
                  <span className="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-md font-medium text-[11px]">
                    جاهز للتسعير
                  </span>
                </div>

                <div className="space-y-3">
                  <p className="text-slate-700">
                    بناءً على تقرير المعاينة الميدانية، يقوم كل مدير قسم بتسعير بنوده في جدول `quote_items`:
                  </p>
                  <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden">
                    <div className="p-3 bg-slate-50 font-semibold flex justify-between text-slate-700">
                      <span>القسم والخدمة</span>
                      <span>القيمة التقديرية</span>
                    </div>
                    <div className="p-3 flex justify-between">
                      <span>🏢 قسم المصاعد: صيانة 4 مصاعد Otis</span>
                      <span className="font-mono font-bold">24,000 ريال</span>
                    </div>
                    <div className="p-3 flex justify-between">
                      <span>📹 قسم المراقبة: توريد 12 كاميرا 4K وNVR</span>
                      <span className="font-mono font-bold">10,200 ريال</span>
                    </div>
                    <div className="p-3 flex justify-between">
                      <span>🧯 قسم السلامة: اختبار وتعبئة 30 طفاية</span>
                      <span className="font-mono font-bold">3,600 ريال</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setCurrentStep(3)}
                    className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100"
                  >
                    السابق
                  </button>
                  <button
                    onClick={handleCreateQuoteAction}
                    disabled={isExecuting}
                    className="px-6 py-2.5 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 flex items-center gap-2"
                  >
                    <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                    <span>توليد عرض السعر المجمع وإرساله للعميل</span>
                  </button>
                </div>
              </div>
            )}

            {/* Step 5: Client Approval & Auto Subscription */}
            {currentStep === 5 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">المرحلة 5: قبول العرض وتفعيل الاشتراكات تلقائياً</h3>
                    <p className="text-slate-500 text-xs mt-0.5">الدور المسؤول: العميل (CLIENT) وبوابة الخدمات الذاتية</p>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-md font-medium text-[11px]">
                    العرض معروض على العميل
                  </span>
                </div>

                <div className="p-4 bg-emerald-50/40 rounded-xl border border-emerald-200 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-900">عرض السعر رقم #{targetQuote?.quote_number || 'QUO-2026-0001'}</span>
                    <span className="font-mono font-bold text-emerald-700 text-sm">
                      {targetQuote?.total_price.toLocaleString() || '43,470'} ريال (شامل الضريبة)
                    </span>
                  </div>
                  <p className="text-slate-600 text-[11px]">
                    ⚡ <strong>آلية الـ Trigger الأوتوماتيكية:</strong> عند نقر العميل على "قبول العقد"، يطلق
                    `trg_quote_accepted_to_subscription` توليد اشتراك سنوي بجدول `subscriptions` + بنود `subscription_items`
                    + تحديث حالة كافة الطلبات إلى `activated`.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setCurrentStep(4)}
                    className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100"
                  >
                    السابق
                  </button>
                  <button
                    onClick={handleAcceptQuoteAction}
                    disabled={isExecuting}
                    className="px-6 py-2.5 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 flex items-center gap-2 shadow-xs"
                  >
                    <CheckCheck className="w-4 h-4 text-white" />
                    <span>قبول العرض وتفعيل الاشتراك السنوي</span>
                  </button>
                </div>
              </div>
            )}

            {/* Step 6: Operational Execution & Reports */}
            {currentStep === 6 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">المرحلة 6: التشغيل المنتظم والتقارير التنفيذية</h3>
                    <p className="text-slate-500 text-xs mt-0.5">الدور المسؤول: الإدارة العامة ومتابعة عقود الصيانة الدورية</p>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-md font-bold text-[11px]">
                    دورة العقد نشطة 100%
                  </span>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>تم اكتمال دورة العميل بنجاح تام!</span>
                  </div>
                  <p className="text-slate-700">
                    أصبح للمنشأة اشتراك سنوي نشط، ورموز QR معتمدة، وخطط صيانة وقائية مجدولة دورياً.
                    تم تحديث الـ SQL Views (تقرير أداء المسوق، وتوزيع المنشآت، ومسار الـ Funnel).
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                    <span>إعادة تشغيل المحاكي من البداية</span>
                  </button>
                  <button
                    onClick={onClose}
                    className="px-6 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800"
                  >
                    إغلاق المحاكي والعودة للوحة التحكم
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Database Live Audit Terminal */}
          <div className="bg-slate-900 text-slate-200 rounded-xl p-4 flex flex-col h-full border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-mono font-bold text-amber-400 text-xs">SQL & Triggers Audit Terminal</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            </div>

            <div className="flex-1 font-mono text-[11px] space-y-2 overflow-y-auto max-h-72">
              {simulationLog.map((log, idx) => (
                <div key={idx} className="leading-relaxed border-b border-slate-800/50 pb-1.5 last:border-0">
                  {log}
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400">
              <span className="text-amber-400">Sequences:</span> Central locks active · <span className="text-emerald-400">Constraints:</span> Stock Non-negative verified
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
