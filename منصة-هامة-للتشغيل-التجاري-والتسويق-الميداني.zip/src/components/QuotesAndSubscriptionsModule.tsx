import React, { useState } from 'react';
import { 
  FileText, 
  CheckCheck, 
  DollarSign, 
  Calendar, 
  Clock, 
  Building, 
  Layers, 
  CheckCircle2, 
  ShieldCheck, 
  Printer, 
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Percent,
  Sparkles,
  Zap,
  Gift,
  AlertTriangle,
  UserCheck,
  Send,
  Plus
} from 'lucide-react';
import { Quote, Subscription, LoyaltyWallet } from '../types';
import { storageService } from '../services/storageService';
import { DEPARTMENTS } from '../data/initialData';

export const QuotesAndSubscriptionsModule: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'quotes' | 'subscriptions' | 'loyalty'>('quotes');
  const [selectedQuoteForPreview, setSelectedQuoteForPreview] = useState<Quote | null>(null);
  const [successToast, setSuccessToast] = useState<string>('');
  const [selectedWalletForRedeem, setSelectedWalletForRedeem] = useState<LoyaltyWallet | null>(null);
  const [redeemPoints, setRedeemPoints] = useState<number>(500);
  const [redeemType, setRedeemType] = useState<'cash' | 'discount'>('discount');
  const [redeemDetails, setRedeemDetails] = useState<string>('حساب مصرف الراجحي SA0380000000000000000000');
  const [newClientAccountModal, setNewClientAccountModal] = useState<{ clientEmail: string; tempPass: string; subNumber: string; clientName: string } | null>(null);

  const quotes = storageService.getQuotes();
  const subscriptions = storageService.getSubscriptions();
  const loyaltyWallets = storageService.getLoyaltyWallets();
  const expiringContracts = storageService.getExpiringContractsIn30Days();

  const handleAcceptQuote = (quoteId: string) => {
    const sub = storageService.acceptQuote(quoteId);
    if (sub) {
      setSuccessToast(`تم قبول العقد بنجاح! العقد الآن بحالة (بانتظار اعتماد الإدارة المالية) #${sub.subscription_number}`);
      setTimeout(() => setSuccessToast(''), 4000);
    }
  };

  // Point 5: Finance Manager Approval
  const handleFinanceApproval = (subId: string) => {
    const approved = storageService.approveSubscriptionByFinance(subId);
    if (approved) {
      const email = `client.${approved.client_id.substring(4)}@hama-enterprise.sa`;
      const pass = 'Hama@' + Math.floor(100000 + Math.random() * 900000);
      setNewClientAccountModal({
        clientEmail: email,
        tempPass: pass,
        subNumber: approved.subscription_number,
        clientName: approved.client_name,
      });
      setSuccessToast(`تم اعتماد العقد مالياً وتوليد بيانات دخول العميل وحساب عمولة المسوق 5%!`);
      setTimeout(() => setSuccessToast(''), 5000);
    }
  };

  // Point 10: Redeem Loyalty Points
  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWalletForRedeem) return;
    const res = storageService.redeemLoyaltyPoints(selectedWalletForRedeem.id, redeemPoints, redeemType, redeemDetails);
    if (res.success) {
      setSuccessToast(res.message);
      setSelectedWalletForRedeem(null);
      setTimeout(() => setSuccessToast(''), 4000);
    } else {
      alert(res.message);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Point 11: 30-Day Contract Expiry Automated Warning Banner */}
      {expiringContracts.length > 0 && (
        <div className="bg-amber-500 text-slate-950 p-4 rounded-2xl shadow-sm border border-amber-400 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-black/10 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-slate-900" />
            </div>
            <div>
              <strong className="font-bold text-sm block">تنبيهات العقود المشرفة على الانتهاء (خلال 30 يوماً):</strong>
              <span>يوجد {expiringContracts.length} عقود ستنتهي قريباً. تم إشعار العميل ومدير التسويق للبدء في إجراءات التجديد الفوري.</span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {expiringContracts.map((c) => {
              const daysLeft = Math.max(0, Math.ceil((new Date(c.end_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
              return (
                <span key={c.id} className="bg-slate-900 text-white px-2.5 py-1 rounded-md font-mono text-[11px] font-bold">
                  {c.subscription_number} ({daysLeft} يوم متبقٍ)
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-900">
              العروض التجارية والاشتراكات السنوية (Contracts & Subscriptions)
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
              عقود Premium+ ومحفظة الولاء
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            تسعير الخدمات المجمعة، عقود بريميوم بلس (0 زيارات دورية، 12 رمز طوارئ)، واعتماد المالية الآلي
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex p-1 bg-slate-100 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveTab('quotes')}
            className={`px-4 py-1.5 rounded-lg transition-all ${
              activeTab === 'quotes' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            عروض الأسعار ({quotes.length})
          </button>
          <button
            onClick={() => setActiveTab('subscriptions')}
            className={`px-4 py-1.5 rounded-lg transition-all ${
              activeTab === 'subscriptions' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            الاشتراكات والعقود ({subscriptions.length})
          </button>
          <button
            onClick={() => setActiveTab('loyalty')}
            className={`px-4 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'loyalty' ? 'bg-amber-600 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            <span>محفظة نقاط الولاء ({loyaltyWallets.length})</span>
          </button>
        </div>
      </div>

      {successToast && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast('')} className="text-xs text-emerald-700">✕</button>
        </div>
      )}

      {/* Quotes Tab */}
      {activeTab === 'quotes' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quotes.map((quote) => {
              const isPremiumPlus = quote.contract_type === 'premium_plus';
              return (
                <div
                  key={quote.id}
                  className={`bg-white rounded-2xl border p-5 space-y-4 shadow-2xs hover:border-slate-300 transition-all text-right text-xs ${
                    isPremiumPlus ? 'border-amber-400 bg-amber-50/20 ring-1 ring-amber-400/30' : 'border-slate-200'
                  }`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-400 text-[11px] block">{quote.quote_number}</span>
                        {isPremiumPlus && (
                          <span className="px-2 py-0.5 rounded bg-amber-500 text-white font-bold text-[10px] flex items-center gap-1">
                            <Zap className="w-3 h-3 fill-white" />
                            <span>عقد بريميوم بلس (Premium+)</span>
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-slate-900 text-sm mt-0.5">{quote.client_name}</h3>
                      <span className="text-slate-500 text-[11px]">{quote.quote_type}</span>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      quote.status === 'accepted'
                        ? 'bg-emerald-100 text-emerald-800'
                        : quote.status === 'sent'
                        ? 'bg-sky-100 text-sky-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {quote.status === 'accepted' ? 'تم القبول والتحويل' :
                       quote.status === 'sent' ? 'معروض على العميل' : 'مسودة'}
                    </span>
                  </div>

                  {/* Premium+ perks highlight (Point 2) */}
                  {isPremiumPlus && (
                    <div className="bg-amber-100/70 p-3 rounded-xl border border-amber-300 space-y-1.5 text-[11px] text-amber-950">
                      <div className="font-bold flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                        <span>مزايا باقة بريميوم بلس الحصرية:</span>
                      </div>
                      <ul className="list-disc list-inside space-y-0.5 text-[10px] text-amber-900">
                        <li><strong>0 زيارات دورية روتينية</strong> (حسب الطلب والاستجابة الفورية).</li>
                        <li><strong>12 رمز استجابة طوارئ مجانية (Emergency Tokens)</strong> سنوية.</li>
                        <li><strong>زمن استجابة فائق SLA: خلال 4 ساعات كحد أقصى</strong> على مدار الساعة.</li>
                        <li><strong>رصيد قطع غيار مجانية سنوي: 6,000 ريال</strong> مشمولة بالعقد.</li>
                      </ul>
                    </div>
                  )}

                  {/* Items breakdown (quote_items) */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold text-slate-700">بنود العرض المفصلة (quote_items):</div>
                    <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden bg-slate-50/50">
                      {quote.items.map((item) => {
                        const dept = DEPARTMENTS.find((d) => d.id === item.department_id);
                        return (
                          <div key={item.id} className="p-2.5 flex items-center justify-between text-[11px]">
                            <div>
                              <div className="font-semibold text-slate-800">{item.description}</div>
                              <div className="text-[10px] text-slate-500 font-medium">{dept?.name_ar || item.department_id} · الكمية: {item.quantity}</div>
                            </div>
                            <div className="font-mono font-bold text-slate-900 tabular-nums">
                              {item.total_price.toLocaleString()} ريال
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Totals */}
                  <div className="bg-slate-50 p-3 rounded-xl space-y-1.5 border border-slate-200/80">
                    <div className="flex justify-between text-slate-600">
                      <span>المجموع قبل الضريبة:</span>
                      <span className="font-mono tabular-nums">{quote.subtotal.toLocaleString()} ريال</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>ضريبة القيمة المضافة (15%):</span>
                      <span className="font-mono tabular-nums">{quote.vat_amount.toLocaleString()} ريال</span>
                    </div>
                    <div className="flex justify-between font-bold text-slate-900 text-sm pt-1.5 border-t border-slate-200">
                      <span>الإجمالي النهائي:</span>
                      <span className="font-mono text-amber-900 tabular-nums">{quote.total_price.toLocaleString()} ريال</span>
                    </div>
                  </div>

                  {/* Footer Actions */}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-400">
                      صالح حتى: <span className="font-mono">{quote.valid_until}</span>
                    </span>

                    {quote.status !== 'accepted' ? (
                      <button
                        onClick={() => handleAcceptQuote(quote.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 active:scale-98"
                      >
                        <CheckCheck className="w-4 h-4 text-emerald-200" />
                        <span>قبول العميل للعقد وتحويله للمالية</span>
                      </button>
                    ) : (
                      <div className="text-emerald-700 font-semibold flex items-center gap-1 text-[11px]">
                        <ShieldCheck className="w-4 h-4" />
                        <span>تم القبول وتحويله للاشتراكات</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Subscriptions Tab */}
      {activeTab === 'subscriptions' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {subscriptions.map((sub) => {
              const isPremiumPlus = sub.contract_type === 'premium_plus';
              const isPendingFinance = sub.status === 'pending_finance';

              return (
                <div
                  key={sub.id}
                  className={`bg-white rounded-2xl border p-5 space-y-4 shadow-2xs hover:border-slate-300 transition-all text-right text-xs ${
                    isPendingFinance ? 'border-amber-300 bg-amber-50/10' : 'border-slate-200'
                  }`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-amber-900 text-sm">{sub.subscription_number}</span>
                        <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                          sub.status === 'active' ? 'bg-emerald-100 text-emerald-800' :
                          sub.status === 'pending_finance' ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {sub.status === 'active' ? 'ساري ونشط' :
                           sub.status === 'pending_finance' ? 'بانتظار الاعتماد المالي' : 'منتهي'}
                        </span>
                        {isPremiumPlus && (
                          <span className="px-2 py-0.5 rounded bg-amber-500 text-white font-bold text-[10px]">
                            Premium+
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-slate-900 text-sm mt-1">{sub.facility_name}</h3>
                    </div>
                    <div className="text-left font-mono">
                      <span className="text-slate-400 text-[10px] block">القيمة السنوية</span>
                      <span className="font-bold text-slate-900 text-sm">{sub.total_annual_value.toLocaleString()} ريال</span>
                    </div>
                  </div>

                  {/* Point 2: Premium+ Live Tokens & SLA */}
                  {isPremiumPlus && (
                    <div className="grid grid-cols-3 gap-2 bg-amber-50 p-3 rounded-xl border border-amber-200 text-center">
                      <div>
                        <span className="text-slate-500 text-[10px] block">رموز الطوارئ المتبقية</span>
                        <span className="font-bold text-amber-900 font-mono text-base">
                          {sub.emergency_tokens_remaining} / {sub.emergency_tokens_total}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">زمن الاستجابة SLA</span>
                        <span className="font-bold text-slate-900 font-mono text-base">{sub.sla_response_hours} ساعات</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[10px] block">رصيد قطع الغيار</span>
                        <span className="font-bold text-emerald-700 font-mono text-base">{sub.free_parts_allowance_annual?.toLocaleString()} ريال</span>
                      </div>
                    </div>
                  )}

                  {/* Subscription Items */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold text-slate-700">حزم الصيانة والتشغيل الدورية:</div>
                    <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50/50 overflow-hidden">
                      {sub.items.map((item) => (
                        <div key={item.id} className="p-3 flex items-center justify-between text-[11px]">
                          <div>
                            <div className="font-semibold text-slate-900">{item.service_name}</div>
                            <div className="text-slate-500 text-[10px] mt-0.5">
                              الوتيرة: {item.visits_per_year === 0 ? '0 زيارات دورية (استجابة طوارئ عند الطلب)' : `${item.visits_per_year} زيارة/سنة`}
                            </div>
                          </div>
                          <div className="text-left font-mono">
                            <span className="font-bold text-slate-800">{item.total_value.toLocaleString()} ريال</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Point 5: Finance Approval Action */}
                  {isPendingFinance && (
                    <div className="p-3.5 bg-amber-100/80 rounded-xl border border-amber-300 flex items-center justify-between">
                      <div>
                        <strong className="block text-slate-900 font-bold text-xs">مطلوب اعتماد المدير المالي (FINANCE_MGR)</strong>
                        <span className="text-slate-600 text-[11px]">
                          الاعتماد المالي يُنشئ تلقائياً حساب العميل ببوابة هامة ويرصد عمولة المسوق (5%).
                        </span>
                      </div>
                      <button
                        onClick={() => handleFinanceApproval(sub.id)}
                        className="px-3.5 py-2 bg-slate-950 hover:bg-slate-800 text-white font-bold rounded-lg text-xs shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
                      >
                        <UserCheck className="w-4 h-4 text-amber-400" />
                        <span>اعتماد المالية وتفعيل الحساب</span>
                      </button>
                    </div>
                  )}

                  {/* Validity and Schedules */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>تاريخ البداية: <strong className="text-slate-800 font-mono">{sub.start_date}</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>تاريخ الانتهاء: <strong className="text-slate-800 font-mono">{sub.end_date}</strong></span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Customer Loyalty Points Wallet (Point 10) */}
      {activeTab === 'loyalty' && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-950 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <strong className="block text-sm">محفظة نقاط الولاء للعملاء (Loyalty Points Wallet)</strong>
                <span className="text-amber-800 text-[11px]">
                  يكتسب العميل نقاط ولاء مع كل عقد وتجديد، مع إمكانية الاسترداد النقدي لحسابه البنكي IBAN أو خصم مباشر على فاتورة التجديد.
                </span>
              </div>
            </div>
            <span className="font-bold text-amber-900 font-mono">{loyaltyWallets.length} محافظ عملاء</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {loyaltyWallets.map((wallet) => (
              <div key={wallet.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-2xs text-right text-xs">
                <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{wallet.client_name}</h3>
                    <span className="text-slate-400 text-[11px]">رقم المحفظة: {wallet.id}</span>
                  </div>
                  <span className="font-mono font-bold text-amber-800 bg-amber-50 px-3 py-1 rounded-lg border border-amber-200 text-sm">
                    {wallet.balance_points.toLocaleString()} نقطة
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-slate-500 text-[11px] block">القيمة النقدية المقابلة:</span>
                    <span className="font-mono font-bold text-emerald-700 text-sm">{wallet.monetary_value_sar.toLocaleString()} ريال</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[11px] block">إجمالي ما تم استرداده:</span>
                    <span className="font-mono font-bold text-slate-800 text-sm">{wallet.total_redeemed_sar.toLocaleString()} ريال</span>
                  </div>
                </div>

                {/* Transactions history */}
                <div className="space-y-1.5">
                  <div className="font-semibold text-slate-700 text-[11px]">سجل العمليات الأخير:</div>
                  <div className="border border-slate-100 rounded-lg divide-y divide-slate-100 max-h-32 overflow-y-auto">
                    {wallet.transactions.map((tx) => (
                      <div key={tx.id} className="p-2 flex items-center justify-between text-[11px]">
                        <div>
                          <span className={`font-semibold ${tx.transaction_type === 'earn' ? 'text-emerald-700' : 'text-rose-700'}`}>
                            {tx.transaction_type === 'earn' ? `+${tx.points}` : `-${tx.points}`} نقطة
                          </span>
                          <span className="text-slate-500 mr-2 text-[10px]">{tx.reference_desc}</span>
                        </div>
                        <span className="text-slate-400 font-mono text-[10px]">{tx.created_at.substring(0, 10)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">معادلة الاسترداد: 10 نقاط = 1 ريال سعودي</span>
                  <button
                    onClick={() => {
                      setSelectedWalletForRedeem(wallet);
                      setRedeemPoints(Math.min(1000, wallet.balance_points));
                    }}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Gift className="w-3.5 h-3.5" />
                    <span>استبدال النقاط الآن</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Point 10: Redeem Points Modal */}
      {selectedWalletForRedeem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md p-6 space-y-4 text-right text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">استبدال نقاط الولاء للعميل</h3>
                <span className="text-slate-500 text-[11px]">{selectedWalletForRedeem.client_name}</span>
              </div>
              <button onClick={() => setSelectedWalletForRedeem(null)} className="text-slate-400 hover:text-slate-700">✕</button>
            </div>

            <form onSubmit={handleRedeem} className="space-y-4">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  النقاط المراد استبدالها (الرصيد المتاح: {selectedWalletForRedeem.balance_points})
                </label>
                <input
                  type="number"
                  min="50"
                  max={selectedWalletForRedeem.balance_points}
                  step="50"
                  value={redeemPoints}
                  onChange={(e) => setRedeemPoints(parseInt(e.target.value) || 50)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                />
                <span className="text-emerald-700 font-medium block mt-1 text-[11px]">
                  القيمة النقدية المقابلة: {(redeemPoints / 10).toLocaleString()} ريال
                </span>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">نوع الاسترداد</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRedeemType('discount')}
                    className={`py-2 px-3 rounded-lg border text-center font-medium ${
                      redeemType === 'discount' ? 'border-amber-600 bg-amber-50 text-amber-950 font-bold' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    خصم على تجديد العقد
                  </button>
                  <button
                    type="button"
                    onClick={() => setRedeemType('cash')}
                    className={`py-2 px-3 rounded-lg border text-center font-medium ${
                      redeemType === 'cash' ? 'border-amber-600 bg-amber-50 text-amber-950 font-bold' : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    تحويل بنكي IBAN
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  {redeemType === 'cash' ? 'رقم الحساب البنكي (IBAN)' : 'رقم الفاتورة أو العقد المستهدف'}
                </label>
                <input
                  type="text"
                  required
                  value={redeemDetails}
                  onChange={(e) => setRedeemDetails(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-left dir-ltr"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setSelectedWalletForRedeem(null)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold shadow-xs"
                >
                  تأكيد الاستبدال
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Point 5: Generated Client User Account Modal */}
      {newClientAccountModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg p-6 space-y-4 text-right text-xs">
            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">تم إنشاء حساب العميل تلقائياً</h3>
                <span className="text-slate-500 text-[11px]">
                  العقد: #{newClientAccountModal.subNumber} · العميل: {newClientAccountModal.clientName}
                </span>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">اسم المستخدم / البريد الإلكتروني:</span>
                <span className="font-mono font-bold text-slate-900 select-all dir-ltr">{newClientAccountModal.clientEmail}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">كلمة المرور المؤقتة:</span>
                <span className="font-mono font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded select-all dir-ltr">{newClientAccountModal.tempPass}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">حالة الإرسال الفوري:</span>
                <span className="text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>تم الإرسال عبر WhatsApp والبريد</span>
                </span>
              </div>
            </div>

            <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200 text-emerald-950 text-[11px]">
              تم رصد عمولة المسوق بنسبة 5% وإضافتها إلى مستحقات الموظف في شؤون الموظفين (HR Dues).
            </div>

            <div className="pt-2 text-center">
              <button
                onClick={() => setNewClientAccountModal(null)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold"
              >
                إغلاق ونسخ البيانات
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
