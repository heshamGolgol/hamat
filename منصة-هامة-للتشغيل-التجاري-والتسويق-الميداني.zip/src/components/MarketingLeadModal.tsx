import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Calendar, 
  Clock, 
  Upload, 
  Plus, 
  Check, 
  Building, 
  User, 
  Phone, 
  AlertCircle,
  FileText,
  Camera,
  Layers,
  Flame,
  Shield,
  LifeBuoy,
  MoveVertical,
  HardHat,
  Leaf
} from 'lucide-react';
import { FacilityType, DepartmentId, ServiceCategory } from '../types';
import { storageService } from '../services/storageService';
import { DEPARTMENTS } from '../data/initialData';

interface MarketingLeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (leadName: string) => void;
  marketerName?: string;
  marketerId?: string;
}

interface ServiceSelectionItem {
  department_id: DepartmentId;
  service_category: ServiceCategory;
  service_title_ar: string;
  service_details: Record<string, any>;
}

export const MarketingLeadModal: React.FC<MarketingLeadModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  marketerName = 'سلطان بن فهد (مسوق معتمد)',
  marketerId = 'usr_mkt_1',
}) => {
  const facilitySubtypes = storageService.getFacilitySubtypes();

  // Basic Facility Info
  const [facilityName, setFacilityName] = useState('');
  const [facilityType, setFacilityType] = useState<FacilityType>('commercial');
  const [commercialSubtype, setCommercialSubtype] = useState(facilitySubtypes[0]?.id || 'st_1');
  const [commercialSubtypeOther, setCommercialSubtypeOther] = useState('');
  const [showAddSubtypeModal, setShowAddSubtypeModal] = useState(false);
  const [newSubtypeNameAr, setNewSubtypeNameAr] = useState('');

  // Owner & Delegate
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [delegateName, setDelegateName] = useState('');
  const [delegatePhone, setDelegatePhone] = useState('');

  // Location
  const [locationLat, setLocationLat] = useState('24.7136');
  const [locationLng, setLocationLng] = useState('46.6753');
  const [mapUrl, setMapUrl] = useState('https://maps.google.com/?q=24.7136,46.6753');
  const [addressText, setAddressText] = useState('');

  // Notes
  const [notes, setNotes] = useState('');

  // Visit Appointment
  const todayStr = new Date().toISOString().substring(0, 10);
  const [visitDate, setVisitDate] = useState(todayStr);
  const [visitTime, setVisitTime] = useState('10:00');

  // Mandatory Site Photo & Attachments
  const [sitePhotoUrl, setSitePhotoUrl] = useState('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&auto=format&fit=crop&q=80');
  const [attachedFiles, setAttachedFiles] = useState<string[]>([
    'كروكي_موقع_المنشأة_المعتمد.pdf',
    'السجل_التجاري_رخصة_البلدية.pdf'
  ]);
  const [newFileName, setNewFileName] = useState('');

  // Multi-department Selected Services
  const [selectedServices, setSelectedServices] = useState<ServiceSelectionItem[]>([
    {
      department_id: 'elevators',
      service_category: 'contract',
      service_title_ar: 'عقد صيانة مصاعد وقائية',
      service_details: { elevators_count: 2, floors: 4, brand: 'Otis' }
    }
  ]);

  // Marketer Pricing Estimation (Point 6 & 7)
  const [estimatedValue, setEstimatedValue] = useState<string>('24000');
  const [pricingNotes, setPricingNotes] = useState<string>('عرض سنوي مقترح يشمل فحص وتجديد مع صيانة ربع سنوية');

  // Form error state
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  // Toggle or add service helper
  const handleToggleService = (
    deptId: DepartmentId, 
    category: ServiceCategory, 
    defaultTitle: string, 
    defaultDetails: Record<string, any> = {}
  ) => {
    const exists = selectedServices.some(
      (s) => s.department_id === deptId && s.service_category === category
    );

    if (exists) {
      setSelectedServices(selectedServices.filter(
        (s) => !(s.department_id === deptId && s.service_category === category)
      ));
    } else {
      setSelectedServices([
        ...selectedServices,
        {
          department_id: deptId,
          service_category: category,
          service_title_ar: defaultTitle,
          service_details: defaultDetails,
        }
      ]);
    }
  };

  const isServiceSelected = (deptId: DepartmentId, category: ServiceCategory) => {
    return selectedServices.some((s) => s.department_id === deptId && s.service_category === category);
  };

  const updateServiceDetail = (deptId: DepartmentId, category: ServiceCategory, key: string, val: any) => {
    setSelectedServices(
      selectedServices.map((s) => {
        if (s.department_id === deptId && s.service_category === category) {
          return {
            ...s,
            service_details: {
              ...s.service_details,
              [key]: val,
            }
          };
        }
        return s;
      })
    );
  };

  const handleAddNewSubtype = () => {
    if (!newSubtypeNameAr.trim()) return;
    const added = storageService.addFacilitySubtype(newSubtypeNameAr.trim(), newSubtypeNameAr.trim());
    setCommercialSubtype(added.id);
    setNewSubtypeNameAr('');
    setShowAddSubtypeModal(false);
  };

  const handleAddAttachment = () => {
    if (!newFileName.trim()) return;
    setAttachedFiles([...attachedFiles, newFileName.trim()]);
    setNewFileName('');
  };

  const handleSave = (asDraft: boolean) => {
    setErrorMsg('');

    if (!facilityName.trim()) {
      setErrorMsg('يرجى إدخال اسم المنشأة.');
      return;
    }
    if (!asDraft && (!ownerName.trim() || !ownerPhone.trim())) {
      setErrorMsg('بيانات المالك (الاسم ورقم الهاتف) إلزامية للاعتماد والإرسال.');
      return;
    }
    if (facilityType === 'commercial' && commercialSubtype === 'st_8' && !commercialSubtypeOther.trim()) {
      setErrorMsg('يرجى تحديد نوع المنشأة التجارية الأخرى.');
      return;
    }
    if (!asDraft && selectedServices.length === 0) {
      setErrorMsg('يرجى اختيار خدمة واحدة على الأقل من الأقسام المتاحة.');
      return;
    }

    setIsSubmitting(true);
    try {
      storageService.createMarketingLead({
        facility_name: facilityName.trim(),
        facility_type: facilityType,
        commercial_subtype: facilityType === 'commercial' ? commercialSubtype : undefined,
        commercial_subtype_other: commercialSubtype === 'st_8' ? commercialSubtypeOther.trim() : undefined,
        owner_name: ownerName.trim() || 'مالك المنشأة (مسودة)',
        owner_phone: ownerPhone.trim() || '0500000000',
        delegate_name: delegateName.trim() || undefined,
        delegate_phone: delegatePhone.trim() || undefined,
        location_lat: parseFloat(locationLat) || 24.7136,
        location_lng: parseFloat(locationLng) || 46.6753,
        map_url: mapUrl.trim(),
        address_text: addressText.trim() || 'المملكة العربية السعودية',
        notes: notes.trim() || undefined,
        site_photo_url: sitePhotoUrl,
        visit_date: visitDate,
        visit_time: visitTime,
        selected_services: selectedServices,
        marketer_id: marketerId,
        marketer_name: marketerName,
        marketer_estimated_value: parseFloat(estimatedValue) || 24000,
        marketer_pricing_notes: pricingNotes.trim(),
        is_draft: asDraft,
      });

      setIsSubmitting(false);
      onSuccess(facilityName + (asDraft ? ' (تم الحفظ كمسودة)' : ''));
      onClose();
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMsg(err.message || 'حدث خطأ أثناء حفظ بيانات العميل');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSave(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between shrink-0 bg-slate-50/70 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-700">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                تسجيل عميل جديد (نموذج المسوق المعتمد)
              </h2>
              <p className="text-xs text-slate-500">
                رفع بيانات المنشأة، الخدمات متعددة الأقسام، وحجز موعد المعاينة الميدانية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Scrollable Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto px-6 py-6 space-y-6 flex-1 text-right text-xs">
          
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span className="font-medium">{errorMsg}</span>
            </div>
          )}

          {/* Section 1: Facility Basics */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                بيانات المنشأة والنشاط
              </h3>
              <span className="text-slate-400 text-[11px]">المسوق الحالي: {marketerName}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-slate-700 mb-1.5">
                  اسم المنشأة / العميل <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: مستشفى النخيل التخصصي، مصنع اليمامة..."
                  value={facilityName}
                  onChange={(e) => setFacilityName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 text-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1.5">
                  نوع المنشأة <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['commercial', 'government', 'residential'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setFacilityType(type)}
                      className={`py-2 px-3 text-center rounded-lg border font-medium transition-all ${
                        facilityType === type
                          ? 'border-amber-600 bg-amber-50/70 text-amber-900 font-semibold shadow-xs'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {type === 'commercial' ? 'تجاري' : type === 'government' ? 'حكومي' : 'سكني'}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Conditional Commercial Subtype */}
            {facilityType === 'commercial' && (
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-medium text-slate-800">
                    نوع النشاط التجاري <span className="text-rose-500">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowAddSubtypeModal(true)}
                    className="text-amber-700 hover:text-amber-800 font-medium flex items-center gap-1 text-[11px]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة نوع جديد للقائمة</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {facilitySubtypes.map((st) => (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => setCommercialSubtype(st.id)}
                      className={`p-2 rounded-lg border text-right transition-all ${
                        commercialSubtype === st.id
                          ? 'border-amber-600 bg-white shadow-xs text-amber-950 font-semibold'
                          : 'border-slate-200 bg-white/60 text-slate-600 hover:bg-white'
                      }`}
                    >
                      <div className="truncate">{st.name_ar}</div>
                    </button>
                  ))}
                </div>

                {commercialSubtype === 'st_8' && (
                  <div className="pt-2">
                    <label className="block text-slate-600 mb-1">حدد نوع النشاط التجاري الآخر:</label>
                    <input
                      type="text"
                      placeholder="اكتب نوع النشاط هنا بالتفصيل..."
                      value={commercialSubtypeOther}
                      onChange={(e) => setCommercialSubtypeOther(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 2: Owner & Delegate Information */}
          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2">
              <span className="w-2 h-2 rounded-full bg-amber-600"></span>
              بيانات المالك والمندوب المفوض
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  اسم المالك <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="الاسم الثلاثي أو صفة المالك..."
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  رقم هاتف المالك <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  placeholder="+966 5X XXX XXXX"
                  value={ownerPhone}
                  onChange={(e) => setOwnerPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900 font-mono text-left"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  اسم المندوب (من ينوب عنه)
                </label>
                <input
                  type="text"
                  placeholder="اسم مدير التشغيل أو المشرف الميداني..."
                  value={delegateName}
                  onChange={(e) => setDelegateName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  رقم هاتف المندوب
                </label>
                <input
                  type="tel"
                  dir="ltr"
                  placeholder="+966 5X XXX XXXX"
                  value={delegatePhone}
                  onChange={(e) => setDelegatePhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900 font-mono text-left"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Multi-Select Services by Department */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                اختيار الخدمات والبنود المطلوبة (متعدد الأقسام)
              </h3>
              <span className="text-amber-800 font-semibold bg-amber-50 px-2.5 py-0.5 rounded-md border border-amber-200">
                المحدد: {selectedServices.length} خدمات
              </span>
            </div>

            {/* Department 1: Elevators */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                  <MoveVertical className="w-4 h-4 text-sky-600" />
                  <span>قسم المصاعد والسلالم الكهربائية</span>
                </div>
                <span className="text-[11px] text-slate-400">صيانة · تركيب · عقود · شهادات</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { cat: 'maintenance', label: 'صيانة دورية' },
                  { cat: 'installation', label: 'توريد وتركيب' },
                  { cat: 'contract', label: 'عقد صيانة سنوي' },
                  { cat: 'certificate', label: 'شهادة أمان وفحص' },
                ].map(({ cat, label }) => {
                  const active = isServiceSelected('elevators', cat as ServiceCategory);
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => handleToggleService('elevators', cat as ServiceCategory, `مصاعد - ${label}`, { count: 2, brand: 'Otis' })}
                      className={`p-2 rounded-lg border text-center transition-all ${
                        active
                          ? 'border-sky-600 bg-sky-50 text-sky-900 font-semibold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        {active && <Check className="w-3.5 h-3.5 text-sky-600" />}
                        <span>{label}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
              {isServiceSelected('elevators', 'contract') && (
                <div className="flex items-center gap-4 bg-sky-50/50 p-2.5 rounded-lg border border-sky-100 mt-2">
                  <span className="text-slate-700 font-medium">عدد المصاعد بالعقد:</span>
                  <input
                    type="number"
                    min="1"
                    defaultValue="2"
                    onChange={(e) => updateServiceDetail('elevators', 'contract', 'elevators_count', parseInt(e.target.value) || 1)}
                    className="w-20 px-2 py-1 border border-slate-300 rounded bg-white text-center font-mono"
                  />
                  <span className="text-slate-500">طراز/الشركة:</span>
                  <input
                    type="text"
                    defaultValue="Otis"
                    onChange={(e) => updateServiceDetail('elevators', 'contract', 'brand', e.target.value)}
                    className="px-2 py-1 border border-slate-300 rounded bg-white flex-1"
                  />
                </div>
              )}
            </div>

            {/* Department 2: Fire Safety & Extinguishers */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                  <Flame className="w-4 h-4 text-rose-600" />
                  <span>قسم السلامة وطفايات الحريق</span>
                </div>
                <span className="text-[11px] text-slate-400">شبكات إنذار · إطفاء · تعبئة وتجديد</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { dept: 'fire_safety', cat: 'certificate', label: 'شهادة دفاع مدني' },
                  { dept: 'fire_safety', cat: 'contract', label: 'عقد صيانة سلامة' },
                  { dept: 'extinguishers', cat: 'refill', label: 'تعبئة واختبار طفايات' },
                  { dept: 'extinguishers', cat: 'renewal', label: 'تجديد واستبدال طفايات' },
                ].map(({ dept, cat, label }) => {
                  const active = isServiceSelected(dept as DepartmentId, cat as ServiceCategory);
                  return (
                    <button
                      key={dept + cat}
                      type="button"
                      onClick={() => handleToggleService(dept as DepartmentId, cat as ServiceCategory, `${label}`, { count: 20 })}
                      className={`p-2 rounded-lg border text-center transition-all ${
                        active
                          ? 'border-rose-600 bg-rose-50 text-rose-900 font-semibold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        {active && <Check className="w-3.5 h-3.5 text-rose-600" />}
                        <span>{label}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
              {isServiceSelected('extinguishers', 'refill') && (
                <div className="flex items-center gap-4 bg-rose-50/50 p-2.5 rounded-lg border border-rose-100 mt-2">
                  <span className="text-slate-700 font-medium">عدد الطفايات التقديري للتعبئة:</span>
                  <input
                    type="number"
                    min="1"
                    defaultValue="25"
                    onChange={(e) => updateServiceDetail('extinguishers', 'refill', 'count', parseInt(e.target.value) || 1)}
                    className="w-24 px-2 py-1 border border-slate-300 rounded bg-white text-center font-mono"
                  />
                  <span className="text-slate-500 text-[11px]">تشمل بودرة ABC وغاز CO2 وفحص الصمامات</span>
                </div>
              )}
            </div>

            {/* Department 3: CCTV & Security */}
            <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  <span>كاميرات المراقبة والحراسات الأمنية</span>
                </div>
                <span className="text-[11px] text-slate-400">أنظمة أمنية · حراسات ورديات</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { dept: 'cctv', cat: 'installation', label: 'تركيب كاميرات مراقبة' },
                  { dept: 'cctv', cat: 'contract', label: 'عقد صيانة كاميرات' },
                  { dept: 'security', cat: 'guards', label: 'تأمين حراسات أمنية' },
                  { dept: 'environmental', cat: 'permit', label: 'تصاريح بيئية ودراسات' },
                ].map(({ dept, cat, label }) => {
                  const active = isServiceSelected(dept as DepartmentId, cat as ServiceCategory);
                  return (
                    <button
                      key={dept + cat}
                      type="button"
                      onClick={() => handleToggleService(dept as DepartmentId, cat as ServiceCategory, `${label}`, { count: dept === 'security' ? 3 : 8 })}
                      className={`p-2 rounded-lg border text-center transition-all ${
                        active
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        {active && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                        <span>{label}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
              {isServiceSelected('security', 'guards') && (
                <div className="flex items-center gap-4 bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100 mt-2">
                  <span className="text-slate-700 font-medium">عدد أفراد الحراسة المطلوبة:</span>
                  <input
                    type="number"
                    min="1"
                    defaultValue="3"
                    onChange={(e) => updateServiceDetail('security', 'guards', 'count', parseInt(e.target.value) || 1)}
                    className="w-20 px-2 py-1 border border-slate-300 rounded bg-white text-center font-mono"
                  />
                  <span className="text-slate-500 text-[11px]">ورديات 24 ساعة مع مشرف موقع أمني</span>
                </div>
              )}
            </div>

            {/* Department 4: Contracting (Handled per spec: "تتطلب مراجعة مدير القسم") */}
            <div className="border border-slate-200 rounded-xl p-4 bg-amber-50/40 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                  <HardHat className="w-4 h-4 text-amber-700" />
                  <span>قسم المقاولات والأعمال المدنية</span>
                </div>
                <span className="text-[11px] text-amber-700 font-medium">تتطلب دراسة ومراجعة مدير القسم</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleToggleService('contracting', 'custom_review', 'أعمال مقاولات تتطلب مراجعة مدير القسم', { notes: 'طلب دراسة تسعير مقاولات' })}
                  className={`px-3 py-2 rounded-lg border text-xs transition-all ${
                    isServiceSelected('contracting', 'custom_review')
                      ? 'border-amber-600 bg-amber-100 text-amber-950 font-semibold'
                      : 'border-amber-300 bg-white text-slate-700 hover:bg-amber-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    {isServiceSelected('contracting', 'custom_review') && <Check className="w-3.5 h-3.5 text-amber-700" />}
                    <span>طلب معاينة وإشراف مدير المقاولات على الموقع</span>
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Section 4: Location, GPS & Address */}
          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2">
              <span className="w-2 h-2 rounded-full bg-amber-600"></span>
              الموقع الجغرافي والإحداثيات
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-600 mb-1">خط العرض (Latitude)</label>
                <input
                  type="text"
                  value={locationLat}
                  dir="ltr"
                  onChange={(e) => {
                    setLocationLat(e.target.value);
                    setMapUrl(`https://maps.google.com/?q=${e.target.value},${locationLng}`);
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-800 text-left"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">خط الطول (Longitude)</label>
                <input
                  type="text"
                  value={locationLng}
                  dir="ltr"
                  onChange={(e) => {
                    setLocationLng(e.target.value);
                    setMapUrl(`https://maps.google.com/?q=${locationLat},${e.target.value}`);
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-800 text-left"
                />
              </div>

              <div>
                <label className="block text-slate-600 mb-1">رابط خريطة Google Maps</label>
                <input
                  type="text"
                  value={mapUrl}
                  dir="ltr"
                  onChange={(e) => setMapUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-800 text-left font-mono truncate text-[11px]"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">
                العنوان المكتوب ووصف الوصول الدقيق <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={2}
                required
                placeholder="المدينة، الحي، اسم الشارع، معالم بارزة قريبة من الموقع..."
                value={addressText}
                onChange={(e) => setAddressText(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900"
              />
            </div>
          </div>

          {/* Section 5: Appointment & Site Photo (Mandatory) & Attachments */}
          <div className="space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 border-b border-slate-100 pb-2">
              <span className="w-2 h-2 rounded-full bg-amber-600"></span>
              موعد زيارة المعاينة وصورة الموقع والمرفقات
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-slate-700 mb-1 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  تاريخ الزيارة المقترح <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={visitDate}
                  onChange={(e) => setVisitDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  وقت الزيارة المطلوب <span className="text-rose-500">*</span>
                </label>
                <input
                  type="time"
                  required
                  value={visitTime}
                  onChange={(e) => setVisitTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-800"
                />
              </div>
            </div>

            {/* Mandatory Site Photo */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-900 flex items-center gap-2">
                  <Camera className="w-4 h-4 text-amber-600" />
                  صورة الموقع (إلزامية للمسوق) <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-500">توثيق واجهة المنشأة أو المدخل</span>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-32 h-24 rounded-lg overflow-hidden border border-slate-300 shrink-0 bg-slate-200">
                  <img
                    src={sitePhotoUrl}
                    alt="معاينة صورة الموقع"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 w-full space-y-2">
                  <input
                    type="url"
                    placeholder="رابط صورة واجهة المنشأة (مباشر)..."
                    value={sitePhotoUrl}
                    onChange={(e) => setSitePhotoUrl(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-800 font-mono text-[11px]"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setSitePhotoUrl('https://images.unsplash.com/photo-1541888946425-d0fbb18615f3?w=800&auto=format&fit=crop&q=80')}
                      className="px-2 py-1 text-[11px] bg-white border border-slate-200 rounded hover:bg-slate-100 text-slate-600"
                    >
                      صورة مبنى تجاري
                    </button>
                    <button
                      type="button"
                      onClick={() => setSitePhotoUrl('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&auto=format&fit=crop&q=80')}
                      className="px-2 py-1 text-[11px] bg-white border border-slate-200 rounded hover:bg-slate-100 text-slate-600"
                    >
                      صورة منشأة صناعية
                    </button>
                    <button
                      type="button"
                      onClick={() => setSitePhotoUrl('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop&q=80')}
                      className="px-2 py-1 text-[11px] bg-white border border-slate-200 rounded hover:bg-slate-100 text-slate-600"
                    >
                      صورة مجمع طبي
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Attachments List */}
            <div className="space-y-2">
              <label className="block text-slate-700 font-medium">المرفقات الإضافية (سجلات، مخططات، رخص)</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="اسم الملف أو المستند (مثال: تقرير_الدفاع_المدني_السابق.pdf)"
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg text-slate-800"
                />
                <button
                  type="button"
                  onClick={handleAddAttachment}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-medium transition-colors"
                >
                  إضافة مرفق
                </button>
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                {attachedFiles.map((file, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md text-[11px] border border-slate-200"
                  >
                    <FileText className="w-3 h-3 text-slate-500" />
                    <span>{file}</span>
                    <button
                      type="button"
                      onClick={() => setAttachedFiles(attachedFiles.filter((_, i) => i !== idx))}
                      className="text-slate-400 hover:text-rose-600"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Point 6: Marketer Estimated Contract Value & Pricing Notes */}
            <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-900 text-xs flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-600"></span>
                  تقدير قيمة العقد والتسعير المبدئي (خاص بالمسوق)
                </label>
                <span className="text-[10px] text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-medium">
                  عمولة متوقعة 5%: {((parseFloat(estimatedValue) || 0) * 0.05).toLocaleString()} ريال
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    القيمة السنوية التقديرية للعقد (ريال)
                  </label>
                  <input
                    type="number"
                    min="1000"
                    step="500"
                    placeholder="24000"
                    value={estimatedValue}
                    onChange={(e) => setEstimatedValue(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    ملاحظات المسوق للتسعير وهيكل العرض
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: خصم 10% للدفعة الكاملة، عقد صيانة شامل قطع الغيار..."
                    value={pricingNotes}
                    onChange={(e) => setPricingNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white text-xs"
                  />
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-slate-700 font-medium mb-1">ملاحظات المسوق التفصيلية</label>
              <textarea
                rows={3}
                placeholder="تفاصيل المبنى، متطلبات المالك الخاصة، أوقات الزيارة المفضلة، أي أجهزة قائمة..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 text-slate-900"
              />
            </div>
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-lg font-medium transition-colors text-xs"
            >
              إلغاء
            </button>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              {/* Point 7: Save as draft */}
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => handleSave(true)}
                className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg border border-slate-300 transition-colors text-xs active:scale-98 disabled:opacity-50"
              >
                حفظ كمسودة (Draft)
              </button>
              {/* Submit and schedule */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 sm:flex-none px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 text-xs"
              >
                {isSubmitting ? (
                  <span>جاري إرسال الطلب وحجز المعاينة...</span>
                ) : (
                  <>
                    <Check className="w-4 h-4 text-amber-400" />
                    <span>إرسال واعتماد موعد المعاينة</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

      </div>

      {/* Mini-Modal: Add New Facility Subtype */}
      {showAddSubtypeModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/40">
          <div className="bg-white rounded-xl shadow-xl p-5 w-full max-w-sm space-y-4 text-right">
            <h4 className="font-bold text-slate-900 text-sm">إضافة نوع نشاط تجاري جديد</h4>
            <p className="text-xs text-slate-500">
              سيتم حفظ هذا النوع في جدول `facility_subtypes` ليكون متاحاً لكافة المسوقين.
            </p>
            <input
              type="text"
              autoFocus
              placeholder="مثال: مجمع أسواق تجارية، فندق، نادي رياضي..."
              value={newSubtypeNameAr}
              onChange={(e) => setNewSubtypeNameAr(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
            />
            <div className="flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowAddSubtypeModal(false)}
                className="px-3 py-1.5 border border-slate-200 rounded-lg text-slate-600"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleAddNewSubtype}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
              >
                إضافة للقائمة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
