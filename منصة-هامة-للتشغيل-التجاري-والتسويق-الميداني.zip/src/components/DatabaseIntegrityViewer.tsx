import React, { useState } from 'react';
import { 
  Database, 
  ShieldCheck, 
  Lock, 
  KeyRound, 
  CheckCircle2, 
  RefreshCw, 
  FileCode2, 
  AlertTriangle,
  Play,
  Terminal,
  Activity
} from 'lucide-react';
import { storageService } from '../services/storageService';

export const DatabaseIntegrityViewer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'sequences' | 'tokens' | 'constraints' | 'asset_trigger' | 'job_locks'>('sequences');
  
  // Interactive sequence test state
  const [seqScope, setSeqScope] = useState('request_FLT');
  const [generatedSeqs, setGeneratedSeqs] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  // Token hashing test state
  const [sampleToken, setSampleToken] = useState('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.user_payload...');
  const [tokenResult, setTokenResult] = useState<{ jti: string; hash: string } | null>(null);

  const refreshTokens = storageService.getRefreshTokens();
  const jobLocks = storageService.getJobLocks();
  const stock = storageService.getStock();

  const handleTestSequenceGenerator = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const year = new Date().getFullYear();
      const seq1 = storageService.nextSequence(seqScope, year);
      const prefix = seqScope.replace('request_', '');
      const formatted = `${prefix}-${year}-${seq1}`;
      setGeneratedSeqs((prev) => [formatted, ...prev]);
      setIsGenerating(false);
    }, 200);
  };

  const handleSimulateTokenHash = () => {
    const jti = 'uuid-' + Math.random().toString(36).substring(2, 10);
    const hash = 'sha256_' + Array.from(sampleToken).map((c) => c.charCodeAt(0).toString(16)).join('').padEnd(64, '0').substring(0, 64);
    setTokenResult({ jti, hash });
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-5 h-5 text-amber-600" />
            <span>سجل الإصلاحات الهندسية وقواعد البيانات (Critical Architecture Fixes)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            استعراض واختبار المعالجات البرمجية الخمس للأخطاء الحرجة المكتشفة في النظام السابق
          </p>
        </div>

        <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>تم تحصين سلامة البيانات 100%</span>
        </span>
      </div>

      {/* Tabs */}
      <div className="flex p-1 bg-slate-100 rounded-xl text-xs font-medium overflow-x-auto">
        <button
          onClick={() => setActiveTab('sequences')}
          className={`px-3.5 py-1.5 rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'sequences' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          1. الترقيم والتزامن (Race Conditions)
        </button>
        <button
          onClick={() => setActiveTab('tokens')}
          className={`px-3.5 py-1.5 rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'tokens' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          2. تحصين Refresh Tokens
        </button>
        <button
          onClick={() => setActiveTab('constraints')}
          className={`px-3.5 py-1.5 rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'constraints' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          3. قيود CHECK والمخزون
        </button>
        <button
          onClick={() => setActiveTab('asset_trigger')}
          className={`px-3.5 py-1.5 rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'asset_trigger' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          4. تشغيل الأصل التلقائي (Trigger)
        </button>
        <button
          onClick={() => setActiveTab('job_locks')}
          className={`px-3.5 py-1.5 rounded-lg transition-all whitespace-nowrap ${
            activeTab === 'job_locks' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          5. أقفال المهام (Job Locks & Heartbeat)
        </button>
      </div>

      {/* Tab 1: Sequences & Concurrency */}
      {activeTab === 'sequences' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-right text-xs">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">
              المشكلة السابقة: تكرار الأرقام تحت التزامن (Race Conditions)
            </h3>
            <p className="text-slate-600 leading-relaxed">
              كانت الـ Triggers القديمة تعتمد على <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">COUNT(*) + 1</code>،
              مما يسبب تكرار أرقام البلاغات والعقود عند دخول طلبين في نفس الجزء من الثانية.
            </p>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 space-y-1">
              <strong className="block font-bold">الحل المعتمد في هامة الجديد:</strong>
              <span>
                جدول Sequences مركزي مع دالة <code className="font-mono">next_sequence()</code> تستخدم قفل تشغيلي 
                <code className="font-mono">SELECT ... FOR UPDATE</code> لضمان تسلسل ترقيم فريد ومستحيل التكرار.
              </span>
            </div>

            {/* Interactive Sequence Generator */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-3">
              <label className="block font-bold text-slate-800">تجربة توليد رقم متسلسل فوري:</label>
              <div className="flex gap-2">
                <select
                  value={seqScope}
                  onChange={(e) => setSeqScope(e.target.value)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800"
                >
                  <option value="request_FLT">بلاغ عطل (FLT)</option>
                  <option value="request_NSB">طلب اشتراك جديد (NSB)</option>
                  <option value="contract">عقد موحد (CON)</option>
                  <option value="subscription">اشتراك سنوي (SUB)</option>
                </select>
                <button
                  onClick={handleTestSequenceGenerator}
                  disabled={isGenerating}
                  className="px-4 py-1.5 bg-slate-900 text-white font-bold rounded-lg hover:bg-slate-800 transition-colors"
                >
                  توليد الرقم التالي
                </button>
              </div>

              {generatedSeqs.length > 0 && (
                <div className="space-y-1 pt-2">
                  <span className="text-[10px] text-slate-400 font-bold block">الأرقام المتولدة حديثاً:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {generatedSeqs.slice(0, 8).map((seq, idx) => (
                      <span key={idx} className="font-mono px-2 py-0.5 bg-white border border-slate-200 rounded text-amber-900 font-bold">
                        {seq}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* DDL Code Snippet */}
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 font-mono text-[11px] space-y-2 overflow-x-auto text-left" dir="ltr">
            <div className="text-amber-400 font-bold">// Central Lock-Safe Sequences Table</div>
            <pre className="text-slate-300 leading-relaxed">{`CREATE TABLE sequences (
  scope VARCHAR(100) NOT NULL,
  year SMALLINT NOT NULL,
  current_value BIGINT NOT NULL DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (scope, year)
) ENGINE=InnoDB;

CREATE FUNCTION next_sequence(p_scope VARCHAR, p_year SMALLINT) 
RETURNS BIGINT
BEGIN
  -- Locking step with FOR UPDATE
  SELECT current_value + 1 INTO v_next 
  FROM sequences 
  WHERE scope = p_scope AND year = p_year 
  FOR UPDATE;
  
  UPDATE sequences SET current_value = v_next 
  WHERE scope = p_scope AND year = p_year;
  
  RETURN v_next;
END;`}</pre>
          </div>
        </div>
      )}

      {/* Tab 2: Refresh Tokens */}
      {activeTab === 'tokens' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-right text-xs">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">
              المشكلة السابقة: تخزين الـ JWT كاملاً كنص صريح في القاعدة
            </h3>
            <p className="text-slate-600">
              في حال تسريب قاعدة البيانات، يتمكن المهاجم من إعادة استخدام التوكنات مباشرة.
            </p>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900">
              <strong className="block font-bold">الحل المعتمد:</strong>
              <span>
                تخزين <code className="font-mono">SHA256(jwt)</code> فقط في جدول <code className="font-mono">refresh_tokens</code> 
                مع توليد <code className="font-mono">jti</code> فريد وربط بصمة الجهاز <code className="font-mono">device_fingerprint</code> 
                وعنوان الـ IP.
              </span>
            </div>

            {/* Token Table Sample */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="p-2.5 bg-slate-50 font-bold text-slate-700 border-b border-slate-200">
                سجلات التوكن المحصنة بالنظام (refresh_tokens):
              </div>
              <div className="p-3 space-y-2 font-mono text-[10px]">
                {refreshTokens.map((rt) => (
                  <div key={rt.id} className="p-2 bg-slate-50 rounded border border-slate-100 space-y-1">
                    <div><span className="text-slate-400">JTI:</span> {rt.jti}</div>
                    <div className="truncate"><span className="text-slate-400">Token Hash:</span> {rt.token_hash}</div>
                    <div className="text-slate-500 font-sans text-[11px]">{rt.device_fingerprint}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* DDL Code */}
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 font-mono text-[11px] space-y-2 overflow-x-auto text-left" dir="ltr">
            <div className="text-amber-400 font-bold">// Security Hardening for Refresh Tokens</div>
            <pre className="text-slate-300 leading-relaxed">{`ALTER TABLE refresh_tokens 
  ADD COLUMN jti CHAR(36) NOT NULL DEFAULT (uuid()) AFTER id,
  ADD COLUMN token_hash CHAR(64) NOT NULL AFTER token,
  ADD COLUMN device_fingerprint VARCHAR(255) DEFAULT NULL,
  ADD COLUMN ip_address VARCHAR(45) DEFAULT NULL,
  ADD UNIQUE KEY uq_jti (jti),
  ADD INDEX idx_token_hash (token_hash);

-- Only SHA256(jwt) stored in application
-- Stolen DB cannot be used to forge user sessions.`}</pre>
          </div>
        </div>
      )}

      {/* Tab 3: Constraints */}
      {activeTab === 'constraints' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-right text-xs">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">
              قيود النزاهة الرياضية (CHECK Constraints)
            </h3>
            <p className="text-slate-600">
              فرض قيود صارمة على مستوى المحرك لمنع أي عمليات إدخال تؤدي إلى كميات سالبة في المخزون أو حجز كميات تفوق المتوفر.
            </p>
            <div className="space-y-2">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="font-bold text-slate-800 block">chk_quantity_non_negative:</span>
                <span className="text-slate-600 font-mono">quantity &gt;= 0</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="font-bold text-slate-800 block">chk_reserved_le_quantity:</span>
                <span className="text-slate-600 font-mono">reserved_quantity &lt;= quantity</span>
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <span className="font-bold text-slate-800 block">chk_dates_order (Visits):</span>
                <span className="text-slate-600 font-mono">actual_end_at &gt;= actual_start_at</span>
              </div>
            </div>
          </div>

          {/* DDL Code */}
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 font-mono text-[11px] space-y-2 overflow-x-auto text-left" dir="ltr">
            <div className="text-amber-400 font-bold">// Database Constraints Enforcement</div>
            <pre className="text-slate-300 leading-relaxed">{`ALTER TABLE warehouse_stock 
  ADD CONSTRAINT chk_quantity_non_negative CHECK (quantity >= 0),
  ADD CONSTRAINT chk_reserved_non_negative CHECK (reserved_quantity >= 0),
  ADD CONSTRAINT chk_reserved_le_quantity CHECK (reserved_quantity <= quantity);

-- Computed View replacing parts.current_stock
CREATE VIEW v_parts_total_stock AS
SELECT p.id, p.part_number, p.name, 
       COALESCE(SUM(ws.quantity), 0) AS total_stock,
       COALESCE(SUM(ws.reserved_quantity), 0) AS total_reserved
FROM parts p
LEFT JOIN warehouse_stock ws ON ws.part_id = p.id
WHERE p.deleted_at IS NULL AND p.is_active = 1
GROUP BY p.id, p.part_number, p.name;`}</pre>
          </div>
        </div>
      )}

      {/* Tab 4: Asset Trigger */}
      {activeTab === 'asset_trigger' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-right text-xs">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">
              إصلاح إغلاق البلاغ وعودة الأصل للتشغيل (trg_asset_status_on_request)
            </h3>
            <p className="text-slate-600">
              في النظام القديم، كان فتح البلاغ يحول الأصل إلى عاطل <code className="font-mono">broken</code>،
              ولكن عند حل البلاغ لم يكن هناك Trigger يعيد الأصل إلى الحالة التشغيلية <code className="font-mono">operational</code>.
            </p>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900">
              <strong className="block font-bold">الحل المعتمد مع فحص عدم وجود بلاغات متوازية:</strong>
              <span>
                عند تحديث حالة البلاغ إلى <code className="font-mono">resolved</code>، يتحقق الـ Trigger من عدم وجود أي بلاغات أخرى مفتوحة على نفس الأصل، ثم يعيد حالته فوراً إلى تشغيل طبيعي.
              </span>
            </div>
          </div>

          {/* DDL Code */}
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 font-mono text-[11px] space-y-2 overflow-x-auto text-left" dir="ltr">
            <div className="text-amber-400 font-bold">// Bi-Directional Asset Status Trigger</div>
            <pre className="text-slate-300 leading-relaxed">{`CREATE TRIGGER trg_asset_status_on_request_resolved
AFTER UPDATE ON service_requests
FOR EACH ROW
BEGIN
  IF NEW.request_type = 'fault' 
     AND NEW.asset_id IS NOT NULL
     AND OLD.status != 'resolved' 
     AND NEW.status = 'resolved' THEN
    
    -- Verify no other open tickets exist on this asset
    IF NOT EXISTS (
      SELECT 1 FROM service_requests 
      WHERE asset_id = NEW.asset_id 
        AND id != NEW.id 
        AND status NOT IN ('resolved','closed','cancelled')
    ) THEN
      UPDATE assets SET status = 'operational' WHERE id = NEW.asset_id;
    END IF;
  END IF;
END;`}</pre>
          </div>
        </div>
      )}

      {/* Tab 5: Job Locks & Heartbeat */}
      {activeTab === 'job_locks' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-right text-xs">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">
              تحصين أقفال المهام المجدولة (Job Locks with Heartbeat)
            </h3>
            <p className="text-slate-600">
              المهام المجدولة الخلفية كجدولة الصيانة وتوليد الفواتير قد تعلق إذا تعطل الخادم أثناء القفل.
            </p>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900">
              <strong className="block font-bold">الحل المعتمد:</strong>
              <span>
                إضافة حقل نبضات القلب <code className="font-mono">heartbeat_at</code> مع Event دوري كل 5 دقائق
                يقوم بتنظيف أي قفل ميت لم يرسل نبضة لأكثر من 10 دقائق.
              </span>
            </div>

            {/* Active locks monitor */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="p-2.5 bg-slate-50 font-bold text-slate-700 border-b border-slate-200 flex justify-between">
                <span>أقفال المهام النشطة (job_locks):</span>
                <span className="text-[10px] text-emerald-600 font-mono">Heartbeat OK</span>
              </div>
              <div className="p-3 space-y-2 font-mono text-[10px]">
                {jobLocks.map((lock, idx) => (
                  <div key={idx} className="p-2 bg-slate-50 rounded border border-slate-100 flex justify-between items-center">
                    <div>
                      <div className="font-bold text-slate-900">{lock.job_name}</div>
                      <div className="text-slate-400">Node: {lock.locked_by}</div>
                    </div>
                    <div className="text-left text-emerald-700 font-bold">
                      {lock.heartbeat_at.substring(11, 19)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* DDL Code */}
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 font-mono text-[11px] space-y-2 overflow-x-auto text-left" dir="ltr">
            <div className="text-amber-400 font-bold">// Stale Lock Cleanup Event with Heartbeat</div>
            <pre className="text-slate-300 leading-relaxed">{`ALTER TABLE job_locks 
  ADD COLUMN heartbeat_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  ADD INDEX idx_locked_until (locked_until);

CREATE EVENT ev_cleanup_stale_locks
ON SCHEDULE EVERY 5 MINUTE
DO BEGIN
  DELETE FROM job_locks 
  WHERE locked_until < NOW() 
    AND heartbeat_at < DATE_SUB(NOW(), INTERVAL 10 MINUTE);
END;`}</pre>
          </div>
        </div>
      )}

    </div>
  );
};
