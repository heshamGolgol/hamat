import React, { useState } from 'react';
import { 
  Users, 
  ShieldCheck, 
  Check, 
  X, 
  Filter, 
  Layers, 
  UserCheck 
} from 'lucide-react';
import { RoleCode } from '../types';
import { ROLES_CATALOG } from '../data/initialData';

interface RolePermissionMatrixProps {
  currentRole: RoleCode;
  onSelectRole: (role: RoleCode) => void;
}

export const RolePermissionMatrix: React.FC<RolePermissionMatrixProps> = ({
  currentRole,
  onSelectRole,
}) => {
  const [activeView, setActiveView] = useState<'matrix' | 'workflows'>('matrix');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [expandedWorkflow, setExpandedWorkflow] = useState<string>('wf_marketing');

  const permissions: { code: string; label: string; category: string; allowedRoles: RoleCode[] }[] = [
    { code: 'system.manage', label: 'إدارة النظام الشاملة', category: 'governance', allowedRoles: ['SYS_ADMIN'] },
    { code: 'roles.manage', label: 'إدارة الأدوار والمستخدمين (19 دوراً)', category: 'governance', allowedRoles: ['SYS_ADMIN'] },
    { code: 'users.manage', label: 'إدارة حسابات الموظفين', category: 'governance', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'HR_MGR'] },
    { code: 'finance.approve_contract', label: 'الاعتماد المالي وتفعيل حساب العميل (النقطة 5)', category: 'commercial', allowedRoles: ['SYS_ADMIN', 'GM', 'FINANCE_MGR'] },
    { code: 'hr.manage_reviews', label: 'إدارة تقييمات الأداء ومستحقات الموظفين (النقطة 9)', category: 'governance', allowedRoles: ['SYS_ADMIN', 'GM', 'HR_MGR'] },
    { code: 'reports.view_all', label: 'استعراض كافة تقارير المنصة', category: 'reports', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'FINANCE_MGR', 'HR_MGR'] },
    { code: 'reports.view_domain', label: 'استعراض تقارير القسم والتسويق', category: 'reports', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'MARKETING_MGR', 'MARKETER', 'REPRESENTATIVE', 'DOMAIN_MGR', 'TEAM_SUPERVISOR', 'SECURITY_MGR', 'ENV_PERMITS_MGR', 'FINANCE_MGR'] },
    { code: 'marketing.manage', label: 'إدارة استراتيجيات التسويق والمسودات', category: 'marketing', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'MARKETING_MGR'] },
    { code: 'clients.create_lead', label: 'تسجيل عميل جديد وحفظ مسودة (المسوق)', category: 'marketing', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'MARKETING_MGR', 'MARKETER', 'REPRESENTATIVE'] },
    { code: 'clients.view_own', label: 'استعراض العملاء وتتبع صفقات الإحالة', category: 'marketing', allowedRoles: ['MARKETING_MGR', 'MARKETER', 'REPRESENTATIVE'] },
    { code: 'facilities.manage', label: 'إدارة المنشآت والأنشطة التجارية', category: 'marketing', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'MARKETING_MGR', 'MARKETER', 'REPRESENTATIVE'] },
    { code: 'service_requests.review', label: 'مراجعة وتوزيع طلبات الخدمات', category: 'marketing', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'MARKETING_MGR', 'DOMAIN_MGR', 'SECURITY_MGR', 'ENV_PERMITS_MGR'] },
    { code: 'quotes.create', label: 'إعداد وتسعير عروض الأسعار (Standard / Premium+)', category: 'commercial', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'REPRESENTATIVE', 'DOMAIN_MGR', 'SECURITY_MGR', 'ENV_PERMITS_MGR'] },
    { code: 'quotes.approve', label: 'اعتماد العروض المجمعة وإرسالها', category: 'commercial', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'MARKETING_MGR', 'DOMAIN_MGR', 'SECURITY_MGR', 'ENV_PERMITS_MGR'] },
    { code: 'subscriptions.manage', label: 'إدارة وتفعيل الاشتراكات السنوية', category: 'commercial', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'FINANCE_MGR', 'DOMAIN_MGR'] },
    { code: 'visits.schedule', label: 'جدولة زيارات المعاينة والصيانة', category: 'operations', allowedRoles: ['SYS_ADMIN', 'DOMAIN_MGR', 'TEAM_SUPERVISOR'] },
    { code: 'visits.assign_team', label: 'توزيع وإسناد الزيارة للفريق (صلاحية المشرف - النقطة 4)', category: 'operations', allowedRoles: ['SYS_ADMIN', 'DOMAIN_MGR', 'TEAM_SUPERVISOR'] },
    { code: 'visits.assign_technician', label: 'توزيع وإسناد الزيارة للفني (صلاحية قائد الفريق - النقطة 4)', category: 'operations', allowedRoles: ['SYS_ADMIN', 'MAINT_TEAM_LEADER', 'FAULT_TEAM_LEADER'] },
    { code: 'visits.execute', label: 'تنفيذ الزيارة بالمسح المزدوج وتعبئة التقرير', category: 'operations', allowedRoles: ['SYS_ADMIN', 'MAINT_TEAM_LEADER', 'MAINT_TECHNICIAN', 'FAULT_TEAM_LEADER', 'FAULT_TECHNICIAN'] },
    { code: 'qr.generate', label: 'توليد رموز QR للمواقع والخدمات', category: 'operations', allowedRoles: ['SYS_ADMIN', 'DOMAIN_MGR', 'TEAM_SUPERVISOR', 'SECURITY_MGR', 'ENV_PERMITS_MGR'] },
    { code: 'qr.scan', label: 'مسح QR المزدوج (بدء وإنهاء الزيارة بالثانية)', category: 'operations', allowedRoles: ['SYS_ADMIN', 'MAINT_TEAM_LEADER', 'MAINT_TECHNICIAN', 'FAULT_TEAM_LEADER', 'FAULT_TECHNICIAN', 'GUARD', 'ENV_INSPECTOR'] },
    { code: 'parts.consume', label: 'صرف واستهلاك قطع الغيار بالزيارة', category: 'operations', allowedRoles: ['SYS_ADMIN', 'MAINT_TEAM_LEADER', 'MAINT_TECHNICIAN', 'FAULT_TEAM_LEADER', 'FAULT_TECHNICIAN'] },
    { code: 'custody.manage', label: 'إدارة عُهد المعدات مع قادة الفرق (النقطة 16)', category: 'operations', allowedRoles: ['SYS_ADMIN', 'DOMAIN_MGR', 'TEAM_SUPERVISOR', 'MAINT_TEAM_LEADER', 'FAULT_TEAM_LEADER'] },
    { code: 'inventory.manage', label: 'إدارة المستودعات والتوريد', category: 'operations', allowedRoles: ['SYS_ADMIN', 'DOMAIN_MGR'] },
    { code: 'security.shifts.manage', label: 'تخطيط ورديات الحراسات الأمنية', category: 'security', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'SECURITY_MGR'] },
    { code: 'security.shifts.view', label: 'استعراض جدول الحراسة الأمنية', category: 'security', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'SECURITY_MGR', 'GUARD', 'CLIENT', 'REFERRED_CLIENT'] },
    { code: 'permits.manage', label: 'إصدار واعتماد التراخيص البيئية', category: 'environmental', allowedRoles: ['SYS_ADMIN', 'GM', 'ADMIN_MGR', 'ENV_PERMITS_MGR', 'ENV_INSPECTOR'] },
    { code: 'loyalty.manage', label: 'إدارة محافظ ولاء العملاء والاسترداد (النقطة 10)', category: 'commercial', allowedRoles: ['SYS_ADMIN', 'GM', 'MARKETING_MGR', 'FINANCE_MGR'] },
    { code: 'loyalty.view_own', label: 'استعراض رصيد نقاط الولاء واستبدالها', category: 'commercial', allowedRoles: ['MARKETING_MGR', 'MARKETER', 'CLIENT', 'REFERRED_CLIENT'] },
    { code: 'feedback.submit', label: 'تقييم جودة الخدمة من العميل', category: 'client', allowedRoles: ['CLIENT', 'REFERRED_CLIENT'] },
  ];

  const filteredPermissions = permissions.filter((p) => {
    if (filterCategory === 'all') return true;
    return p.category === filterCategory;
  });

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-5 text-right text-xs">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-600" />
            <span>مصفوفة الصلاحيات والهيكل التنظيمي (17 دوراً × 27 صلاحية رئيسية)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            منع الاختراق الأفقي والعمودي عبر عزل النطاقات (scope_domain) والتسلسل الهرمي (role_hierarchy)
          </p>
        </div>
      </div>

      {/* Top View Selector: Matrix vs Detailed Workflows */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex p-1 bg-slate-100 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveView('matrix')}
            className={`px-4 py-1.5 rounded-lg transition-all ${
              activeView === 'matrix' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            مصفوفة الصلاحيات (17 دوراً)
          </button>
          <button
            onClick={() => setActiveView('workflows')}
            className={`px-4 py-1.5 rounded-lg transition-all ${
              activeView === 'workflows' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            دليل العمليات التشغيلية (8 مسارات عمل)
          </button>
        </div>

        {activeView === 'matrix' && (
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-medium">
            {[
              { id: 'all', label: 'كافة الصلاحيات' },
              { id: 'marketing', label: 'التسويق والعملاء' },
              { id: 'commercial', label: 'العقود والعروض' },
              { id: 'operations', label: 'التشغيل والزيارات' },
              { id: 'security', label: 'الحراسات والتصاريح' },
              { id: 'governance', label: 'الحوكمة والإدارة' },
            ].map((c) => (
              <button
                key={c.id}
                onClick={() => setFilterCategory(c.id)}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  filterCategory === c.id ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {activeView === 'matrix' ? (
        <>
          {/* Current Active Role Highlight */}
          <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-amber-700" />
              <span className="font-bold text-amber-950">
                الدور النشط حالياً في المعاينة: {ROLES_CATALOG.find((r) => r.code === currentRole)?.title_ar} ({currentRole})
              </span>
            </div>
            <span className="text-[11px] text-amber-800">
              المسموح له: {permissions.filter((p) => p.allowedRoles.includes(currentRole)).length} صلاحية
            </span>
          </div>

          {/* Permissions Matrix Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden overflow-x-auto">
            <table className="w-full text-right text-[11px]">
              <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 sticky right-0 bg-slate-50 z-10 w-64">الصلاحية / الوظيفة</th>
                  {ROLES_CATALOG.map((role) => (
                    <th
                      key={role.code}
                      onClick={() => onSelectRole(role.code)}
                      className={`py-2 px-2 text-center cursor-pointer transition-colors whitespace-nowrap ${
                        currentRole === role.code
                          ? 'bg-amber-100 text-amber-950 font-bold'
                          : 'hover:bg-slate-100 text-slate-600'
                      }`}
                      title={`${role.title_ar} (انقر للتبديل)`}
                    >
                      <div className="font-mono text-[10px]">{role.code}</div>
                      <div className="text-[9px] font-normal truncate max-w-[80px]">{role.title_ar}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPermissions.map((perm) => (
                  <tr key={perm.code} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-2.5 px-3 font-medium text-slate-900 sticky right-0 bg-white z-10 border-l border-slate-200/60">
                      <div>{perm.label}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{perm.code}</div>
                    </td>
                    {ROLES_CATALOG.map((role) => {
                      const isAllowed = perm.allowedRoles.includes(role.code);
                      const isCurrent = currentRole === role.code;
                      return (
                        <td
                          key={role.code}
                          className={`py-2 px-2 text-center ${
                            isCurrent ? 'bg-amber-50/40 font-bold' : ''
                          }`}
                        >
                          {isAllowed ? (
                            <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-100 text-emerald-800">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </span>
                          ) : (
                            <span className="text-slate-200 text-xs">—</span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        /* Workflows Deep-Dive Guide */
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Workflow 1 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #01</span>
                <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-800 text-[10px]">MARKETER</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">1. دورة التقاط الفرصة والتسجيل الميداني (Marketing Lead Funnel)</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                يقوم المسوق الميداني بجمع بيانات المنشأة (حكومي/تجاري/سكني)، واختيار الخدمات متعددة الأقسام (مصاعد، سلامة، كاميرات، بيئة، حراسات، طفايات)، وتحديد إحداثيات الموقع، وإلزامية إرفاق صورة الموقع وكروكي المخطط، مع اقتراح موعد وتاريخ الزيارة. يُحفظ الطلب بجدول <code className="font-mono">client_service_requests</code>.
              </p>
            </div>

            {/* Workflow 2 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #02</span>
                <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 text-[10px]">MARKETING_MGR</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">2. المراجعة وتأكيد الموعد وتوليد الزيارة التشغيلية (Inspection Trigger)</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                يراجع مدير التسويق الطلبات ويؤكد الموعد. يطلق النظام Trigger تلقائي <code className="font-mono">trg_appointment_confirmed_to_visit</code> لتوليد زيارة معاينة فورية بجدول <code className="font-mono">visits</code> بمصدر <code className="font-mono">source_type = 'marketing'</code> ونوع <code className="font-mono">inspection</code> وإشعار المسوق.
              </p>
            </div>

            {/* Workflow 3 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #03</span>
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px]">TECHNICIAN & QR</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">3. المعاينة الميدانية والتحقق الجغرافي برمز الـ QR</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                عند وصول الفني أو فريق المعاينة لموقع العميل، يقوم بمسح رمز QR الموقع <code className="font-mono">HAMA-FAC-XXXX-SITE</code> لإثبات الحضور وبدء الزيارة. يعاين الأجهزة (طراز المصاعد، كواشف الحريق، نقاط الكاميرات) ويرفع التقرير الفني وقائمة التدقيق.
              </p>
            </div>

            {/* Workflow 4 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #04</span>
                <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px]">DOMAIN_MGR × 3</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">4. تسعير البنود وتجميع عرض السعر الموحد (Quote Formulation)</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                يدرس كل مدير قسم (مصاعد، سلامة، كاميرات، إلخ) تقرير المعاينة ويُدخل أسعار بنوده في جدول <code className="font-mono">quote_items</code>. تُجمع هذه البنود في عرض سعر موحد شامل لضريبة القيمة المضافة (15%) يُرسل للعميل عبر البوابة ورسائل الواتساب.
              </p>
            </div>

            {/* Workflow 5 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #05</span>
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px]">CLIENT & SYSTEM</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">5. قبول العرض والتحويل التلقائي للاشتراك السنوي (Auto Subscription)</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                عند موافقة العميل على العرض، يطلق <code className="font-mono">trg_quote_accepted_to_subscription</code> تلقائياً: إنشاء اشتراك سنوي <code className="font-mono">subscriptions</code>، وتوليد بنود الاشتراك <code className="font-mono">subscription_items</code>، وتفعيل حالة الطلبات إلى <code className="font-mono">activated</code>، واحتساب مكافأة وعمولة المسوق.
              </p>
            </div>

            {/* Workflow 6 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #06</span>
                <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 text-[10px]">OPERATIONS</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">6. خطط الصيانة الدورية واستهلاك قطع الغيار الآمن</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                تتولد زيارات دورية وقائية منتظمة (شهرية/ربع سنوية). يتم تزويد الفرق بقطع الغيار المربوطة بنوع المنشأة وقسمها (<code className="font-mono">part_facility_types</code>). تضمن قيود <code className="font-mono">chk_quantity_non_negative</code> استحالة تسجيل مخزون سالب أو حجز زائد.
              </p>
            </div>

            {/* Workflow 7 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #07</span>
                <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 text-[10px]">EMERGENCY / FAULTS</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">7. بلاغات الأعطال والطوارئ والـ Trigger العكسي للأصل</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                عند بلاغ العطل يتحول الأصل لـ <code className="font-mono">broken</code>. وعند حل البلاغ واعتماده ينطلق Trigger العكسي <code className="font-mono">trg_asset_status_on_request_resolved</code> للتحقق من عدم وجود بلاغات متوازية أخرى وإعادة الأصل فوراً إلى <code className="font-mono">operational</code>.
              </p>
            </div>

            {/* Workflow 8 */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-amber-800 text-[10px] font-bold">WORKFLOW #08</span>
                <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-800 text-[10px]">SECURITY & PERMITS</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs">8. جدولة الحراسات والتصاريح البيئية</h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                إدارة أفراد الحراسة الأمنية والورديات لمواقع المنشآت الصناعية والطبية، وتتبع التراخيص البيئية والفحوصات المخبرية واشتراطات الالتزام عبر مفتشي ومسؤولي البيئة المعنيين.
              </p>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
