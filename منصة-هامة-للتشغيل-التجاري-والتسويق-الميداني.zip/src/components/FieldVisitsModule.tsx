import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  QrCode, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  Wrench, 
  FileCheck, 
  Plus, 
  Search,
  ExternalLink,
  ChevronDown,
  Navigation,
  Timer,
  Play,
  Square,
  DollarSign,
  UserCheck,
  TrendingUp,
  Cpu
} from 'lucide-react';
import { Visit, DispatchSuggestion } from '../types';
import { storageService } from '../services/storageService';

export const FieldVisitsModule: React.FC = () => {
  const [filterSource, setFilterSource] = useState<string>('all');
  const [selectedVisitForReport, setSelectedVisitForReport] = useState<Visit | null>(null);
  const [selectedVisitForDispatch, setSelectedVisitForDispatch] = useState<Visit | null>(null);
  const [isScanningQR, setIsScanningQR] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<string>('');
  const [selectedCostVisit, setSelectedCostVisit] = useState<Visit | null>(null);

  // Report Form state
  const [reportFindings, setReportFindings] = useState<string>('');
  const [reportNotes, setReportNotes] = useState<string>('');
  const [selectedPartId, setSelectedPartId] = useState<string>('');
  const [partQty, setPartQty] = useState<number>(1);
  const [consumedParts, setConsumedParts] = useState<{ part_id: string; part_name: string; quantity: number }[]>([]);
  const [actionError, setActionError] = useState<string>('');

  const visits = storageService.getVisits();
  const parts = storageService.getParts();
  const stock = storageService.getStock();

  const filteredVisits = visits.filter((v) => {
    if (filterSource === 'all') return true;
    return v.source_type === filterSource;
  });

  // Point 14: Dual QR scan handler (1st scan = Start visit, 2nd scan = End visit)
  const handleDualQRScan = (visit: Visit) => {
    setIsScanningQR(visit.id);
    setTimeout(() => {
      const qrCode = visit.site_qr_code || 'HAMA-FAC-1001-SITE';
      const res = storageService.scanQRCode(qrCode, visit.assigned_technician_name || 'فني الصيانة: م. عبد الله المالكي');
      setScanResult(res.message);
      setIsScanningQR(null);

      // If finished session, open cost modal or report
      if (res.scanPhase === 'visit_end') {
        const updated = storageService.getVisits().find((v) => v.id === visit.id);
        if (updated) setSelectedCostVisit(updated);
      }

      setTimeout(() => setScanResult(''), 5000);
    }, 600);
  };

  const handleOpenReportModal = (visit: Visit) => {
    setSelectedVisitForReport(visit);
    setReportFindings('');
    setReportNotes('');
    setConsumedParts([]);
    setActionError('');
  };

  const handleOpenDispatchModal = (visit: Visit) => {
    setSelectedVisitForDispatch(visit);
  };

  const handleAssignDispatch = (visitId: string, technicianId: string) => {
    storageService.assignVisit(visitId, technicianId);
    setSelectedVisitForDispatch(null);
    setScanResult('تم توجيه وإسناد الفني وأقرب فريق بنجاح!');
    setTimeout(() => setScanResult(''), 4000);
  };

  const handleAddPartConsumption = () => {
    if (!selectedPartId) return;
    const part = parts.find((p) => p.id === selectedPartId);
    if (!part) return;

    const currentStock = stock.find((s) => s.part_id === selectedPartId);
    if (!currentStock || currentStock.available_quantity < partQty) {
      setActionError(`الكمية المتاحة في المستودع غير كافية (المتاح: ${currentStock?.available_quantity || 0})`);
      return;
    }

    setConsumedParts([...consumedParts, { part_id: part.id, part_name: part.name_ar, quantity: partQty }]);
    setSelectedPartId('');
    setPartQty(1);
    setActionError('');
  };

  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVisitForReport) return;

    try {
      storageService.completeVisitInspection(selectedVisitForReport.id, {
        findings: reportFindings ? reportFindings.split('\n').filter(Boolean) : ['تمت المعاينة الفنية بنجاح دون ملاحظات'],
        inspection_notes: reportNotes || 'تقرير فني معتمد',
        parts_consumed: consumedParts,
      });

      setSelectedVisitForReport(null);
    } catch (err: any) {
      setActionError(err.message || 'حدث خطأ أثناء حفظ تقرير الزيارة');
    }
  };

  // Helper format seconds to HH:MM:SS
  const formatDuration = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-900">
              وحدة الزيارات الميدانية والتشغيل (Field Operations & Visits)
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-900 border border-sky-200">
              مسح QR مزدوج + تسعير بالثانية
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            إسناد تسلسلي هرمي، توجيه GPS لأقرب فريق، وتوثيق دقيق لبدء وإنهاء الزيارة وحساب التكلفة بالثانية
          </p>
        </div>

        {/* Source Filter */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-medium">
          {[
            { id: 'all', label: 'كافة الزيارات' },
            { id: 'marketing', label: 'معاينة تسويقية (Marketing)' },
            { id: 'maintenance_plan', label: 'صيانة دورية (Plan)' },
            { id: 'emergency', label: 'طوارئ وأعطال' },
          ].map((s) => (
            <button
              key={s.id}
              onClick={() => setFilterSource(s.id)}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterSource === s.id ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Visits Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">
            سجل الزيارات الميدانية ومسح الـ QR المزدوج (visits)
          </h3>
          <span className="text-xs text-slate-500">{filteredVisits.length} زيارة مسجلة</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200 font-semibold">
              <tr>
                <th className="py-3 px-4">رقم الزيارة</th>
                <th className="py-3 px-4">المنشأة والموقع</th>
                <th className="py-3 px-4">نوع ومصدر الزيارة</th>
                <th className="py-3 px-4">الفريق والفني المسند</th>
                <th className="py-3 px-4 text-center">المسح المزدوج (Dual QR)</th>
                <th className="py-3 px-4">مدة الزيارة والتكلفة</th>
                <th className="py-3 px-4 text-center">الإجراء الميداني</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredVisits.map((visit) => {
                const isSessionActive = visit.session_status === 'active';
                const isSessionEnded = visit.session_status === 'ended' || visit.status === 'completed';
                const totalSeconds = visit.duration_seconds || 0;

                return (
                  <tr key={visit.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      <div>{visit.visit_number}</div>
                      {visit.emergency_token_deducted && (
                        <span className="text-[10px] text-amber-700 font-sans font-medium">⚡ رمز طوارئ</span>
                      )}
                    </td>
                    
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{visit.facility_name}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate max-w-[180px]">{visit.site_address}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">
                        {visit.visit_type === 'inspection' ? 'معاينة فنية ودراسة تسعير' : 'صيانة دورية وقائية'}
                      </div>
                      <div className="text-[11px] mt-0.5">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono ${
                          visit.source_type === 'marketing'
                            ? 'bg-amber-100 text-amber-900 font-semibold'
                            : 'bg-sky-100 text-sky-900'
                        }`}>
                          source: {visit.source_type}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{visit.assigned_technician_name}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        فريق: {visit.assigned_team_name || 'الفريق السريع 1'}
                      </div>
                      {/* Suggest nearest technician button (Point 13) */}
                      {visit.status !== 'completed' && (
                        <button
                          onClick={() => handleOpenDispatchModal(visit)}
                          className="mt-1 text-sky-700 hover:text-sky-800 text-[10px] font-semibold flex items-center gap-1"
                        >
                          <Navigation className="w-3 h-3" />
                          <span>اقتراح أقرب فريق GPS</span>
                        </button>
                      )}
                    </td>

                    {/* Point 14: Dual QR Scan UI */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex flex-col items-center gap-1">
                        {isSessionEnded ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>مكتملة (مسح البدء والإنهاء)</span>
                          </span>
                        ) : isSessionActive ? (
                          <button
                            onClick={() => handleDualQRScan(visit)}
                            disabled={isScanningQR === visit.id}
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold shadow-xs transition-colors active:scale-98"
                          >
                            <Square className="w-3.5 h-3.5 fill-white" />
                            <span>مسح QR الإنهاء (Stop)</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleDualQRScan(visit)}
                            disabled={isScanningQR === visit.id}
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-xs transition-colors active:scale-98"
                          >
                            <Play className="w-3.5 h-3.5 fill-white" />
                            <span>مسح QR البدء (Start)</span>
                          </button>
                        )}

                        <span className="text-[10px] text-slate-400 font-mono">
                          {isSessionActive ? 'العداد يعمل حالياً...' : isSessionEnded ? `المدة: ${formatDuration(totalSeconds)}` : 'بانتظار وصول الفني'}
                        </span>
                      </div>
                    </td>

                    {/* Point 15: Exact Second-by-Second Cost */}
                    <td className="py-3.5 px-4 tabular-nums">
                      <div className="font-mono font-bold text-slate-900 flex items-center gap-1">
                        <Timer className="w-3.5 h-3.5 text-slate-400" />
                        <span>{formatDuration(totalSeconds)}</span>
                      </div>
                      {visit.cost_calculation ? (
                        <button
                          onClick={() => setSelectedCostVisit(visit)}
                          className="text-[10px] text-amber-800 font-bold hover:underline block mt-0.5"
                        >
                          التكلفة: {visit.cost_calculation.total_cost_sar.toLocaleString()} ريال (عرض)
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-400">قيد الاحتساب</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {visit.status !== 'completed' ? (
                        <button
                          onClick={() => handleOpenReportModal(visit)}
                          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[11px] font-semibold transition-colors shadow-2xs"
                        >
                          تقرير المعاينة
                        </button>
                      ) : (
                        <div className="text-[11px] text-emerald-800 font-semibold flex items-center justify-center gap-1">
                          <FileCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>التقرير معتمد</span>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* QR Scanning Feedback Toast */}
      {scanResult && (
        <div className="fixed bottom-6 left-6 z-50 p-4 bg-slate-900 text-white rounded-xl shadow-2xl flex items-center gap-3 border border-slate-700 animate-in fade-in slide-in-from-bottom-4">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-medium">{scanResult}</span>
        </div>
      )}

      {/* Point 13: Nearest GPS Dispatch Modal */}
      {selectedVisitForDispatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden text-right text-xs">
            <div className="p-4 border-b border-slate-200 bg-sky-50/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Navigation className="w-5 h-5 text-sky-700" />
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    اقتراح وتوجيه أقرب فريق صيانة (Live GPS Dispatch)
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    الزيارة: #{selectedVisitForDispatch.visit_number} · منشأة: {selectedVisitForDispatch.facility_name}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedVisitForDispatch(null)}
                className="text-slate-400 hover:text-slate-700 text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="text-slate-600 text-xs">
                يتم حساب الترتيب الذكي استناداً إلى مسافة Haversine اللحظية، زمن الوصول المتوقع (ETA)، وعبء العمل الحالي:
              </div>

              <div className="space-y-2.5">
                {storageService.suggestTechniciansForVisit(selectedVisitForDispatch.id).map((item, idx) => (
                  <div
                    key={item.technician_id}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-sky-300 bg-white flex items-center justify-between gap-4 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                        idx === 0 ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-slate-100 text-slate-700'
                      }`}>
                        #{idx + 1}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <span>{item.technician_name}</span>
                          <span className="text-[10px] text-slate-400">({item.team_name})</span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-0.5">
                          <span>المسافة: <strong className="text-slate-800 font-mono">{item.distance_km} كم</strong></span>
                          <span>زمن الوصول: <strong className="text-sky-700 font-mono">~{item.estimated_arrival_minutes} دقيقة</strong></span>
                          <span>المهام الجارية: <strong className="text-slate-800 font-mono">{item.current_workload}</strong></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs text-amber-800 bg-amber-50 px-2 py-1 rounded">
                        Score: {item.score}
                      </span>
                      <button
                        onClick={() => handleAssignDispatch(selectedVisitForDispatch.id, item.technician_id)}
                        className="px-3.5 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-lg font-bold text-xs shadow-xs transition-colors"
                      >
                        إسناد وتوجيه
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Point 15: Second-by-Second Cost Breakdown Modal */}
      {selectedCostVisit && selectedCostVisit.cost_calculation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg p-6 space-y-4 text-right text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-amber-600" />
                  <span>تفصيل تكلفة الزيارة بالثانية (visit_cost_items)</span>
                </h3>
                <span className="text-slate-400 text-[11px]">الزيارة #{selectedCostVisit.visit_number}</span>
              </div>
              <button onClick={() => setSelectedCostVisit(null)} className="text-slate-400 hover:text-slate-700">✕</button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5">
              <div className="flex justify-between items-center text-slate-700">
                <span>مدة العمل الميداني بالثواني:</span>
                <span className="font-mono font-bold text-slate-900">
                  {selectedCostVisit.cost_calculation.duration_seconds} ثانية ({formatDuration(selectedCostVisit.cost_calculation.duration_seconds)})
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span>تكلفة العمالة الفنية (120 ريال/ساعة ÷ 3600 × الثواني):</span>
                <span className="font-mono font-bold text-slate-900">
                  {selectedCostVisit.cost_calculation.labor_cost_sar.toFixed(2)} ريال
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span>تكلفة تشغيل المركبة والوقود (40 ريال/ساعة ÷ 3600 × الثواني):</span>
                <span className="font-mono font-bold text-slate-900">
                  {selectedCostVisit.cost_calculation.vehicle_operating_cost_sar.toFixed(2)} ريال
                </span>
              </div>
              <div className="flex justify-between items-center text-slate-700">
                <span>تكلفة قطع الغيار المستهلكة:</span>
                <span className="font-mono font-bold text-slate-900">
                  {selectedCostVisit.cost_calculation.parts_cost_sar.toFixed(2)} ريال
                </span>
              </div>
              <div className="flex justify-between items-center font-bold text-sm text-slate-900 pt-2 border-t border-slate-200">
                <span>إجمالي التكلفة التشغيلية للزيارة:</span>
                <span className="font-mono text-amber-900 text-base">
                  {selectedCostVisit.cost_calculation.total_cost_sar.toFixed(2)} ريال
                </span>
              </div>
            </div>

            <div className="pt-2 text-center">
              <button
                onClick={() => setSelectedCostVisit(null)}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold"
              >
                إغلاق التفاصيل
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {selectedVisitForReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col text-right text-xs">
            
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70 rounded-t-2xl">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">
                  رفع تقرير المعاينة الفنية للزيارة #{selectedVisitForReport.visit_number}
                </h3>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  منشأة: {selectedVisitForReport.facility_name} · الفني: {selectedVisitForReport.assigned_technician_name}
                </p>
              </div>
              <button
                onClick={() => setSelectedVisitForReport(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitReport} className="p-6 space-y-4 overflow-y-auto flex-1">
              {actionError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{actionError}</span>
                </div>
              )}

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  الملاحظات الفنية ونتائج المعاينة الميدانية (سطر لكل نقطة) <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="مثال:
- فحص المصاعد: عدد 2 بحالة جيدة و2 بحاجة صيانة لوحة التحكم
- فحص أنظمة الحريق: ضغط منخفض في الطفايات
- التوصيات: اعتماد باقة الصيانة الشاملة"
                  value={reportFindings}
                  onChange={(e) => setReportFindings(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              {/* Spare Parts Consumption with Non-Negative Inventory Constraint */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">
                    استهلاك قطع غيار من المستودع (تحقق عدم السالبية chk_quantity_non_negative)
                  </label>
                  <span className="text-slate-400 text-[10px]">اختياري للزيارات</span>
                </div>

                <div className="flex gap-2">
                  <select
                    value={selectedPartId}
                    onChange={(e) => setSelectedPartId(e.target.value)}
                    className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800"
                  >
                    <option value="">اختر قطعة الغيار...</option>
                    {parts.map((p) => {
                      const pStock = stock.find((s) => s.part_id === p.id);
                      return (
                        <option key={p.id} value={p.id}>
                          {p.name_ar} (المتاح: {pStock?.available_quantity || 0} {p.unit})
                        </option>
                      );
                    })}
                  </select>

                  <input
                    type="number"
                    min="1"
                    value={partQty}
                    onChange={(e) => setPartQty(parseInt(e.target.value) || 1)}
                    className="w-20 px-2 py-1.5 border border-slate-300 rounded-lg text-center font-mono"
                  />

                  <button
                    type="button"
                    onClick={handleAddPartConsumption}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-medium"
                  >
                    إضافة للتقرير
                  </button>
                </div>

                {consumedParts.length > 0 && (
                  <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg bg-white overflow-hidden">
                    {consumedParts.map((item, idx) => (
                      <div key={idx} className="p-2 flex items-center justify-between text-[11px]">
                        <span className="font-medium text-slate-800">{item.part_name}</span>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-slate-600">الكمية: {item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => setConsumedParts(consumedParts.filter((_, i) => i !== idx))}
                            className="text-rose-500 hover:text-rose-700"
                          >
                            حذف
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  الملاحظات العامة وتوصيات التسعير
                </label>
                <textarea
                  rows={2}
                  placeholder="ملاحظات تفيد مدير التسويق ومدراء الأقسام عند إعداد عرض السعر النهائي..."
                  value={reportNotes}
                  onChange={(e) => setReportNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setSelectedVisitForReport(null)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold shadow-xs transition-colors"
                >
                  اعتماد التقرير وإنهاء الزيارة
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
