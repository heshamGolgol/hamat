import React, { useState } from 'react';
import { 
  Package, 
  QrCode, 
  Warehouse, 
  CheckCircle2, 
  Filter, 
  Search, 
  Building2, 
  AlertTriangle, 
  ShieldCheck, 
  Scan, 
  ExternalLink,
  Plus
} from 'lucide-react';
import { DepartmentId, FacilityType } from '../types';
import { storageService } from '../services/storageService';
import { DEPARTMENTS } from '../data/initialData';

export const InventoryAndQRModule: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'qr'>('inventory');
  
  // Inventory filters
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [selectedFacilityType, setSelectedFacilityType] = useState<string>('all');
  
  // QR state
  const [scannerInput, setScannerInput] = useState('');
  const [scanResult, setScanResult] = useState<{ success: boolean; message: string } | null>(null);

  const parts = storageService.getParts();
  const stock = storageService.getStock();
  const qrCodes = storageService.getQRCodes();

  // Filter parts based on department and facility type
  const filteredParts = parts.filter((p) => {
    const matchesDept = selectedDept === 'all' || p.department_ids.includes(selectedDept as DepartmentId);
    const matchesFacility = selectedFacilityType === 'all' || p.facility_types.includes(selectedFacilityType as FacilityType);
    return matchesDept && matchesFacility;
  });

  const handleTestScan = (qrString: string) => {
    const res = storageService.scanQRCode(qrString, 'الفني الميداني / المشرف');
    setScanResult(res);
    setTimeout(() => setScanResult(null), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200">
        <div>
          <h1 className="text-lg font-bold text-slate-900">
            وحدة إدارة المخزون ورموز الـ QR (Inventory & QR Matrix)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            ربط قطع الغيار بالقطاعات وأنواع المنشآت، مراقبة سلامة الأرصدة، وتوثيق الحضور الميداني بالـ QR
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex p-1 bg-slate-100 rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-4 py-1.5 rounded-lg transition-all ${
              activeTab === 'inventory' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            كتالوج القطع والمستودعات ({parts.length})
          </button>
          <button
            onClick={() => setActiveTab('qr')}
            className={`px-4 py-1.5 rounded-lg transition-all ${
              activeTab === 'qr' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            رموز الـ QR للمواقع والأصول ({qrCodes.length})
          </button>
        </div>
      </div>

      {/* Inventory Tab */}
      {activeTab === 'inventory' && (
        <div className="space-y-5">
          
          {/* Smart Filter per prompt: Filter by department and facility type */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                تصفية ذكية حسب القسم والقطاع:
              </span>

              {/* Department */}
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800"
              >
                <option value="all">كافة الأقسام</option>
                {DEPARTMENTS.map((d) => (
                  <option key={d.id} value={d.id}>{d.name_ar}</option>
                ))}
              </select>

              {/* Facility Type */}
              <select
                value={selectedFacilityType}
                onChange={(e) => setSelectedFacilityType(e.target.value)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800"
              >
                <option value="all">كافة أنواع المنشآت</option>
                <option value="commercial">تجاري (مستشفيات، مولات، مستودعات)</option>
                <option value="government">حكومي</option>
                <option value="residential">سكني</option>
              </select>
            </div>

            <div className="text-[11px] text-slate-500 font-medium bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
              ⚡ ميزة النظام: يظهر للفني والمشرف فقط القطع المخصصة لنوع المنشأة والقسم لتفادي أخطاء الصيانة
            </div>
          </div>

          {/* Warehouse Stock Status Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredParts.map((part) => {
              const partStocks = stock.filter((s) => s.part_id === part.id);
              const totalStock = partStocks.reduce((sum, s) => sum + s.quantity, 0);
              const totalReserved = partStocks.reduce((sum, s) => sum + s.reserved_quantity, 0);
              const totalAvailable = totalStock - totalReserved;

              return (
                <div
                  key={part.id}
                  className="bg-white rounded-xl border border-slate-200 p-4 space-y-3 shadow-2xs hover:border-slate-300 transition-all text-right text-xs"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="font-mono text-slate-400 text-[10px]">{part.part_number}</span>
                      <h3 className="font-bold text-slate-900 text-xs mt-0.5 line-clamp-1">{part.name_ar}</h3>
                      <p className="text-slate-400 font-mono text-[10px] mt-0.5">{part.name_en}</p>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[10px]">
                      {part.unit_cost} ريال/{part.unit}
                    </span>
                  </div>

                  {/* Departments and facility types tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {part.department_ids.map((dId) => {
                      const dept = DEPARTMENTS.find((d) => d.id === dId);
                      return (
                        <span key={dId} className="px-2 py-0.5 rounded bg-sky-50 text-sky-800 text-[10px] font-medium border border-sky-100">
                          {dept?.name_ar || dId}
                        </span>
                      );
                    })}
                    {part.facility_types.map((ft) => (
                      <span key={ft} className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px]">
                        {ft === 'commercial' ? 'تجاري' : ft === 'government' ? 'حكومي' : 'سكني'}
                      </span>
                    ))}
                  </div>

                  {/* Stock Levels with CHECK Constraint Indicators */}
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 space-y-1.5 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-500">إجمالي المخزون (v_parts_total_stock):</span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums">{totalStock} {part.unit}</span>
                    </div>
                    <div className="flex justify-between text-amber-800">
                      <span>الكمية المحجوزة للزيارات:</span>
                      <span className="font-mono font-semibold tabular-nums">{totalReserved} {part.unit}</span>
                    </div>
                    <div className="flex justify-between font-bold text-emerald-800 pt-1 border-t border-slate-200">
                      <span>المتاح للصرف:</span>
                      <span className="font-mono tabular-nums">{totalAvailable} {part.unit}</span>
                    </div>
                  </div>

                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>متحقق بـ CHECK Constraint: الكمية ≥ 0</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* QR Codes Tab */}
      {activeTab === 'qr' && (
        <div className="space-y-6">
          
          {/* Quick Scanner Simulator Box */}
          <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-right">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Scan className="w-4 h-4 text-amber-400" />
                محاكي مسح رمز الـ QR الميداني (QR Scanner Simulator)
              </h3>
              <p className="text-xs text-slate-300">
                اختبر مسح الـ QR للتحقق من وصول الفني للموقع وتسجيل وقت الحضور اللحظي
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <input
                type="text"
                placeholder="أدخل رمز الـ QR (مثال: HAMA-FAC-1001-SITE)"
                value={scannerInput}
                onChange={(e) => setScannerInput(e.target.value)}
                className="px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/30 font-mono w-full sm:w-64"
              />
              <button
                onClick={() => handleTestScan(scannerInput || 'HAMA-FAC-1001-SITE')}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-colors whitespace-nowrap"
              >
                مسح الرمز
              </button>
            </div>
          </div>

          {scanResult && (
            <div className={`p-4 rounded-xl border text-xs font-bold flex items-center gap-2 animate-in fade-in ${
              scanResult.success ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-rose-50 border-rose-300 text-rose-900'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{scanResult.message}</span>
            </div>
          )}

          {/* QR Codes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {qrCodes.map((qr) => (
              <div
                key={qr.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs hover:border-slate-300 transition-all text-right text-xs"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-slate-400 text-[10px] block">{qr.qr_code}</span>
                    <h3 className="font-bold text-slate-900 text-sm mt-0.5">{qr.assigned_label}</h3>
                    <p className="text-slate-500 text-[11px] mt-0.5">{qr.location_name}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                    qr.purpose === 'site_access' ? 'bg-emerald-100 text-emerald-800' : 'bg-sky-100 text-sky-800'
                  }`}>
                    {qr.purpose}
                  </span>
                </div>

                {/* SVG Visual Graphic of QR */}
                <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div className="w-20 h-20 bg-white p-2 rounded-lg border border-slate-200 shrink-0 flex items-center justify-center">
                    <QrCode className="w-16 h-16 text-slate-900" />
                  </div>
                  <div className="space-y-1 text-[11px]">
                    <div className="text-slate-600">
                      عدد مرات المسح: <strong className="text-slate-900 tabular-nums">{qr.scans_count}</strong>
                    </div>
                    <div className="text-slate-600">
                      آخر مسح: <span className="text-slate-500 font-mono tabular-nums">{qr.last_scanned_at || 'لم يتم بعد'}</span>
                    </div>
                    <button
                      onClick={() => handleTestScan(qr.qr_code)}
                      className="text-amber-700 hover:text-amber-800 font-bold text-[11px] pt-1 block"
                    >
                      ▶ محاكاة مسح هذا الرمز الآن
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

    </div>
  );
};
