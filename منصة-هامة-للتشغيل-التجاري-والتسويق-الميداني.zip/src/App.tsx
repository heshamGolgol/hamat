import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Sparkles, 
  Layers, 
  CheckCircle2, 
  TrendingUp, 
  FileCheck, 
  ShieldAlert, 
  Plus, 
  Users, 
  Clock, 
  HelpCircle,
  Database
} from 'lucide-react';
import { RoleCode } from './types';
import { storageService } from './services/storageService';
import { Navbar } from './components/Navbar';
import { MarketingLeadModal } from './components/MarketingLeadModal';
import { InteractiveLifecycleSimulator } from './components/InteractiveLifecycleSimulator';
import { MarketingModule } from './components/MarketingModule';
import { FieldVisitsModule } from './components/FieldVisitsModule';
import { QuotesAndSubscriptionsModule } from './components/QuotesAndSubscriptionsModule';
import { HRAndFinanceModule } from './components/HRAndFinanceModule';
import { RoleLandingView } from './components/RoleLandingView';
import { InventoryAndQRModule } from './components/InventoryAndQRModule';
import { ReportsModule } from './components/ReportsModule';
import { DatabaseIntegrityViewer } from './components/DatabaseIntegrityViewer';
import { RolePermissionMatrix } from './components/RolePermissionMatrix';
import { ROLES_CATALOG } from './data/initialData';

export default function App() {
  const [currentRole, setCurrentRole] = useState<RoleCode>('MARKETER');
  const [activeTab, setActiveTab] = useState<string>('role_landing');
  const [isLeadModalOpen, setIsLeadModalOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [bannerNotice, setBannerNotice] = useState<string>('');
  const [, setTick] = useState(0);

  // Subscribe to storage service updates
  useEffect(() => {
    const unsub = storageService.subscribe(() => {
      setTick((t) => t + 1);
    });
    return unsub;
  }, []);

  const handleLeadSuccess = (facilityName: string) => {
    setBannerNotice(`تم تسجيل المنشأة (${facilityName}) وجدولة موعد المعاينة وتوليد رمز الـ QR بنجاح!`);
    setTimeout(() => setBannerNotice(''), 5000);
  };

  const activeRoleDef = ROLES_CATALOG.find((r) => r.code === currentRole);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-800">
      
      {/* Strict 3-Zone Top Navigation Bar */}
      <Navbar
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenNewLeadModal={() => setIsLeadModalOpen(true)}
        onOpenSimulator={() => setIsSimulatorOpen(true)}
      />

      {/* Role Context Bar */}
      <div className="bg-slate-900 text-white border-b border-slate-800 px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            <span className="text-slate-300">أنت تتصفح النظام الآن بصلاحيات:</span>
            <strong className="text-amber-300 font-bold">{activeRoleDef?.title_ar}</strong>
            <span className="text-slate-400 font-mono text-[10px]">({currentRole} · Level {activeRoleDef?.level})</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-300">
            <span>النطاق: <strong>{activeRoleDef?.domain === 'all' ? 'كافة القطاعات' : activeRoleDef?.domain}</strong></span>
            <button
              onClick={() => setActiveTab('roles_matrix')}
              className="text-amber-400 hover:text-amber-300 underline font-medium"
            >
              استعراض مصفوفة الصلاحيات (19 دوراً)
            </button>
            <button
              onClick={() => setIsSimulatorOpen(true)}
              className="hidden sm:inline-flex items-center gap-1 text-slate-300 hover:text-white"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>تشغيل المحاكي التفاعلي</span>
            </button>
          </div>
        </div>
      </div>

      {/* Success Notification Banner */}
      {bannerNotice && (
        <div className="bg-emerald-600 text-white px-4 py-2.5 text-center text-xs font-bold animate-in fade-in slide-in-from-top-2 flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
          <span>{bannerNotice}</span>
          <button onClick={() => setBannerNotice('')} className="mr-3 text-emerald-200 hover:text-white">✕</button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {activeTab === 'role_landing' && (
          <RoleLandingView
            currentRole={currentRole}
            onNavigateTab={setActiveTab}
            onOpenNewLeadModal={() => setIsLeadModalOpen(true)}
            onOpenSimulator={() => setIsSimulatorOpen(true)}
          />
        )}

        {activeTab === 'marketing' && (
          <MarketingModule onOpenNewLeadModal={() => setIsLeadModalOpen(true)} />
        )}

        {activeTab === 'visits' && (
          <FieldVisitsModule />
        )}

        {activeTab === 'quotes_subs' && (
          <QuotesAndSubscriptionsModule />
        )}

        {activeTab === 'hr_finance' && (
          <HRAndFinanceModule />
        )}

        {activeTab === 'inventory' && (
          <InventoryAndQRModule />
        )}

        {activeTab === 'reports' && (
          <ReportsModule />
        )}

        {activeTab === 'database_fixes' && (
          <DatabaseIntegrityViewer />
        )}

        {activeTab === 'roles_matrix' && (
          <RolePermissionMatrix
            currentRole={currentRole}
            onSelectRole={(r) => setCurrentRole(r)}
          />
        )}
      </main>

      {/* Modals */}
      <MarketingLeadModal
        isOpen={isLeadModalOpen}
        onClose={() => setIsLeadModalOpen(false)}
        onSuccess={handleLeadSuccess}
        marketerName={activeRoleDef?.title_ar.includes('مسوق') ? 'سلطان بن فهد (مسوق معتمد)' : 'المسوق الميداني المعتمد'}
        marketerId="usr_mkt_1"
      />

      <InteractiveLifecycleSimulator
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        onOpenNewLead={() => setIsLeadModalOpen(true)}
      />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-6 text-xs text-slate-500 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900">نظام هامة للتشغيل والتسويق</span>
            <span>·</span>
            <span>الإصدار الشامل المحدث 2026</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <span>تسلسل آمن ضد التزامن</span>
            <span>·</span>
            <span>تحصين Refresh Tokens</span>
            <span>·</span>
            <span>ربط الـ QR بالمواقع</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
