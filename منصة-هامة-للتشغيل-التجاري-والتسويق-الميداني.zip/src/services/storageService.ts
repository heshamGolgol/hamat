import {
  ClientFacility,
  ClientServiceRequest,
  MarketingVisitAppointment,
  Visit,
  Quote,
  Subscription,
  Part,
  WarehouseStock,
  QRCodeRecord,
  NotificationRecord,
  FacilitySubtype,
  JobLockRecord,
  RefreshTokenRecord,
  LoyaltyWallet,
  EmployeeDue,
  PerformanceReview,
  AssetRecord,
  TechnicianLiveLocation,
  DispatchSuggestion,
  SubscriberDensityPoint,
  EmployeeMarketingActivation
} from '../types';
import {
  INITIAL_FACILITIES,
  INITIAL_SERVICE_REQUESTS,
  INITIAL_APPOINTMENTS,
  INITIAL_VISITS,
  INITIAL_QUOTES,
  INITIAL_SUBSCRIPTIONS,
  INITIAL_PARTS,
  INITIAL_STOCK,
  INITIAL_QR_CODES,
  INITIAL_NOTIFICATIONS,
  INITIAL_FACILITY_SUBTYPES,
  INITIAL_JOB_LOCKS,
  INITIAL_REFRESH_TOKENS,
  INITIAL_LOYALTY_WALLETS,
  INITIAL_EMPLOYEE_DUES,
  INITIAL_PERFORMANCE_REVIEWS,
  INITIAL_ASSETS,
  INITIAL_TECHNICIAN_LOCATIONS,
  INITIAL_EMPLOYEE_MARKETING_ACTIVATIONS
} from '../data/initialData';

class StorageService {
  private facilities: ClientFacility[] = [];
  private serviceRequests: ClientServiceRequest[] = [];
  private appointments: MarketingVisitAppointment[] = [];
  private visits: Visit[] = [];
  private quotes: Quote[] = [];
  private subscriptions: Subscription[] = [];
  private parts: Part[] = [];
  private stock: WarehouseStock[] = [];
  private qrCodes: QRCodeRecord[] = [];
  private notifications: NotificationRecord[] = [];
  private facilitySubtypes: FacilitySubtype[] = [];
  private jobLocks: JobLockRecord[] = [];
  private refreshTokens: RefreshTokenRecord[] = [];
  private loyaltyWallets: LoyaltyWallet[] = [];
  private employeeDues: EmployeeDue[] = [];
  private performanceReviews: PerformanceReview[] = [];
  private assets: AssetRecord[] = [];
  private technicianLocations: TechnicianLiveLocation[] = [];
  private marketingActivations: EmployeeMarketingActivation[] = [];
  private sequences: Record<string, number> = {};

  private listeners: (() => void)[] = [];

  constructor() {
    this.loadState();
  }

  private loadState() {
    try {
      const stored = localStorage.getItem('hama_platform_state_v3');
      if (stored) {
        const parsed = JSON.parse(stored);
        this.facilities = parsed.facilities || INITIAL_FACILITIES;
        this.serviceRequests = parsed.serviceRequests || INITIAL_SERVICE_REQUESTS;
        this.appointments = parsed.appointments || INITIAL_APPOINTMENTS;
        this.visits = parsed.visits || INITIAL_VISITS;
        this.quotes = parsed.quotes || INITIAL_QUOTES;
        this.subscriptions = parsed.subscriptions || INITIAL_SUBSCRIPTIONS;
        this.parts = parsed.parts || INITIAL_PARTS;
        this.stock = parsed.stock || INITIAL_STOCK;
        this.qrCodes = parsed.qrCodes || INITIAL_QR_CODES;
        this.notifications = parsed.notifications || INITIAL_NOTIFICATIONS;
        this.facilitySubtypes = parsed.facilitySubtypes || INITIAL_FACILITY_SUBTYPES;
        this.jobLocks = parsed.jobLocks || INITIAL_JOB_LOCKS;
        this.refreshTokens = parsed.refreshTokens || INITIAL_REFRESH_TOKENS;
        this.loyaltyWallets = parsed.loyaltyWallets || INITIAL_LOYALTY_WALLETS;
        this.employeeDues = parsed.employeeDues || INITIAL_EMPLOYEE_DUES;
        this.performanceReviews = parsed.performanceReviews || INITIAL_PERFORMANCE_REVIEWS;
        this.assets = parsed.assets || INITIAL_ASSETS;
        this.technicianLocations = parsed.technicianLocations || INITIAL_TECHNICIAN_LOCATIONS;
        this.marketingActivations = parsed.marketingActivations || INITIAL_EMPLOYEE_MARKETING_ACTIVATIONS;
        this.sequences = parsed.sequences || {
          request_REQ: 5,
          request_FLT: 1,
          subscription: 2,
          appointment: 2,
          visit: 1,
          quote: 1,
        };
        return;
      }
    } catch (e) {
      console.warn('Could not parse local storage, falling back to defaults', e);
    }

    this.facilities = [...INITIAL_FACILITIES];
    this.serviceRequests = [...INITIAL_SERVICE_REQUESTS];
    this.appointments = [...INITIAL_APPOINTMENTS];
    this.visits = [...INITIAL_VISITS];
    this.quotes = [...INITIAL_QUOTES];
    this.subscriptions = [...INITIAL_SUBSCRIPTIONS];
    this.parts = [...INITIAL_PARTS];
    this.stock = [...INITIAL_STOCK];
    this.qrCodes = [...INITIAL_QR_CODES];
    this.notifications = [...INITIAL_NOTIFICATIONS];
    this.facilitySubtypes = [...INITIAL_FACILITY_SUBTYPES];
    this.jobLocks = [...INITIAL_JOB_LOCKS];
    this.refreshTokens = [...INITIAL_REFRESH_TOKENS];
    this.loyaltyWallets = [...INITIAL_LOYALTY_WALLETS];
    this.employeeDues = [...INITIAL_EMPLOYEE_DUES];
    this.performanceReviews = [...INITIAL_PERFORMANCE_REVIEWS];
    this.assets = [...INITIAL_ASSETS];
    this.technicianLocations = [...INITIAL_TECHNICIAN_LOCATIONS];
    this.marketingActivations = [...INITIAL_EMPLOYEE_MARKETING_ACTIVATIONS];
    this.sequences = {
      request_REQ: 5,
      request_FLT: 1,
      subscription: 2,
      appointment: 2,
      visit: 1,
      quote: 1,
    };
    this.saveState();
  }

  private saveState() {
    try {
      const state = {
        facilities: this.facilities,
        serviceRequests: this.serviceRequests,
        appointments: this.appointments,
        visits: this.visits,
        quotes: this.quotes,
        subscriptions: this.subscriptions,
        parts: this.parts,
        stock: this.stock,
        qrCodes: this.qrCodes,
        notifications: this.notifications,
        facilitySubtypes: this.facilitySubtypes,
        jobLocks: this.jobLocks,
        refreshTokens: this.refreshTokens,
        loyaltyWallets: this.loyaltyWallets,
        employeeDues: this.employeeDues,
        performanceReviews: this.performanceReviews,
        assets: this.assets,
        technicianLocations: this.technicianLocations,
        marketingActivations: this.marketingActivations,
        sequences: this.sequences,
      };
      localStorage.setItem('hama_platform_state_v3', JSON.stringify(state));
    } catch (e) {
      console.error('Failed to save state to localStorage', e);
    }
    this.notify();
  }

  public subscribe(fn: () => void) {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== fn);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  // --- 1.1 Central Sequence Generator (Lock-safe Emulation) ---
  public nextSequence(scope: string, year: number = new Date().getFullYear()): string {
    const key = `${scope}_${year}`;
    const current = (this.sequences[key] || 0) + 1;
    this.sequences[key] = current;
    this.saveState();
    return String(current).padStart(4, '0');
  }

  // --- Getters ---
  public getFacilities(): ClientFacility[] { return [...this.facilities]; }
  public getServiceRequests(): ClientServiceRequest[] { return [...this.serviceRequests]; }
  public getAppointments(): MarketingVisitAppointment[] { return [...this.appointments]; }
  public getVisits(): Visit[] { return [...this.visits]; }
  public getQuotes(): Quote[] { return [...this.quotes]; }
  public getSubscriptions(): Subscription[] { return [...this.subscriptions]; }
  public getParts(): Part[] { return [...this.parts]; }
  public getStock(): WarehouseStock[] { return [...this.stock]; }
  public getQRCodes(): QRCodeRecord[] { return [...this.qrCodes]; }
  public getNotifications(): NotificationRecord[] { return [...this.notifications]; }
  public getFacilitySubtypes(): FacilitySubtype[] { return [...this.facilitySubtypes]; }
  public getJobLocks(): JobLockRecord[] { return [...this.jobLocks]; }
  public getRefreshTokens(): RefreshTokenRecord[] { return [...this.refreshTokens]; }
  public getLoyaltyWallets(): LoyaltyWallet[] { return [...this.loyaltyWallets]; }
  public getEmployeeDues(): EmployeeDue[] { return [...this.employeeDues]; }
  public getPerformanceReviews(): PerformanceReview[] { return [...this.performanceReviews]; }
  public getAssets(): AssetRecord[] { return [...this.assets]; }
  public getTechnicianLocations(): TechnicianLiveLocation[] { return [...this.technicianLocations]; }
  public getMarketingActivations(): EmployeeMarketingActivation[] { return [...this.marketingActivations]; }

  // --- Point 6 & 7: Marketer Lead Creation with Draft mode & Marketer Estimated Value ---
  public createMarketingLead(data: {
    facility_name: string;
    facility_type: 'government' | 'commercial' | 'residential';
    commercial_subtype?: string;
    commercial_subtype_other?: string;
    owner_name: string;
    owner_phone: string;
    delegate_name?: string;
    delegate_phone?: string;
    location_lat: number;
    location_lng: number;
    map_url: string;
    address_text: string;
    notes?: string;
    site_photo_url: string;
    visit_date: string;
    visit_time: string;
    marketer_estimated_value?: number; // Point 6
    marketer_pricing_notes?: string;
    is_draft?: boolean;                // Point 7
    selected_services: {
      department_id: any;
      service_category: any;
      service_title_ar: string;
      service_details: Record<string, any>;
    }[];
    marketer_id: string;
    marketer_name: string;
  }) {
    const clientId = 'cln_' + Date.now();
    const facilityId = 'fac_' + Date.now();
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const currentYear = new Date().getFullYear();
    const initialStatus = data.is_draft ? 'draft' : 'submitted';

    // 1. Create Facility Record
    const newFacility: ClientFacility = {
      id: facilityId,
      client_id: clientId,
      facility_name: data.facility_name,
      facility_type: data.facility_type,
      commercial_subtype: data.commercial_subtype,
      commercial_subtype_other: data.commercial_subtype_other,
      owner_name: data.owner_name,
      owner_phone: data.owner_phone,
      delegate_name: data.delegate_name,
      delegate_phone: data.delegate_phone,
      location_lat: data.location_lat,
      location_lng: data.location_lng,
      map_url: data.map_url,
      address_text: data.address_text,
      notes: data.notes,
      site_photo_url: data.site_photo_url,
      created_at: now,
    };
    this.facilities.unshift(newFacility);

    // 2. Create Service Requests
    const createdRequests: ClientServiceRequest[] = [];
    data.selected_services.forEach((srv) => {
      const seq = this.nextSequence('request_REQ', currentYear);
      const reqNumber = `REQ-${currentYear}-${seq}`;
      const req: ClientServiceRequest = {
        id: 'csr_' + Math.random().toString(36).substring(2, 9),
        request_number: reqNumber,
        client_id: clientId,
        client_name: data.facility_name,
        facility_id: facilityId,
        department_id: srv.department_id,
        service_category: srv.service_category,
        service_title_ar: srv.service_title_ar,
        service_details: srv.service_details,
        status: initialStatus,
        marketer_id: data.marketer_id,
        marketer_name: data.marketer_name,
        marketer_estimated_value: data.marketer_estimated_value,
        marketer_pricing_notes: data.marketer_pricing_notes,
        submitted_at: now,
        created_at: now,
      };
      this.serviceRequests.unshift(req);
      createdRequests.push(req);
    });

    // 3. Create Marketing Visit Appointment
    const appSeq = this.nextSequence('appointment', currentYear);
    const newAppointment: MarketingVisitAppointment = {
      id: 'app_' + Date.now(),
      appointment_number: `APP-${currentYear}-${appSeq}`,
      client_id: clientId,
      client_name: data.facility_name,
      facility_id: facilityId,
      facility_name: data.facility_name,
      service_request_id: createdRequests[0]?.id,
      requested_date: data.visit_date,
      requested_time: data.visit_time,
      status: 'requested',
      marketer_id: data.marketer_id,
      marketer_name: data.marketer_name,
      created_at: now,
    };
    this.appointments.unshift(newAppointment);

    // 4. Generate Site Access QR Code
    const qrSeq = Math.floor(1000 + Math.random() * 9000);
    const newQR: QRCodeRecord = {
      id: 'qr_' + Date.now(),
      qr_code: `HAMA-FAC-${qrSeq}-SITE`,
      client_id: clientId,
      facility_id: facilityId,
      purpose: 'site_access',
      assigned_label: `رمز التحقق الميداني لمنشأة ${data.facility_name}`,
      location_name: `${data.facility_name} - المدخل الرئيسي`,
      scans_count: 0,
      created_at: now,
    };
    this.qrCodes.unshift(newQR);

    // 5. Create initial Loyalty Wallet for Client
    this.loyaltyWallets.unshift({
      id: 'lw_' + Date.now(),
      client_id: clientId,
      client_name: data.facility_name,
      balance_points: 500, // 500 welcome bonus points
      monetary_value_sar: 50,
      total_earned_points: 500,
      total_redeemed_sar: 0,
      transactions: [{
        id: 'lt_' + Date.now(),
        wallet_id: 'lw_' + Date.now(),
        transaction_type: 'earn',
        points: 500,
        monetary_value: 50,
        reference_desc: 'مكافأة ترحيبية بتسجيل المنشأة في نظام هامة',
        created_at: now
      }]
    });

    // 6. In-App notification
    this.notifications.unshift({
      id: 'notif_' + Date.now(),
      recipient_type: 'user',
      recipient_id: 'mkt_mgr',
      recipient_name: 'مدير التسويق والعمليات',
      channel: 'in_app',
      subject: data.is_draft ? `مسودة منشأة جديدة: ${data.facility_name}` : `طلب عميل جديد: ${data.facility_name}`,
      message: `تم رفع بيانات منشأة (${data.facility_name}) بتقدير مبدئي ${data.marketer_estimated_value?.toLocaleString() || 'غير محدد'} ريال. الحالة: ${initialStatus}.`,
      status: 'queued',
      event_type: 'service_request_submitted',
      created_at: now,
    });

    this.saveState();
    return { facility: newFacility, requests: createdRequests, appointment: newAppointment };
  }

  // --- Point 7: Marketing Manager Completes and Submits Draft ---
  public submitDraftLead(facilityId: string, updatedNotesOrData?: string | {
    owner_name?: string;
    owner_phone?: string;
    marketer_estimated_value?: number;
    marketer_pricing_notes?: string;
  }) {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    
    // Update Facility
    const facIdx = this.facilities.findIndex((f) => f.id === facilityId);
    if (facIdx !== -1) {
      const fac = this.facilities[facIdx];
      const dataObj = typeof updatedNotesOrData === 'object' ? updatedNotesOrData : {};
      this.facilities[facIdx] = {
        ...fac,
        is_draft: false,
        lead_status: 'submitted',
        owner_name: dataObj.owner_name || fac.owner_name,
        owner_phone: dataObj.owner_phone || fac.owner_phone,
        marketer_estimated_value: dataObj.marketer_estimated_value || fac.marketer_estimated_value,
        marketer_pricing_notes: dataObj.marketer_pricing_notes || (typeof updatedNotesOrData === 'string' ? updatedNotesOrData : fac.marketer_pricing_notes),
      };
    }

    // Update Service Requests
    this.serviceRequests = this.serviceRequests.map((csr) => {
      if (csr.facility_id === facilityId && csr.status === 'draft') {
        const notesStr = typeof updatedNotesOrData === 'string' ? updatedNotesOrData : updatedNotesOrData?.marketer_pricing_notes;
        return {
          ...csr,
          status: 'submitted',
          submitted_at: now,
          marketer_pricing_notes: notesStr || csr.marketer_pricing_notes,
          marketer_estimated_value: typeof updatedNotesOrData === 'object' && updatedNotesOrData?.marketer_estimated_value ? updatedNotesOrData.marketer_estimated_value : csr.marketer_estimated_value,
        };
      }
      return csr;
    });

    // If an appointment exists for this facility, ensure it is in requested status
    this.appointments = this.appointments.map((a) => {
      if (a.facility_id === facilityId && a.status === 'requested') {
        return { ...a, status: 'requested' };
      }
      return a;
    });

    this.saveState();
  }

  // --- Point 3 & 4: Confirm Appointment with Supervisor and Team Leader Assignment ---
  public confirmAppointment(appointmentId: string, confirmedBy: string): Visit | null {
    const appIndex = this.appointments.findIndex((a) => a.id === appointmentId);
    if (appIndex === -1) return null;

    const app = this.appointments[appIndex];
    if (app.status === 'confirmed') {
      return this.visits.find((v) => v.id === app.converted_visit_id) || null;
    }

    const currentYear = new Date().getFullYear();
    const visitSeq = this.nextSequence('visit', currentYear);
    const visitId = 'vis_' + Date.now();
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const facility = this.facilities.find((f) => f.id === app.facility_id);
    const newVisit: Visit = {
      id: visitId,
      visit_number: `VIS-${currentYear}-${visitSeq}`,
      client_id: app.client_id,
      client_name: app.client_name,
      facility_id: app.facility_id,
      facility_name: app.facility_name,
      site_address: facility?.address_text || 'العنوان المسجل بالمنشأة',
      location_lat: facility?.location_lat || 24.7136,
      location_lng: facility?.location_lng || 46.6753,
      visit_type: 'inspection',
      source_type: 'marketing',
      marketing_appointment_id: app.id,
      source_service_request_id: app.service_request_id,
      scheduled_date: app.requested_date,
      scheduled_time: app.requested_time,
      status: 'scheduled',
      session_status: 'not_started', // Point 14
      duration_seconds: 0,
      
      // Point 3 & 4: Distinct supervisor & team leader & technician
      assigned_team_id: 'team_01',
      assigned_team_name: 'فريق المعاينة الفنية الموحد',
      assigned_supervisor_name: 'م. حسام العمودي (مشرف الفرق)',
      assigned_team_leader_name: 'م. ياسر الحربي (قائد الفريق)',
      assigned_technician_id: 'tech_01',
      assigned_technician_name: 'فني أول: عبد الله المالكي',

      // Point 15: Costs
      labor_cost: 0,
      vehicle_cost: 0,
      parts_cost: 0,
      total_cost: 0,

      completion_percentage: 0,
      qr_verified: false,
      findings: [],
      created_by: confirmedBy,
      created_at: now,
    };

    this.visits.unshift(newVisit);

    // Update appointment
    this.appointments[appIndex] = {
      ...app,
      status: 'confirmed',
      confirmed_by: confirmedBy,
      confirmed_at: now,
      converted_visit_id: visitId,
    };

    // Update requests
    this.serviceRequests = this.serviceRequests.map((req) => {
      if (req.facility_id === app.facility_id && req.status === 'submitted') {
        return { ...req, status: 'under_review', reviewed_by: confirmedBy, reviewed_at: now };
      }
      return req;
    });

    this.saveState();
    return newVisit;
  }

  // --- Point 14: Dual QR Scan (Start Visit vs End Visit) + Point 15: Second-by-Second Cost Calculation ---
  public scanQRCode(qrString: string, scannerRole: string, visitId?: string) {
    const qrIdx = this.qrCodes.findIndex((q) => q.qr_code.trim() === qrString.trim());
    if (qrIdx === -1) {
      return { success: false, message: 'رمز الـ QR غير صالح أو غير موجود في قاعدة بيانات هامة' };
    }

    const qr = this.qrCodes[qrIdx];
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    this.qrCodes[qrIdx] = {
      ...qr,
      scans_count: qr.scans_count + 1,
      last_scanned_at: now,
    };

    // Find target visit
    let vIdx = -1;
    if (visitId) {
      vIdx = this.visits.findIndex((v) => v.id === visitId);
    } else if (qr.facility_id) {
      vIdx = this.visits.findIndex(
        (v) => v.facility_id === qr.facility_id && (v.status === 'scheduled' || v.status === 'in_progress')
      );
    }

    if (vIdx === -1) {
      this.saveState();
      return {
        success: true,
        qr,
        message: `تم مسح رمز QR بنجاح بواسطة ${scannerRole}. لا توجد زيارة تشغيلية مجدولة حالياً لهذه المنشأة.`,
      };
    }

    const currentVisit = this.visits[vIdx];

    // Scan 1: Start Visit Session
    if (currentVisit.session_status === 'not_started') {
      this.visits[vIdx] = {
        ...currentVisit,
        session_status: 'active',
        status: 'in_progress',
        start_scan_at: now,
        actual_start_at: now,
        qr_verified: true,
      };

      this.saveState();
      return {
        success: true,
        qr,
        matchedVisit: this.visits[vIdx],
        scanPhase: 'start',
        message: `✅ المسح الأول (بدء الزيارة): تم التحقق من الحضور الجغرافي وبدء احتساب وقت الزيارة الفعلي في الموقع #${currentVisit.visit_number}.`,
      };
    }

    // Scan 2: End Visit Session
    if (currentVisit.session_status === 'active') {
      const startTimeMs = new Date(currentVisit.start_scan_at || currentVisit.created_at).getTime();
      const endTimeMs = new Date().getTime();
      const durationSeconds = Math.max(60, Math.round((endTimeMs - startTimeMs) / 1000));

      // Calculate cost per second:
      // Technician hourly rate: 60 SAR/h -> (60 / 3600) SAR per second
      // Vehicle operating cost: 18 SAR/h -> (18 / 3600) SAR per second
      const technicianLaborCost = parseFloat(((60 / 3600) * durationSeconds).toFixed(2));
      const vehicleOperatingCost = parseFloat(((18 / 3600) * durationSeconds).toFixed(2));
      const partsTotalCost = (currentVisit.parts_consumed || []).reduce((acc, p) => acc + (p.quantity * (p.unit_cost || 0)), 0);
      const totalCost = parseFloat((technicianLaborCost + vehicleOperatingCost + partsTotalCost).toFixed(2));

      this.visits[vIdx] = {
        ...currentVisit,
        session_status: 'ended',
        status: 'completed',
        end_scan_at: now,
        actual_end_at: now,
        duration_seconds: durationSeconds,
        labor_cost: technicianLaborCost,
        vehicle_cost: vehicleOperatingCost,
        parts_cost: partsTotalCost,
        total_cost: totalCost,
        completion_percentage: 100,
      };

      // Prompt notification for final inspection report
      this.notifications.unshift({
        id: 'notif_' + Date.now(),
        recipient_type: 'user',
        recipient_id: 'tech_leader',
        recipient_name: currentVisit.assigned_team_leader_name || 'قائد الفريق',
        channel: 'in_app',
        subject: `اكتمال الزيارة #${currentVisit.visit_number} بالمسح المزدوج`,
        message: `انتهت الزيارة بعد مدة ${Math.floor(durationSeconds / 60)} دقيقة و${durationSeconds % 60} ثانية. التكلفة المحتسبة بالثانية: ${totalCost} ريال. يرجى مراجعة التقرير الفني.`,
        status: 'queued',
        event_type: 'visit_session_ended',
        created_at: now,
      });

      this.saveState();
      return {
        success: true,
        qr,
        matchedVisit: this.visits[vIdx],
        scanPhase: 'end',
        duration_seconds: durationSeconds,
        total_cost: totalCost,
        message: `🏁 المسح الثاني (إنهاء الزيارة): تم تسجيل المغادرة وحساب مدة العمل بالثانية (${durationSeconds}s) وتكلفة التشغيل (${totalCost} ريال).`,
      };
    }

    this.saveState();
    return {
      success: true,
      qr,
      matchedVisit: currentVisit,
      message: `رمز QR تم مسحه مسبقاً والزيارة مسجلة كمكتملة.`,
    };
  }

  // --- Complete Visit Inspection & Supervisor Approval ---
  public completeVisitInspection(visitId: string, data: {
    findings: string[];
    inspection_notes: string;
    parts_consumed?: { part_id: string; part_name: string; quantity: number }[];
    supervisor_approved_by?: string;
  }) {
    const idx = this.visits.findIndex((v) => v.id === visitId);
    if (idx === -1) return;

    const visit = this.visits[idx];
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    // Spare parts stock deduction with non-negative constraint
    const resolvedPartsConsumed: { part_id: string; part_name: string; quantity: number; unit_cost: number }[] = [];
    if (data.parts_consumed && data.parts_consumed.length > 0) {
      data.parts_consumed.forEach((item) => {
        const stkIdx = this.stock.findIndex((s) => s.part_id === item.part_id);
        const partObj = this.parts.find((p) => p.id === item.part_id);
        if (stkIdx !== -1) {
          const current = this.stock[stkIdx];
          if (current.quantity < item.quantity) {
            throw new Error(`كمية المخزون غير كافية للقطعة: ${item.part_name}`);
          }
          const updatedQty = current.quantity - item.quantity;
          this.stock[stkIdx] = {
            ...current,
            quantity: updatedQty,
            available_quantity: updatedQty - current.reserved_quantity,
          };
        }
        resolvedPartsConsumed.push({
          part_id: item.part_id,
          part_name: item.part_name,
          quantity: item.quantity,
          unit_cost: partObj?.unit_cost || 100,
        });
      });
    }

    this.visits[idx] = {
      ...visit,
      status: 'completed',
      session_status: 'ended',
      completion_percentage: 100,
      qr_verified: true,
      actual_end_at: visit.actual_end_at || now,
      findings: data.findings,
      inspection_notes: data.inspection_notes,
      parts_consumed: resolvedPartsConsumed,
      report_approved_by: data.supervisor_approved_by || 'مشرف الفرق: م. حسام العمودي',
    };

    if (visit.marketing_appointment_id) {
      this.appointments = this.appointments.map((a) =>
        a.id === visit.marketing_appointment_id ? { ...a, status: 'completed' } : a
      );
    }

    this.saveState();
  }

  // --- Point 13: Suggest Nearest Available Technicians / Teams via GPS Distance ---
  public suggestTechniciansForVisit(visitId: string): DispatchSuggestion[] {
    const visit = this.visits.find((v) => v.id === visitId);
    const siteLat = visit?.location_lat || 21.5685;
    const siteLng = visit?.location_lng || 39.1677;

    return this.technicianLocations.map((tech) => {
      // Haversine distance in km
      const R = 6371; // Earth's radius in km
      const dLat = ((tech.latitude - siteLat) * Math.PI) / 180;
      const dLng = ((tech.longitude - siteLng) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((siteLat * Math.PI) / 180) *
          Math.cos((tech.latitude * Math.PI) / 180) *
          Math.sin(dLng / 2) *
          Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const distanceKm = parseFloat((R * c).toFixed(1));
      const etaMinutes = Math.max(5, Math.round((distanceKm / 35) * 60)); // Avg 35 km/h city driving

      // Score: Closest + Lowest workload + Highest rating
      const score = Math.round(
        (100 / (1 + distanceKm)) * 0.5 +
        (10 / (1 + tech.active_tasks_count)) * 0.3 +
        tech.rating * 5
      );

      return {
        technician_id: tech.technician_id,
        technician_name: tech.name,
        team_name: tech.team_name,
        distance_km: distanceKm,
        estimated_arrival_minutes: etaMinutes,
        current_workload: tech.active_tasks_count,
        score,
        rating: tech.rating,
      };
    }).sort((a, b) => b.score - a.score);
  }

  // --- Point 4: Assign Visit to Team and Technician ---
  public assignVisit(visitId: string, technicianId: string) {
    const vIdx = this.visits.findIndex((v) => v.id === visitId);
    const tech = this.technicianLocations.find((t) => t.technician_id === technicianId);
    if (vIdx === -1 || !tech) return;

    this.visits[vIdx] = {
      ...this.visits[vIdx],
      assigned_technician_id: tech.technician_id,
      assigned_technician_name: tech.name,
      assigned_team_name: tech.team_name,
      status: 'scheduled',
    };
    this.saveState();
  }

  // --- Create Quote From Service Requests ---
  public createQuoteForFacility(facilityId: string, items: {
    department_id: any;
    description: string;
    quantity: number;
    unit_price: number;
  }[], contractType: 'standard' | 'premium_plus' = 'standard') {
    const facility = this.facilities.find((f) => f.id === facilityId);
    if (!facility) return null;

    const currentYear = new Date().getFullYear();
    const quoteSeq = this.nextSequence('quote', currentYear);
    const quoteId = 'quo_' + Date.now();
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    let subtotal = 0;
    const quoteItems = items.map((it, idx) => {
      const total = it.quantity * it.unit_price;
      subtotal += total;
      return {
        id: `qi_${Date.now()}_${idx}`,
        quote_id: quoteId,
        department_id: it.department_id,
        description: it.description,
        quantity: it.quantity,
        unit_price: it.unit_price,
        total_price: total,
      };
    });

    const vatRate = 0.15;
    const vatAmount = subtotal * vatRate;
    const totalPrice = subtotal + vatAmount;

    const validDate = new Date();
    validDate.setDate(validDate.getDate() + 30);
    const validUntil = validDate.toISOString().substring(0, 10);

    const newQuote: Quote = {
      id: quoteId,
      quote_number: `QUO-${currentYear}-${quoteSeq}`,
      client_id: facility.client_id,
      client_name: facility.facility_name,
      facility_id: facility.id,
      facility_name: facility.facility_name,
      quote_type: contractType === 'premium_plus' ? 'باقة المميز + فائقة السرعة' : 'عرض موحد متعدد الخدمات والأقسام',
      contract_type: contractType,
      items: quoteItems,
      subtotal,
      vat_rate: vatRate,
      vat_amount: vatAmount,
      total_price: totalPrice,
      status: 'sent',
      valid_until: validUntil,
      created_by: 'مدير التسويق والمبيعات الموحد',
      created_at: now,
    };

    this.quotes.unshift(newQuote);

    // Update requests
    this.serviceRequests = this.serviceRequests.map((csr) => {
      if (csr.facility_id === facilityId && (csr.status === 'under_review' || csr.status === 'submitted')) {
        return { 
          ...csr, 
          status: 'quoted', 
          quote_id: quoteId,
          domain_approved_value: totalPrice
        };
      }
      return csr;
    });

    this.saveState();
    return newQuote;
  }

  // --- Point 2 & 5: Trigger: Quote Accepted -> Subscribed in 'pending_finance' ---
  public acceptQuote(quoteId: string): Subscription | null {
    const qIdx = this.quotes.findIndex((q) => q.id === quoteId);
    if (qIdx === -1) return null;

    const quote = this.quotes[qIdx];
    if (quote.status === 'accepted') {
      return this.subscriptions.find((s) => s.id === quote.generated_subscription_id) || null;
    }

    const currentYear = new Date().getFullYear();
    const subSeq = this.nextSequence('subscription', currentYear);
    const subId = 'sub_' + Date.now();
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const startDate = new Date().toISOString().substring(0, 10);
    const endDateObj = new Date();
    endDateObj.setFullYear(endDateObj.getFullYear() + 1);
    const endDate = endDateObj.toISOString().substring(0, 10);

    // Point 2: Handling Premium+ contracts
    const isPremiumPlus = quote.contract_type === 'premium_plus';

    const subItems = quote.items.map((qi, idx) => ({
      id: `si_${Date.now()}_${idx}`,
      subscription_id: subId,
      department_id: qi.department_id,
      service_name: qi.description,
      quantity: qi.quantity,
      unit_value: qi.unit_price,
      total_value: qi.total_price,
      visit_frequency: isPremiumPlus ? ('annual' as const) : ('monthly' as const),
      visits_per_year: isPremiumPlus ? 0 : 12, // Zero scheduled visits for Premium+!
    }));

    const newSub: Subscription = {
      id: subId,
      subscription_number: isPremiumPlus ? `SUB-${currentYear}-${subSeq}-PLUS` : `SUB-${currentYear}-${subSeq}`,
      client_id: quote.client_id,
      client_name: quote.client_name,
      facility_id: quote.facility_id,
      facility_name: quote.facility_name,
      contract_type: quote.contract_type,
      emergency_tokens_total: isPremiumPlus ? 12 : undefined,
      emergency_tokens_remaining: isPremiumPlus ? 12 : undefined,
      free_parts_allowance_annual: isPremiumPlus ? 6000 : undefined,
      free_parts_consumed: isPremiumPlus ? 0 : undefined,
      sla_response_hours: isPremiumPlus ? 4 : 24,
      items: subItems,
      total_annual_value: quote.total_price,
      start_date: startDate,
      end_date: endDate,
      status: 'pending_finance', // Point 5: Awaiting Finance Approval
      created_at: now,
    };

    this.subscriptions.unshift(newSub);

    // Update Quote
    this.quotes[qIdx] = {
      ...quote,
      status: 'accepted',
      accepted_at: now,
      generated_subscription_id: subId,
    };

    // Notify Finance Manager
    this.notifications.unshift({
      id: 'notif_' + Date.now(),
      recipient_type: 'user',
      recipient_id: 'finance_mgr',
      recipient_name: 'المدير المالي (FINANCE_MGR)',
      channel: 'in_app',
      subject: `عقد جديد بانتظار الاعتماد المالي #${newSub.subscription_number}`,
      message: `اعتمد العميل ${quote.client_name} العرض بقيمة ${quote.total_price.toLocaleString()} ريال. يرجى التحقق المالي وتفعيل الحساب.`,
      status: 'queued',
      event_type: 'subscription_pending_finance',
      created_at: now,
    });

    this.saveState();
    return newSub;
  }

  // --- Point 5: Finance Manager Approves -> Auto-Create Client Account & Commission Dues ---
  public approveSubscriptionByFinance(subscriptionId: string): Subscription | null {
    const sIdx = this.subscriptions.findIndex((s) => s.id === subscriptionId);
    if (sIdx === -1) return null;

    const sub = this.subscriptions[sIdx];
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    this.subscriptions[sIdx] = {
      ...sub,
      status: 'active',
      finance_approved_by: 'المدير المالي (FINANCE_MGR)',
      finance_approved_at: now,
    };

    // Update all CSRs to activated
    this.serviceRequests = this.serviceRequests.map((csr) => {
      if (csr.facility_id === sub.facility_id && (csr.status === 'quoted' || csr.status === 'under_review')) {
        return { ...csr, status: 'activated', subscription_id: sub.id, finance_approved_value: sub.total_annual_value };
      }
      return csr;
    });

    // 1. Point 5: Auto-Create User Account for Client
    const clientEmail = `client.${sub.client_id.substring(4)}@hama-enterprise.sa`;
    const tempPassword = 'Hama@' + Math.floor(100000 + Math.random() * 900000);

    // 2. Point 8 & 9: Create Employee Commission Due (5%)
    const relatedCSR = this.serviceRequests.find((r) => r.facility_id === sub.facility_id);
    const marketerName = relatedCSR?.marketer_name || 'سلطان بن فهد';
    const marketerId = relatedCSR?.marketer_id || 'usr_mkt_1';
    const commissionAmount = Math.round(sub.total_annual_value * 0.05);

    this.employeeDues.unshift({
      id: 'ed_' + Date.now(),
      user_id: marketerId,
      user_name: marketerName,
      due_type: 'commission',
      source_subscription_id: sub.id,
      amount: commissionAmount,
      status: 'approved',
      approved_by: 'المدير المالي ومدير الموارد البشرية',
      created_at: now,
    });

    // 3. Emit Welcome & Account details invitation to Client via Email & WhatsApp
    this.notifications.unshift({
      id: 'notif_client_' + Date.now(),
      recipient_type: 'client',
      recipient_id: sub.client_id,
      recipient_name: sub.client_name,
      channel: 'whatsapp',
      subject: `🎉 تفعيل حسابكم في بوابة هامة والاشتراك السنوي #${sub.subscription_number}`,
      message: `مرحباً بك! تم اعتماد العقد رسمياً وإنشاء حسابكم ببوابة هامة. اسم المستخدم: ${clientEmail} · كلمة المرور المؤقتة: ${tempPassword}.`,
      status: 'delivered',
      event_type: 'client_account_created',
      created_at: now,
    });

    this.saveState();
    return this.subscriptions[sIdx];
  }

  // --- Point 10: Loyalty Wallet Points Redemption ---
  public redeemLoyaltyPoints(walletId: string, points: number, type: 'cash' | 'discount', details: string) {
    const wIdx = this.loyaltyWallets.findIndex((w) => w.id === walletId);
    if (wIdx === -1) return { success: false, message: 'المحفظة غير موجودة' };

    const wallet = this.loyaltyWallets[wIdx];
    if (wallet.balance_points < points) {
      return { success: false, message: 'رصيد نقاط الولاء غير كافٍ' };
    }

    const monetaryVal = Math.round(points / 10); // 10 points = 1 SAR
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const updatedWallet: LoyaltyWallet = {
      ...wallet,
      balance_points: wallet.balance_points - points,
      monetary_value_sar: (wallet.balance_points - points) / 10,
      total_redeemed_sar: wallet.total_redeemed_sar + monetaryVal,
      transactions: [
        {
          id: 'lt_' + Date.now(),
          wallet_id: wallet.id,
          transaction_type: type === 'cash' ? 'redeem_cash' : 'redeem_discount',
          points: -points,
          monetary_value: monetaryVal,
          reference_desc: type === 'cash' 
            ? `استرداد نقدي بمبلغ ${monetaryVal} ريال لحساب الآيبان (${details})`
            : `خصم ولاء بمبلغ ${monetaryVal} ريال مطبق على الفاتورة (${details})`,
          created_at: now,
        },
        ...wallet.transactions
      ]
    };

    this.loyaltyWallets[wIdx] = updatedWallet;
    this.saveState();
    return { success: true, message: `تم استبدال ${points} نقطة بنجاح بقيمة ${monetaryVal} ريال.` };
  }

  // --- Point 17: Marketer Subscriber Density in Radius ---
  public getSubscriberDensity(radiusOrLat: number = 5, centerLngParam?: number, radiusKmParam?: number): {
    points: SubscriberDensityPoint[];
    totalSubscribers: number;
    totalProspects: number;
    totalRevenueInRadius: number;
  } {
    // If only 1 argument provided, treat it as radiusKm from default center (Riyadh: 24.7136, 46.6753)
    const centerLat = centerLngParam !== undefined ? radiusOrLat : 24.7136;
    const centerLng = centerLngParam !== undefined ? centerLngParam : 46.6753;
    const radiusKm = radiusKmParam !== undefined ? radiusKmParam : (centerLngParam !== undefined ? 5 : radiusOrLat);

    const points: SubscriberDensityPoint[] = this.facilities.map((fac) => {
      // Calculate distance
      const R = 6371;
      const dLat = ((fac.location_lat - centerLat) * Math.PI) / 180;
      const dLng = ((fac.location_lng - centerLng) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((centerLat * Math.PI) / 180) *
          Math.cos((fac.location_lat * Math.PI) / 180) *
          Math.sin(dLng / 2) *
          Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const distanceKm = parseFloat((R * c).toFixed(1));

      const sub = this.subscriptions.find((s) => s.facility_id === fac.id && s.status === 'active');
      const reqs = this.serviceRequests.filter((r) => r.facility_id === fac.id);
      const subtypeObj = this.facilitySubtypes.find((st) => st.id === fac.commercial_subtype);

      return {
        client_id: fac.client_id,
        client_name: fac.facility_name,
        facility_type: fac.facility_type,
        commercial_subtype_name: subtypeObj?.name_ar || fac.commercial_subtype_other || 'منشأة تجارية',
        latitude: fac.location_lat,
        longitude: fac.location_lng,
        distance_km: distanceKm,
        is_active_subscriber: !!sub,
        annual_contract_value: sub?.total_annual_value || 0,
        services_count: reqs.length,
      };
    }).filter((p) => p.distance_km <= radiusKm);

    const totalSubscribers = points.filter((p) => p.is_active_subscriber).length;
    const totalProspects = points.filter((p) => !p.is_active_subscriber).length;
    const totalRevenueInRadius = points.reduce((acc, p) => acc + p.annual_contract_value, 0);

    return {
      points,
      totalSubscribers,
      totalProspects,
      totalRevenueInRadius,
    };
  }

  // --- Point 12: Marketer Lead Tracking View ---
  public getMarketerLeadTrackingView() {
    return this.serviceRequests.map((csr) => {
      const facility = this.facilities.find((f) => f.id === csr.facility_id);
      const quote = this.quotes.find((q) => q.id === csr.quote_id);
      const sub = this.subscriptions.find((s) => s.id === csr.subscription_id);

      let stageLabel = 'مسودة أولية';
      let progressPct = 10;
      if (csr.status === 'submitted') {
        stageLabel = 'بانتظار مراجعة مدير التسويق';
        progressPct = 25;
      } else if (csr.status === 'under_review') {
        stageLabel = 'المعاينة الميدانية قيد التنفيذ';
        progressPct = 50;
      } else if (csr.status === 'quoted') {
        stageLabel = 'عرض السعر جاهز ومعروض على العميل';
        progressPct = 75;
      } else if (csr.status === 'activated') {
        stageLabel = 'عقد سنوي نشط ومفعل مالياً';
        progressPct = 100;
      }

      const expectedValue = csr.finance_approved_value || csr.domain_approved_value || csr.marketer_estimated_value || quote?.total_price || 15000;
      const expectedCommission = Math.round(expectedValue * 0.05);

      return {
        id: csr.id,
        request_number: csr.request_number,
        facility_name: csr.client_name,
        facility_address: facility?.address_text || 'المملكة العربية السعودية',
        service_title: csr.service_title_ar,
        department_id: csr.department_id,
        status: csr.status,
        stage_label: stageLabel,
        progress_pct: progressPct,
        estimated_value: expectedValue,
        expected_commission: expectedCommission,
        marketer_name: csr.marketer_name,
        submitted_at: csr.submitted_at,
      };
    });
  }

  // --- Point 11: Contract Expiry Check (Within 30 Days) ---
  public getExpiringContractsIn30Days(): Subscription[] {
    const today = new Date();
    return this.subscriptions.filter((sub) => {
      if (sub.status !== 'active') return false;
      const end = new Date(sub.end_date);
      const diffDays = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 30;
    });
  }

  // --- Point 8: Toggle Employee Side-Hustle Marketing Activation ---
  public toggleMarketingMode(userId: string, userName: string, dept: string) {
    const idx = this.marketingActivations.findIndex((a) => a.user_id === userId);
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    if (idx !== -1) {
      const curr = this.marketingActivations[idx];
      this.marketingActivations[idx] = {
        ...curr,
        is_active: !curr.is_active,
      };
    } else {
      this.marketingActivations.push({
        id: 'ema_' + Date.now(),
        user_id: userId,
        user_name: userName,
        user_department: dept,
        is_active: true,
        commission_rate: 5.0,
        total_leads_submitted: 0,
        total_commissions_earned: 0,
        activated_at: now,
      });
    }
    this.saveState();
  }

  // --- SQL Views Calculations ---
  public getMarketerPerformanceView() {
    const marketersMap: Record<string, {
      marketer_id: string;
      marketer_name: string;
      clients_registered: Set<string>;
      service_requests_count: number;
      activated_services_count: number;
      total_revenue: number;
    }> = {};

    this.serviceRequests.forEach((csr) => {
      if (!marketersMap[csr.marketer_id]) {
        marketersMap[csr.marketer_id] = {
          marketer_id: csr.marketer_id,
          marketer_name: csr.marketer_name,
          clients_registered: new Set(),
          service_requests_count: 0,
          activated_services_count: 0,
          total_revenue: 0,
        };
      }
      const entry = marketersMap[csr.marketer_id];
      entry.clients_registered.add(csr.client_id);
      entry.service_requests_count++;
      if (csr.status === 'activated') {
        entry.activated_services_count++;
        const quote = this.quotes.find((q) => q.id === csr.quote_id);
        entry.total_revenue += quote?.total_price || csr.finance_approved_value || 20000;
      }
    });

    return Object.values(marketersMap).map((m) => {
      const convPct = m.service_requests_count > 0
        ? Math.round((m.activated_services_count / m.service_requests_count) * 100)
        : 0;
      return {
        marketer_id: m.marketer_id,
        marketer_name: m.marketer_name,
        clients_count: m.clients_registered.size,
        service_requests: m.service_requests_count,
        activated_services: m.activated_services_count,
        total_revenue: m.total_revenue,
        conversion_rate_pct: convPct,
      };
    });
  }

  public getClientsByFacilityTypeView() {
    const counts: Record<string, { facility_type: string; subtype_name: string; count: number; requests_count: number }> = {};
    this.facilities.forEach((fac) => {
      const subtype = this.facilitySubtypes.find((st) => st.id === fac.commercial_subtype);
      const subtypeName = fac.facility_type === 'commercial'
        ? (subtype?.name_ar || fac.commercial_subtype_other || 'تجاري عام')
        : fac.facility_type === 'government' ? 'منشأة حكومية' : 'مجمع سكني';
      
      const key = `${fac.facility_type}_${subtypeName}`;
      if (!counts[key]) {
        counts[key] = {
          facility_type: fac.facility_type,
          subtype_name: subtypeName,
          count: 0,
          requests_count: 0,
        };
      }
      counts[key].count++;
      const reqs = this.serviceRequests.filter((r) => r.facility_id === fac.id);
      counts[key].requests_count += reqs.length;
    });
    return Object.values(counts);
  }

  public getLeadFunnelView() {
    const statusCounts: Record<string, number> = {
      draft: 0,
      submitted: 0,
      under_review: 0,
      quoted: 0,
      approved: 0,
      activated: 0,
      rejected: 0,
    };
    this.serviceRequests.forEach((csr) => {
      if (statusCounts[csr.status] !== undefined) {
        statusCounts[csr.status]++;
      }
    });
    const total = this.serviceRequests.length || 1;
    return Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
      pct: Math.round((count / total) * 100),
    }));
  }

  public addFacilitySubtype(name_ar: string, name_en: string): FacilitySubtype {
    const code = 'custom_' + Date.now();
    const newSubtype: FacilitySubtype = {
      id: 'st_' + Date.now(),
      code,
      name_ar,
      name_en,
      is_system: false,
      is_active: true,
    };
    this.facilitySubtypes.push(newSubtype);
    this.saveState();
    return newSubtype;
  }
}

export const storageService = new StorageService();
