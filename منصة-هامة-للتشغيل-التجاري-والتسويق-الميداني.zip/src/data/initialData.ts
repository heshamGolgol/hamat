import { 
  FacilitySubtype, 
  Department, 
  ClientFacility, 
  ClientServiceRequest, 
  MarketingVisitAppointment, 
  Visit, 
  Quote, 
  Subscription, 
  Part, 
  WarehouseStock, 
  QRCodeRecord, 
  NotificationRecord, 
  UserRoleDefinition,
  JobLockRecord,
  RefreshTokenRecord,
  LoyaltyWallet,
  EmployeeDue,
  PerformanceReview,
  AssetRecord,
  TechnicianLiveLocation,
  EmployeeMarketingActivation
} from '../types';

export const DEPARTMENTS: Department[] = [
  { id: 'elevators', name_ar: 'المصاعد والسلالم الكهربائية', name_en: 'Elevators & Escalators', icon: 'MoveVertical', managerName: 'م. أحمد الشهري' },
  { id: 'fire_safety', name_ar: 'أنظمة السلامة ومكافحة الحريق', name_en: 'Fire Safety Systems', icon: 'Flame', managerName: 'م. خالد الدوسري' },
  { id: 'cctv', name_ar: 'كاميرات المراقبة والأنظمة الأمنية', name_en: 'CCTV & Surveillance', icon: 'Camera', managerName: 'م. طارق العتيبي' },
  { id: 'environmental', name_ar: 'الخدمات البيئية والتصاريح', name_en: 'Environmental Permits & Studies', icon: 'Leaf', managerName: 'د. ريم القحطاني' },
  { id: 'security', name_ar: 'الحراسات الأمنية والتشغيل', name_en: 'Security Guard Services', icon: 'Shield', managerName: 'أ. فهد المطيري' },
  { id: 'extinguishers', name_ar: 'طفايات الحريق ومعدات السلامة', name_en: 'Fire Extinguishers', icon: 'LifeBuoy', managerName: 'م. سامي السبيعي' },
  { id: 'contracting', name_ar: 'المقاولات والأعمال المدنية المتخصصة', name_en: 'General Contracting', icon: 'HardHat', managerName: 'م. وليد البدر' },
];

export const INITIAL_FACILITY_SUBTYPES: FacilitySubtype[] = [
  { id: 'st_1', code: 'industrial', name_ar: 'صناعي / مصنع', name_en: 'Industrial / Factory', is_system: true, is_active: true },
  { id: 'st_2', code: 'educational', name_ar: 'تعليمي / معاهد ومدارس', name_en: 'Educational', is_system: true, is_active: true },
  { id: 'st_3', code: 'warehouse', name_ar: 'مستودع / لوجستي', name_en: 'Warehouse / Logistics', is_system: true, is_active: true },
  { id: 'st_4', code: 'workshop', name_ar: 'ورشة صيانة / تشغيل', name_en: 'Workshop', is_system: true, is_active: true },
  { id: 'st_5', code: 'farm', name_ar: 'مزارع ومنشآت زراعية', name_en: 'Farm / Agriculture', is_system: true, is_active: true },
  { id: 'st_6', code: 'healthcare', name_ar: 'صحي / مستشفيات ومجمعات طبية', name_en: 'Healthcare / Hospitals', is_system: false, is_active: true },
  { id: 'st_7', code: 'commercial_center', name_ar: 'مجمع تجاري / مولات وأسواق', name_en: 'Commercial Center / Mall', is_system: false, is_active: true },
  { id: 'st_8', code: 'other', name_ar: 'أخرى (مخصص)', name_en: 'Other', is_system: true, is_active: true },
];

// Point 1 & 18: Full 19 Roles with personalized Landing Pages and Widgets
export const ROLES_CATALOG: UserRoleDefinition[] = [
  { 
    code: 'SYS_ADMIN', 
    title_ar: 'مدير النظام التقني', 
    level: 1, 
    domain: 'all', 
    description_ar: 'إدارة البنية التحتية، الصلاحيات، التدقيق الأمني، والإعدادات المركزية',
    landing_route: '/admin/health',
    default_view: 'chart',
    widgets: ['system_health', 'active_sessions', 'database_integrity', 'security_alerts']
  },
  { 
    code: 'GM', 
    title_ar: 'المدير العام', 
    level: 2, 
    parent_role: 'SYS_ADMIN', 
    domain: 'all', 
    description_ar: 'مراقبة العوائد المالية، أداء الأقسام، واعتماد القرارات الاستراتيجية',
    landing_route: '/dashboard/executive',
    default_view: 'chart',
    widgets: ['revenue_mtd', 'active_contracts', 'expiring_30d', 'top_marketers']
  },
  { 
    code: 'ADMIN_MGR', 
    title_ar: 'المدير الإداري', 
    level: 3, 
    parent_role: 'GM', 
    domain: 'all', 
    description_ar: 'الإشراف الإداري على العمليات، الموارد البشرية، وتنسيق الأقسام',
    landing_route: '/dashboard/operations',
    default_view: 'chart',
    widgets: ['today_visits', 'open_faults', 'team_utilization', 'pending_hr']
  },
  { 
    code: 'FINANCE_MGR', 
    title_ar: 'المدير المالي (Finance Manager)', 
    level: 4, 
    parent_role: 'ADMIN_MGR', 
    domain: 'all', 
    description_ar: 'اعتماد العقود وتفعيل الحسابات بعد السداد، مراقبة التحصيل وتكاليف الزيارات',
    landing_route: '/finance/overview',
    default_view: 'chart',
    widgets: ['pending_activations', 'cash_flow', 'receivables', 'visit_cost_audits']
  },
  { 
    code: 'HR_MGR', 
    title_ar: 'مدير الموارد البشرية (HR Manager)', 
    level: 4, 
    parent_role: 'ADMIN_MGR', 
    domain: 'all', 
    description_ar: 'إدارة عمولات المسوقين، وضع التسويق الإضافي للموظفين، وتقييمات الأداء',
    landing_route: '/hr/overview',
    default_view: 'list',
    widgets: ['commissions_due', 'employee_marketing_stats', 'performance_reviews', 'attendance']
  },
  { 
    code: 'MARKETING_MGR', 
    title_ar: 'مدير التسويق والمبيعات', 
    level: 4, 
    parent_role: 'ADMIN_MGR', 
    domain: 'all', 
    description_ar: 'قيادة مسار التسويق، مراجعة وإكمال مسودات المسوقين، واعتماد المواعيد',
    landing_route: '/marketing/funnel',
    default_view: 'kanban',
    widgets: ['funnel_stages', 'top_marketers', 'pending_drafts', 'density_map']
  },
  { 
    code: 'MARKETER', 
    title_ar: 'مسوق ميداني معتمد', 
    level: 5, 
    parent_role: 'MARKETING_MGR', 
    domain: 'own', 
    description_ar: 'تسجيل المنشآت والعملاء، حفظ المسودات، متابعة الصفقات، وتحليل كثافة المشتركين',
    landing_route: '/marketing/my-leads',
    default_view: 'list',
    widgets: ['my_leads_pipeline', 'density_radius_map', 'commission_wallet', 'pending_drafts']
  },
  { 
    code: 'REPRESENTATIVE', 
    title_ar: 'مندوب مبيعات تنفيذي', 
    level: 5, 
    parent_role: 'MARKETING_MGR', 
    domain: 'own', 
    description_ar: 'متابعة العملاء المحتملين، تقديم عروض الأسعار، وتوقيع الاتفاقيات',
    landing_route: '/sales/my-pipeline',
    default_view: 'kanban',
    widgets: ['my_opportunities', 'active_quotes', 'my_commission', 'density_map']
  },
  { 
    code: 'DOMAIN_MGR', 
    title_ar: 'مدير قسم متخصص (مصاعد / سلامة / كاميرات)', 
    level: 4, 
    parent_role: 'ADMIN_MGR', 
    domain: 'elevators', 
    description_ar: 'دراسة تقارير المعاينة الفنية، تسعير بنود العروض، وجرد أصول وقطع القسم',
    landing_route: '/domain/overview',
    default_view: 'chart',
    widgets: ['domain_visits_today', 'pending_quotes', 'inventory_alerts', 'team_custody']
  },
  { 
    code: 'TEAM_SUPERVISOR', 
    title_ar: 'مشرف الفرق الميدانية', 
    level: 5, 
    parent_role: 'DOMAIN_MGR', 
    domain: 'elevators', 
    description_ar: 'توزيع الزيارات على الفرق عبر خريطة الأقرب تلقائياً، واعتماد تقارير المعاينة',
    landing_route: '/team/dispatch',
    default_view: 'map',
    widgets: ['live_dispatch_map', 'nearest_team_suggestions', 'unassigned_visits', 'team_load']
  },
  { 
    code: 'MAINT_TEAM_LEADER', 
    title_ar: 'قائد فريق صيانة وقائية', 
    level: 6, 
    parent_role: 'TEAM_SUPERVISOR', 
    domain: 'elevators', 
    description_ar: 'إسناد المهام للفنيين داخل الفريق، وإدارة عهدة الأجهزة والسيارة التابعة للفريق',
    landing_route: '/team/my-team',
    default_view: 'list',
    widgets: ['my_team_visits', 'team_custody_assets', 'parts_in_hand', 'active_sessions']
  },
  { 
    code: 'MAINT_TECHNICIAN', 
    title_ar: 'فني صيانة وقائية ميداني', 
    level: 6, 
    parent_role: 'MAINT_TEAM_LEADER', 
    domain: 'elevators', 
    description_ar: 'مسح QR مزدوج (بدء/نهاية الزيارة)، استهلاك قطع الغيار، ورفع التقرير',
    landing_route: '/field/today',
    default_view: 'list',
    widgets: ['today_visits_list', 'active_visit_timer', 'dual_qr_scanner', 'report_prompt']
  },
  { 
    code: 'FAULT_TEAM_LEADER', 
    title_ar: 'قائد فريق بلاغات وأعطال', 
    level: 6, 
    parent_role: 'TEAM_SUPERVISOR', 
    domain: 'elevators', 
    description_ar: 'الاستجابة الفورية لبلاغات الطوارئ، وتوجيه أقرب فني ومراقبة الـ SLA',
    landing_route: '/faults/dispatch',
    default_view: 'map',
    widgets: ['live_faults_map', 'sla_timers', 'nearest_fault_tech', 'active_emergency_tokens']
  },
  { 
    code: 'FAULT_TECHNICIAN', 
    title_ar: 'فني طوارئ وأعطال', 
    level: 6, 
    parent_role: 'FAULT_TEAM_LEADER', 
    domain: 'elevators', 
    description_ar: 'مباشرة الأعطال بالـ QR المزدوج، وحساب تكاليف الإصلاح بالثانية وإعادة الأصل للتشغيل',
    landing_route: '/field/faults',
    default_view: 'list',
    widgets: ['urgent_faults_list', 'timer_and_costs', 'dual_qr_scanner', 'parts_emergency']
  },
  { 
    code: 'SECURITY_MGR', 
    title_ar: 'مدير الحراسات الأمنية', 
    level: 4, 
    parent_role: 'ADMIN_MGR', 
    domain: 'security', 
    description_ar: 'تخطيط ورديات الحراسة، توزيع الأفراد، ومتابعة حوادث المواقع',
    landing_route: '/security/overview',
    default_view: 'chart',
    widgets: ['active_shifts', 'incidents_today', 'guards_on_duty', 'site_coverage']
  },
  { 
    code: 'GUARD', 
    title_ar: 'حارس أمن ميداني', 
    level: 5, 
    parent_role: 'SECURITY_MGR', 
    domain: 'security', 
    description_ar: 'تسجيل الحضور عبر QR، ضبط المداخل، وتوثيق الملاحظات الأمنية',
    landing_route: '/guard/my-shift',
    default_view: 'list',
    widgets: ['my_shift_details', 'check_in_qr', 'incident_report', 'site_contacts']
  },
  { 
    code: 'ENV_PERMITS_MGR', 
    title_ar: 'مدير التصاريح والدراسات البيئية', 
    level: 4, 
    parent_role: 'ADMIN_MGR', 
    domain: 'environmental', 
    description_ar: 'إصدار التراخيص البيئية، الفحوص المخبرية، واعتماد الدراسات',
    landing_route: '/env/permits',
    default_view: 'list',
    widgets: ['pending_permits', 'expiring_permits', 'inspections_today', 'compliance_status']
  },
  { 
    code: 'ENV_INSPECTOR', 
    title_ar: 'مفتش بيئي ميداني', 
    level: 5, 
    parent_role: 'ENV_PERMITS_MGR', 
    domain: 'environmental', 
    description_ar: 'أخذ العينات، قياس الانبعاثات، والتحقق من اشتراطات الالتزام',
    landing_route: '/env/my-inspections',
    default_view: 'list',
    widgets: ['inspections_schedule', 'active_sampling', 'dual_qr_scan', 'lab_reports']
  },
  { 
    code: 'CLIENT', 
    title_ar: 'العميل (المنشأة المستفيدة)', 
    level: 7, 
    domain: 'client', 
    description_ar: 'استعراض العروض، تتبع الزيارات بالـ QR، متابعة رصيد الولاء وتجديد العقود',
    landing_route: '/portal/overview',
    default_view: 'chart',
    widgets: ['my_sites', 'upcoming_visits', 'open_faults', 'loyalty_points', 'contract_expiry_alert']
  },
  { 
    code: 'REFERRED_CLIENT', 
    title_ar: 'عميل مُوصى به (برنامج الولاء)', 
    level: 7, 
    domain: 'client', 
    description_ar: 'استبدال نقاط الولاء (استرداد نقدي أو خصم على التجديد القادم)',
    landing_route: '/portal/loyalty',
    default_view: 'chart',
    widgets: ['loyalty_wallet', 'referred_friends', 'redeem_cash_or_discount', 'active_contracts']
  },
];

export const INITIAL_FACILITIES: ClientFacility[] = [
  {
    id: 'fac_1',
    client_id: 'cln_1',
    facility_name: 'مجمع النخيل الطبي المتخصص',
    facility_type: 'commercial',
    commercial_subtype: 'st_6', // healthcare
    owner_name: 'د. سارة بنت عبد الله الغامدي',
    owner_phone: '+966502220001',
    delegate_name: 'م. فيصل بن خالد العمري',
    delegate_phone: '+966502220003',
    location_lat: 21.5685,
    location_lng: 39.1677,
    map_url: 'https://maps.google.com/?q=21.5685,39.1677',
    address_text: 'جدة - حي الزهراء - طريق الأمير سلطان - مبنى 4 طوابق',
    notes: 'المبنى الطبي يحتوي 4 مصاعد Otis، نظام إطفاء مرشات مائية، وغرفة تحكم كاميرات مركزية.',
    site_photo_url: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop&q=80',
    created_at: '2026-10-20 09:30:00',
  },
  {
    id: 'fac_2',
    client_id: 'cln_2',
    facility_name: 'شركة اليمامة للصناعات التحويلية',
    facility_type: 'commercial',
    commercial_subtype: 'st_1', // industrial
    owner_name: 'الشيخ عبد الرحمن بن منصور التميمي',
    owner_phone: '+966551112233',
    delegate_name: 'أ. طلال الرويلي',
    delegate_phone: '+966554443322',
    location_lat: 24.7136,
    location_lng: 46.6753,
    map_url: 'https://maps.google.com/?q=24.7136,46.6753',
    address_text: 'الرياض - المدينة الصناعية الثانية - شارع 14',
    notes: 'مصنع متقدم يحتاج شهادات دفاع مدني، وتجديد 80 طفاية حريق، و3 حراس أمن للورديات.',
    site_photo_url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&auto=format&fit=crop&q=80',
    created_at: '2026-10-21 14:15:00',
  },
  {
    id: 'fac_3',
    client_id: 'cln_3',
    facility_name: 'مستودعات الخليج للخدمات اللوجستية',
    facility_type: 'commercial',
    commercial_subtype: 'st_3', // warehouse
    owner_name: 'م. إبراهيم بن عبد العزيز الحصان',
    owner_phone: '+966533339988',
    delegate_name: 'أ. حسام السعيد',
    delegate_phone: '+966533339900',
    location_lat: 26.4207,
    location_lng: 50.0888,
    map_url: 'https://maps.google.com/?q=26.4207,50.0888',
    address_text: 'الدمام - الميناء الجاف - طريق الملك فهد',
    notes: 'مستودع مبرد ومستودع بضائع عامة. طلب صيانة أنظمة الإنذار وتركيب 16 كاميرا مراقبة IP.',
    site_photo_url: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800&auto=format&fit=crop&q=80',
    created_at: '2026-10-22 11:00:00',
  }
];

export const INITIAL_SERVICE_REQUESTS: ClientServiceRequest[] = [
  {
    id: 'csr_1',
    request_number: 'REQ-2026-0001',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    facility_id: 'fac_1',
    department_id: 'elevators',
    service_category: 'contract',
    service_title_ar: 'عقد صيانة دورية مصاعد (4 مصاعد Otis)',
    service_details: { elevators_count: 4, buildings: 1, manufacturer: 'Otis', floors: 4 },
    status: 'under_review',
    marketer_id: 'usr_mkt_1',
    marketer_name: 'سلطان بن فهد (مسوق معتمد)',
    marketer_estimated_value: 24000,
    marketer_pricing_notes: 'تقدير مبدئي: 4 مصاعد في مستشفى طبي خاص بمعدل 6,000 ريال سنوياً للمصعد',
    domain_approved_value: 24000,
    submitted_at: '2026-10-20 09:35:00',
    created_at: '2026-10-20 09:35:00',
  },
  {
    id: 'csr_2',
    request_number: 'REQ-2026-0002',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    facility_id: 'fac_1',
    department_id: 'cctv',
    service_category: 'installation',
    service_title_ar: 'توريد وتركيب 12 كاميرا مراقبة بدقة 4K',
    service_details: { cameras_count: 12, storage_weeks: 4, indoor_count: 8, outdoor_count: 4 },
    status: 'under_review',
    marketer_id: 'usr_mkt_1',
    marketer_name: 'سلطان بن فهد (مسوق معتمد)',
    marketer_estimated_value: 12000,
    submitted_at: '2026-10-20 09:35:00',
    created_at: '2026-10-20 09:35:00',
  },
  {
    id: 'csr_3',
    request_number: 'REQ-2026-0003',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    facility_id: 'fac_1',
    department_id: 'extinguishers',
    service_category: 'refill',
    service_title_ar: 'فحص وتعبئة واختبار ضغط 30 طفاية بودرة وCO2',
    service_details: { count: 30, types: ['powder_6kg', 'co2_5kg'], certification_required: true },
    status: 'under_review',
    marketer_id: 'usr_mkt_1',
    marketer_name: 'سلطان بن فهد (مسوق معتمد)',
    marketer_estimated_value: 3600,
    submitted_at: '2026-10-20 09:35:00',
    created_at: '2026-10-20 09:35:00',
  },
  {
    id: 'csr_4',
    request_number: 'REQ-2026-0004',
    client_id: 'cln_2',
    client_name: 'شركة اليمامة للصناعات التحويلية',
    facility_id: 'fac_2',
    department_id: 'fire_safety',
    service_category: 'certificate',
    service_title_ar: 'إصدار تقرير السلامة وشهادة الإشراف الوقائي للدفاع المدني',
    service_details: { cert_type: 'civil_defense', area_sqm: 4500, hazards: 'medium' },
    status: 'quoted',
    quote_id: 'quo_1',
    marketer_id: 'usr_mkt_2',
    marketer_name: 'منى الشريف (مسوقة أعمال)',
    marketer_estimated_value: 18000,
    domain_approved_value: 18000,
    submitted_at: '2026-10-21 14:20:00',
    created_at: '2026-10-21 14:20:00',
  },
  {
    id: 'csr_5',
    request_number: 'REQ-2026-0005',
    client_id: 'cln_2',
    client_name: 'شركة اليمامة للصناعات التحويلية',
    facility_id: 'fac_2',
    department_id: 'security',
    service_category: 'guards',
    service_title_ar: 'تأمين 3 حراسات أمنية مدار 24 ساعة',
    service_details: { count: 3, shift_hours: 8, uniform: 'formal', weapons: false },
    status: 'quoted',
    quote_id: 'quo_1',
    marketer_id: 'usr_mkt_2',
    marketer_name: 'منى الشريف (مسوقة أعمال)',
    marketer_estimated_value: 180000,
    domain_approved_value: 180000,
    submitted_at: '2026-10-21 14:20:00',
    created_at: '2026-10-21 14:20:00',
  }
];

export const INITIAL_APPOINTMENTS: MarketingVisitAppointment[] = [
  {
    id: 'app_1',
    appointment_number: 'APP-2026-0001',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    facility_id: 'fac_1',
    facility_name: 'مجمع النخيل الطبي المتخصص',
    requested_date: '2026-10-25',
    requested_time: '10:00',
    status: 'confirmed',
    confirmed_by: 'م. أحمد الشهري (مدير المصاعد والسلامة)',
    confirmed_at: '2026-10-20 11:00:00',
    converted_visit_id: 'vis_1',
    marketer_id: 'usr_mkt_1',
    marketer_name: 'سلطان بن فهد',
    created_at: '2026-10-20 09:35:00',
  },
  {
    id: 'app_2',
    appointment_number: 'APP-2026-0002',
    client_id: 'cln_2',
    client_name: 'شركة اليمامة للصناعات التحويلية',
    facility_id: 'fac_2',
    facility_name: 'شركة اليمامة للصناعات التحويلية',
    requested_date: '2026-10-27',
    requested_time: '13:30',
    status: 'requested',
    marketer_id: 'usr_mkt_2',
    marketer_name: 'منى الشريف',
    created_at: '2026-10-21 14:20:00',
  }
];

// Point 3, 14 & 15: Visits with dual QR session, technician/leader/supervisor attribution, and second-by-second costs
export const INITIAL_VISITS: Visit[] = [
  {
    id: 'vis_1',
    visit_number: 'VIS-2026-0001',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    facility_id: 'fac_1',
    facility_name: 'مجمع النخيل الطبي المتخصص',
    site_address: 'جدة - حي الزهراء - طريق الأمير سلطان',
    location_lat: 21.5685,
    location_lng: 39.1677,
    visit_type: 'inspection',
    source_type: 'marketing',
    marketing_appointment_id: 'app_1',
    scheduled_date: '2026-10-25',
    scheduled_time: '10:00',
    status: 'in_progress',
    session_status: 'active',
    start_scan_at: '2026-10-25 10:02:15',
    duration_seconds: 2450, // 40 minutes 50 seconds
    
    // Structure & Supervision
    assigned_team_id: 'team_jed_01',
    assigned_team_name: 'فريق المعاينة الفنية الموحد - جدة',
    assigned_supervisor_name: 'مشرف المنطقة: م. حسام العمودي',
    assigned_team_leader_name: 'قائد الفريق: م. ياسر الحربي',
    assigned_technician_id: 'tech_01',
    assigned_technician_name: 'فني أول: عبد الله المالكي',
    
    // Second-by-second Cost Breakdown
    labor_cost: 34.03, // (2450s / 3600) * 50 SAR/h
    vehicle_cost: 10.21, // (2450s / 3600) * 15 SAR/h operating cost
    parts_cost: 0,
    total_cost: 44.24,

    completion_percentage: 60,
    qr_verified: true,
    findings: ['فحص 4 مصاعد Otis: تعمل بكفاءة وتحتاج تغيير رولمانات الباب فقط'],
    created_by: 'م. أحمد الشهري',
    created_at: '2026-10-20 11:05:00',
  }
];

export const INITIAL_QUOTES: Quote[] = [
  {
    id: 'quo_1',
    quote_number: 'QUO-2026-0001',
    client_id: 'cln_2',
    client_name: 'شركة اليمامة للصناعات التحويلية',
    facility_id: 'fac_2',
    facility_name: 'شركة اليمامة للصناعات التحويلية',
    quote_type: 'باقة صناعية متكاملة (سلامة وحراسات)',
    contract_type: 'standard',
    items: [
      {
        id: 'qi_1',
        quote_id: 'quo_1',
        department_id: 'fire_safety',
        description: 'تقرير فني هندسي وشهادة إشراف وقائي معتمدة للدفاع المدني',
        quantity: 1,
        unit_price: 18000,
        total_price: 18000,
      },
      {
        id: 'qi_2',
        quote_id: 'quo_1',
        department_id: 'security',
        description: 'خدمة 3 حراسات أمنية مدربة مدار 24 ساعة (عقد سنوي)',
        quantity: 3,
        unit_price: 60000,
        total_price: 180000,
      }
    ],
    subtotal: 198000,
    vat_rate: 0.15,
    vat_amount: 29700,
    total_price: 227700,
    status: 'sent',
    valid_until: '2026-11-25',
    created_by: 'م. خالد الدوسري',
    created_at: '2026-10-22 15:30:00',
  }
];

// Point 2: Subscriptions including Standard vs Premium+ (zero visits, emergency tokens)
export const INITIAL_SUBSCRIPTIONS: Subscription[] = [
  {
    id: 'sub_demo_1',
    subscription_number: 'SUB-2026-0001',
    client_id: 'cln_3',
    client_name: 'مستودعات الخليج للخدمات اللوجستية',
    facility_id: 'fac_3',
    facility_name: 'مستودعات الخليج للخدمات اللوجستية',
    contract_type: 'standard',
    items: [
      {
        id: 'si_1',
        subscription_id: 'sub_demo_1',
        department_id: 'cctv',
        service_name: 'صيانة وقائية دورية لمنظومة 16 كاميرا وشبكة NVR',
        quantity: 16,
        unit_value: 1200,
        total_value: 19200,
        visit_frequency: 'monthly',
        visits_per_year: 12
      },
      {
        id: 'si_2',
        subscription_id: 'sub_demo_1',
        department_id: 'extinguishers',
        service_name: 'فحص ربع سنوي وإعادة ضغط طفايات الحريق بالمستودع',
        quantity: 40,
        unit_value: 180,
        total_value: 7200,
        visit_frequency: 'quarterly',
        visits_per_year: 4
      }
    ],
    total_annual_value: 26400,
    start_date: '2026-10-01',
    end_date: '2027-09-30',
    status: 'active',
    finance_approved_by: 'المدير المالي (FINANCE_MGR)',
    finance_approved_at: '2026-10-01 10:30:00',
    created_at: '2026-10-01 10:00:00'
  },
  {
    id: 'sub_demo_2_premium_plus',
    subscription_number: 'SUB-2026-0002-PLUS',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    facility_id: 'fac_1',
    facility_name: 'مجمع النخيل الطبي المتخصص',
    contract_type: 'premium_plus', // Point 2: Premium+ contract
    emergency_tokens_total: 12,
    emergency_tokens_remaining: 10,
    free_parts_allowance_annual: 8000,
    free_parts_consumed: 1250,
    sla_response_hours: 4, // SLA: 4 hours
    items: [
      {
        id: 'si_p1',
        subscription_id: 'sub_demo_2_premium_plus',
        department_id: 'elevators',
        service_name: 'عقد استجابة طوارئ فائق السرعة المميز+ (بدون زيارات دورية) مع قطع غيار مجانية',
        quantity: 4,
        unit_value: 9000,
        total_value: 36000,
        visit_frequency: 'annual',
        visits_per_year: 0 // Zero scheduled visits!
      }
    ],
    total_annual_value: 36000,
    start_date: '2026-10-15',
    end_date: '2026-11-20', // Point 11: Expiring within 30 days to test alert
    status: 'active',
    finance_approved_by: 'المدير المالي (FINANCE_MGR)',
    finance_approved_at: '2026-10-15 14:00:00',
    created_at: '2026-10-15 12:00:00'
  }
];

export const INITIAL_PARTS: Part[] = [
  {
    id: 'prt_1',
    part_number: 'PRT-ELV-01',
    name_ar: 'لوحة تحكم مصاعد ذكية Microprocessor Board',
    name_en: 'Smart Elevator Controller Board',
    department_ids: ['elevators'],
    facility_types: ['commercial', 'residential', 'government'],
    unit: 'قطعة',
    unit_cost: 3400,
    is_active: true,
  },
  {
    id: 'prt_2',
    part_number: 'PRT-ELV-02',
    name_ar: 'حبال جر فولاذية مجدولة 10mm Steel Wire Ropes',
    name_en: 'Steel Traction Wire Rope 10mm',
    department_ids: ['elevators'],
    facility_types: ['commercial', 'government'],
    unit: 'متر',
    unit_cost: 45,
    is_active: true,
  },
  {
    id: 'prt_3',
    part_number: 'PRT-FIR-01',
    name_ar: 'رأس رشاش مائي نحاسي معتمد UL/FM Sprinkler Head',
    name_en: 'UL/FM Certified Brass Sprinkler Head',
    department_ids: ['fire_safety'],
    facility_types: ['commercial', 'government'],
    commercial_subtypes: ['industrial', 'warehouse', 'healthcare'],
    unit: 'قطعة',
    unit_cost: 85,
    is_active: true,
  },
  {
    id: 'prt_4',
    part_number: 'PRT-CAM-01',
    name_ar: 'كاميرا شبكية ذكية 4K بدقة عالية ورؤية ليلية',
    name_en: '4K IP Bullet Camera IR 50m',
    department_ids: ['cctv'],
    facility_types: ['commercial', 'residential', 'government'],
    unit: 'جهاز',
    unit_cost: 650,
    is_active: true,
  },
  {
    id: 'prt_5',
    part_number: 'PRT-EXT-01',
    name_ar: 'مسحوق بودرة كيماوية جافة ABC 50lb Refill Powder',
    name_en: 'ABC Dry Chemical Powder Refill',
    department_ids: ['extinguishers'],
    facility_types: ['commercial', 'government', 'residential'],
    unit: 'كيس 25 كجم',
    unit_cost: 160,
    is_active: true,
  }
];

export const INITIAL_STOCK: WarehouseStock[] = [
  {
    id: 'stk_1',
    part_id: 'prt_1',
    part_name: 'لوحة تحكم مصاعد ذكية Microprocessor Board',
    part_number: 'PRT-ELV-01',
    warehouse_id: 'wh_jed',
    warehouse_name: 'مستودع الغربية الرئيسي - جدة',
    quantity: 14,
    reserved_quantity: 2,
    available_quantity: 12
  },
  {
    id: 'stk_2',
    part_id: 'prt_2',
    part_name: 'حبال جر فولاذية مجدولة 10mm Steel Wire Ropes',
    part_number: 'PRT-ELV-02',
    warehouse_id: 'wh_jed',
    warehouse_name: 'مستودع الغربية الرئيسي - جدة',
    quantity: 500,
    reserved_quantity: 80,
    available_quantity: 420
  },
  {
    id: 'stk_3',
    part_id: 'prt_3',
    part_name: 'رأس رشاش مائي نحاسي معتمد UL/FM Sprinkler Head',
    part_number: 'PRT-FIR-01',
    warehouse_id: 'wh_ryd',
    warehouse_name: 'مستودع الوسطى الرئيسي - الرياض',
    quantity: 240,
    reserved_quantity: 40,
    available_quantity: 200
  },
  {
    id: 'stk_4',
    part_id: 'prt_4',
    part_name: 'كاميرا شبكية ذكية 4K بدقة عالية ورؤية ليلية',
    part_number: 'PRT-CAM-01',
    warehouse_id: 'wh_ryd',
    warehouse_name: 'مستودع الوسطى الرئيسي - الرياض',
    quantity: 36,
    reserved_quantity: 12,
    available_quantity: 24
  },
  {
    id: 'stk_5',
    part_id: 'prt_5',
    part_name: 'مسحوق بودرة كيماوية جافة ABC 50lb Refill Powder',
    part_number: 'PRT-EXT-01',
    warehouse_id: 'wh_dam',
    warehouse_name: 'مستودع الشرقية - الدمام',
    quantity: 65,
    reserved_quantity: 5,
    available_quantity: 60
  }
];

export const INITIAL_QR_CODES: QRCodeRecord[] = [
  {
    id: 'qr_1',
    qr_code: 'HAMA-FAC-1001-SITE',
    client_id: 'cln_1',
    facility_id: 'fac_1',
    purpose: 'site_access',
    assigned_label: 'رمز دخول الموقع وتوثيق وصول الفريق',
    location_name: 'مجمع النخيل الطبي - البوابة الرئيسية',
    scans_count: 5,
    last_scanned_at: '2026-10-25 10:02:15',
    created_at: '2026-10-20 09:35:00'
  },
  {
    id: 'qr_2',
    qr_code: 'HAMA-SRV-2001-ELV',
    client_id: 'cln_1',
    facility_id: 'fac_1',
    service_request_id: 'csr_1',
    purpose: 'service_specific',
    assigned_label: 'رمز فحص مصاعد المبنى الرئيسي (غرفة المحركات)',
    location_name: 'مجمع النخيل الطبي - السطح غرفة المصاعد',
    scans_count: 2,
    last_scanned_at: '2026-10-22 16:40:00',
    created_at: '2026-10-20 09:35:00'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationRecord[] = [
  {
    id: 'notif_1',
    recipient_type: 'user',
    recipient_id: 'usr_mkt_1',
    recipient_name: 'سلطان بن فهد',
    channel: 'in_app',
    subject: 'تأكيد موعد المعاينة #APP-2026-0001',
    message: 'تم تأكيد موعد المعاينة الميدانية لمنشأة مجمع النخيل الطبي يوم 2026-10-25 الساعة 10:00 وتوليد زيارة الفحص التلقائية.',
    status: 'read',
    event_type: 'marketing_appointment_confirmed',
    created_at: '2026-10-20 11:00:00'
  },
  {
    id: 'notif_2',
    recipient_type: 'client',
    recipient_id: 'cln_2',
    recipient_name: 'شركة اليمامة للصناعات',
    channel: 'whatsapp',
    subject: 'عرض سعر معتمد جاهز #QUO-2026-0001',
    message: 'يسرنا إشعاركم بأن عرض السعر الموحد لأنظمة السلامة والحراسات الأمنية جاهز للاطلاع والاعتماد بقيمة 227,700 ريال شامل الضريبة.',
    status: 'delivered',
    event_type: 'quote_ready',
    created_at: '2026-10-22 15:35:00'
  },
  {
    id: 'notif_3',
    recipient_type: 'client',
    recipient_id: 'cln_1',
    recipient_name: 'مجمع النخيل الطبي المتخصص',
    channel: 'whatsapp',
    subject: 'تنبيه انتهاء العقد خلال 10 أيام #SUB-2026-0002-PLUS',
    message: 'عزيزنا العميل: نود تذكيركم بأن اشتراككم المميز+ ينتهي بتاريخ 2026-11-20. يرجى المبادرة بالتجديد للاستفادة من خصم الولاء 10%.',
    status: 'sent',
    event_type: 'contract_expiry_30d',
    created_at: '2026-11-10 09:00:00'
  }
];

// Point 10: Initial Loyalty Wallets
export const INITIAL_LOYALTY_WALLETS: LoyaltyWallet[] = [
  {
    id: 'lw_1',
    client_id: 'cln_1',
    client_name: 'مجمع النخيل الطبي المتخصص',
    balance_points: 3400,
    monetary_value_sar: 340, // 10 points = 1 SAR
    total_earned_points: 4400,
    total_redeemed_sar: 100,
    transactions: [
      {
        id: 'lt_1',
        wallet_id: 'lw_1',
        transaction_type: 'earn',
        points: 2000,
        monetary_value: 200,
        reference_desc: 'توصية ناجحة لمنشأة مجمع العيادات الشرقية',
        created_at: '2026-10-15 14:00:00'
      },
      {
        id: 'lt_2',
        wallet_id: 'lw_1',
        transaction_type: 'earn',
        points: 2400,
        monetary_value: 240,
        reference_desc: 'مكافأة تجديد اشتراك المصاعد السنوي',
        created_at: '2026-10-22 10:00:00'
      },
      {
        id: 'lt_3',
        wallet_id: 'lw_1',
        transaction_type: 'redeem_discount',
        points: 1000,
        monetary_value: 100,
        reference_desc: 'خصم 100 ريال على فاتورة صيانة طارئة',
        created_at: '2026-11-01 16:30:00'
      }
    ]
  }
];

// Point 9: Initial Performance Reviews & Employee Dues
export const INITIAL_PERFORMANCE_REVIEWS: PerformanceReview[] = [
  {
    id: 'pr_1',
    user_id: 'tech_01',
    user_name: 'فني أول: عبد الله المالكي',
    role: 'MAINT_TECHNICIAN',
    period: 'الربع الثالث 2026',
    visits_completed: 48,
    visits_on_time_pct: 96,
    avg_customer_rating: 4.85,
    overall_score: 4.8,
    hr_comments: 'أداء متميز في الالتزام بمسح الـ QR والتوثيق الميداني الدقيق واستهلاك قطع الغيار.',
    status: 'finalized',
    created_at: '2026-10-01 09:00:00'
  },
  {
    id: 'pr_2',
    user_id: 'usr_mkt_1',
    user_name: 'سلطان بن فهد (مسوق معتمد)',
    role: 'MARKETER',
    period: 'الربع الثالث 2026',
    visits_completed: 18,
    visits_on_time_pct: 100,
    avg_customer_rating: 4.9,
    overall_score: 4.9,
    hr_comments: 'تحقيق أعلى معدل تحويل صفقات بالمنطقة الغربية مع استيفاء صور وبيانات المنشآت بنسبة 100%.',
    status: 'finalized',
    created_at: '2026-10-01 09:30:00'
  }
];

export const INITIAL_EMPLOYEE_DUES: EmployeeDue[] = [
  {
    id: 'ed_1',
    user_id: 'usr_mkt_1',
    user_name: 'سلطان بن فهد',
    due_type: 'commission',
    source_subscription_id: 'sub_demo_2_premium_plus',
    amount: 1800, // 5% of 36,000 SAR
    status: 'approved',
    approved_by: 'مدير الموارد البشرية (HR_MGR)',
    paid_at: '2026-11-05 12:00:00',
    created_at: '2026-10-15 14:10:00'
  },
  {
    id: 'ed_2',
    user_id: 'emp_hustle_1',
    user_name: 'م. ياسر الحربي (مهندس صيانة - تسويق إضافي)',
    due_type: 'side_hustle',
    amount: 1320, // 5% of 26,400 SAR
    status: 'pending',
    created_at: '2026-10-01 10:45:00'
  }
];

// Point 16: Initial Assets with Team & Leader Custody
export const INITIAL_ASSETS: AssetRecord[] = [
  {
    id: 'ast_1',
    asset_code: 'AST-VEH-01',
    name_ar: 'فان صيانة ميدانية هيونداي H1 موديل 2024',
    category: 'vehicle',
    custody_type: 'team',
    custody_team_name: 'فريق المعاينة الفنية الموحد - جدة',
    custody_leader_name: 'م. ياسر الحربي (قائد الفريق)',
    custody_since: '2026-01-15',
    condition: 'excellent',
    value_sar: 110000
  },
  {
    id: 'ast_2',
    asset_code: 'AST-TL-02',
    name_ar: 'جهاز فحص وتشخيص أعطال لوحات المصاعد الرقمي Fluke 87V',
    category: 'testing_device',
    custody_type: 'technician',
    custody_technician_name: 'فني أول: عبد الله المالكي',
    custody_leader_name: 'م. ياسر الحربي',
    custody_since: '2026-05-10',
    condition: 'good',
    value_sar: 4500
  },
  {
    id: 'ast_3',
    asset_code: 'AST-WH-03',
    name_ar: 'مضخة تعبئة واختبار ضغط هيدروستاتيكي لطفايات الحريق',
    category: 'specialized_tool',
    custody_type: 'warehouse',
    condition: 'excellent',
    value_sar: 18500
  }
];

// Point 13: Live GPS Technician Locations for Nearest Dispatch Algorithm
export const INITIAL_TECHNICIAN_LOCATIONS: TechnicianLiveLocation[] = [
  {
    technician_id: 'tech_01',
    name: 'عبد الله المالكي',
    team_name: 'فريق صيانة جدة الشمالي',
    department_id: 'elevators',
    latitude: 21.5720,
    longitude: 39.1650, // Near Al-Zahra
    active_tasks_count: 1,
    rating: 4.8,
    vehicle_plate: 'أ ب ج 1234',
    last_updated: 'قبل 2 دقيقة'
  },
  {
    technician_id: 'tech_02',
    name: 'فيصل السعيد',
    team_name: 'فريق التدخل السريع جدة',
    department_id: 'elevators',
    latitude: 21.5540,
    longitude: 39.1720,
    active_tasks_count: 0,
    rating: 4.9,
    vehicle_plate: 'د هـ و 5678',
    last_updated: 'قبل 1 دقيقة'
  },
  {
    technician_id: 'tech_03',
    name: 'سالم الدوسري',
    team_name: 'فريق مكافحة الحريق والسلامة',
    department_id: 'fire_safety',
    latitude: 21.5890,
    longitude: 39.1550,
    active_tasks_count: 2,
    rating: 4.6,
    vehicle_plate: 'ح ط ي 9012',
    last_updated: 'قبل 4 دقائق'
  }
];

// Point 8: Employee Marketing Activation (Side-Hustle)
export const INITIAL_EMPLOYEE_MARKETING_ACTIVATIONS: EmployeeMarketingActivation[] = [
  {
    id: 'ema_1',
    user_id: 'emp_hustle_1',
    user_name: 'م. ياسر الحربي (قائد فريق صيانة)',
    user_department: 'قسم المصاعد',
    is_active: true,
    commission_rate: 5.0, // 5%
    total_leads_submitted: 4,
    total_commissions_earned: 3120,
    activated_at: '2026-06-01 10:00:00'
  }
];

export const INITIAL_JOB_LOCKS: JobLockRecord[] = [
  {
    job_name: 'ev_maintenance_plan_scheduler',
    locked_by: 'worker-node-01',
    locked_at: '2026-11-10 12:00:00',
    locked_until: '2026-11-10 12:05:00',
    heartbeat_at: '2026-11-10 12:04:30',
    is_active: true
  },
  {
    job_name: 'ev_contract_expiry_alerts',
    locked_by: 'cron-master-sa-01',
    locked_at: '2026-11-10 12:01:00',
    locked_until: '2026-11-10 12:06:00',
    heartbeat_at: '2026-11-10 12:04:45',
    is_active: true
  }
];

export const INITIAL_REFRESH_TOKENS: RefreshTokenRecord[] = [
  {
    id: 'rt_1',
    jti: 'e86b3a24-9df1-4a37-b76b-95bb51a56191',
    user_id: 'usr_mkt_1',
    token_hash: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4',
    device_fingerprint: 'Chrome-128 / macOS Sequoia / Screen 2560x1440',
    ip_address: '178.80.124.90',
    expires_at: '2026-11-17 12:00:00',
    created_at: '2026-11-10 12:00:00'
  }
];
